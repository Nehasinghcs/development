import { Injectable } from '@angular/core';
import { ToasterService } from 'angular2-toaster/src/toaster.service';
import { Router } from '@angular/router';
import { DataService } from '../../services/data.services';
import * as moment from 'moment';
import { AppSettings } from './app.settings';
import { Constants } from './app.constants';


@Injectable()

export class UtilityService {
    constructor(private _dataService: DataService, private _router: Router, private _toasterService: ToasterService) { }

    getPreviousDayMonth() {
        const date = new Date();
        const previousDay = new Date(date.getFullYear(), date.getMonth(), date.getDate() - 1);
        return moment(previousDay).format('DD/MM/YYYY');
    }

    getFirstDayMonth() {
        const date = new Date();
        const firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
        return moment(firstDay).format('DD/MM/YYYY');
    }

    getDateInDDMMYYYY(date) {
        return moment(new Date()).format('DD/MM/YYYY');
    }

    getLastDayMonth() {
        const date = new Date();
        const lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);
        return moment(lastDay).format('DD/MM/YYYY');
    }

    logout() {
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.LOGOUT, undefined);
    }

    getVerticals() {
        const returnList: any[] = [];
        let verticalList: string[];
        verticalList = JSON.parse(localStorage.verticalList);
        verticalList.forEach(element => {
            const vertical = {
                verticalId: element,
                accountIds: this._getAccounts(element)
            };
            returnList.push(vertical);
        });
        return returnList;
    }

    getAccounts() {
        const returnList: string[] = [];
        const accountList: any[] = JSON.parse(localStorage.accountList);
        accountList.forEach(element => {
            returnList.push(element.id);
        });
        return returnList;
    }

    private _getAccounts(verticalId) {
        const returnList: string[] = [];
        const accountList: string[] = JSON.parse(localStorage.accountList);
        const _accountList: any[] = accountList.filter(element => element['verticalId'] === verticalId);
        _accountList.forEach(element => {
            returnList.push(element.id);
        });
        return returnList;
    }

    handleException(status) {
        this._toasterService.pop(Constants.toaster_error, Constants.emptyString, this.getError_Status_Text(status));
        if (status.status === 401) {
            localStorage.clear();
            this._router.navigateByUrl('');
        }
    }

    getCurrentMonth() {
        return new Date().getMonth();
    }

    getCurrentYear() {
        return new Date().getFullYear();
    }

    getDaysInMonth(month, year) {
        const date = new Date(year, month, 1);
        const days = [];
        while (date.getMonth() === month) {
            days.push(new Date(date));
            date.setDate(date.getDate() + 1);
        }
        return days;
    }

    getpreviousMonthOfFirstDate() {
        const date = new Date();
        const monthStartDay = new Date(date.getFullYear(), date.getMonth() - 1, 1);
        return moment(monthStartDay).format('DD/MM/YYYY');

    }

    getpreviousMonthOfLastDate() {
        const date = new Date();
        const monthEndDay = new Date(date.getFullYear(), date.getMonth(), 0);
        return moment(monthEndDay).format('DD/MM/YYYY');
    }
    getDaysCountInMonth(month, year) {
        return new Date(year, month, 0).getDate();
    }

    getDaysDifferenceInSeconds(startDate: Date, endDate: Date) {
        return Math.abs((startDate.getTime() - endDate.getTime()) / 1000);
    }

    getDaysDifference(startDate: Date, endDate: Date) {
        return Math.abs(endDate.getDate() - startDate.getDate());
    }

    convertUTCDateToLocalDate(dateString: string) {
        const date = new Date(dateString);
        const newDate = new Date(date.getTime() + date.getTimezoneOffset() * 60 * 1000);
        const offset = date.getTimezoneOffset() / 60;
        const hours = date.getHours();
        newDate.setHours(hours - offset);
        return newDate;
    }

    getError_Status_Text(status) {
        let returnValue: string;
        if (status === 800) {
            returnValue = 'This widget already exists.';
            return returnValue;
        }
        else {
            switch (status.status) {
                case 401:
                    if (status.json().error === 'unauthorized') {
                        returnValue = 'Invalid credentials, Please enter valid credentials';
                    }
                    else {
                        returnValue = 'Session Expired, Please login again.';
                    }
                    break;
                case 400:
                    if (status.json().error === 'invalid_grant') {
                        returnValue = 'Invalid credentials, Please enter valid credentials';
                    }
                    else {
                        returnValue = 'Internal server error, Please try later.';
                    }
                    break;
                case 500:
                    returnValue = 'Internal server error, Please try later.';
                    break;
                default:
                    returnValue = 'Internal server error, Please try later.';
                    break;
            }
            return returnValue;
        }

    }

    millSecondsToTimeString(millisec) {
        let seconds: any;
        let hours: any = 0;
        let minutes: any;
        seconds = (millisec / 1000).toFixed(0);
        minutes = Math.floor(seconds / 60);
        if (minutes > 59) {
            hours = Math.floor(minutes / 60);
            hours = (hours >= 10) ? hours : '0' + hours;
            minutes = minutes - (hours * 60);
            minutes = ((minutes >= 10) ? minutes : '0' + minutes);
        }
        seconds = Math.floor(seconds % 60);
        seconds = (seconds >= 10) ? seconds : '0' + seconds;
        return hours + ':' + minutes;
    }

    getCalendarDates() {
        const DateRange = [];
        let firstDay;
        let lastDay;

        for (let i = 0; i < 13; i++) {
            const date = new Date();
            const dateObj = {
                endDate: null,
                startDate: null
            };
            if (i === 0) {
                firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
                lastDay = new Date();
                dateObj.startDate = moment(firstDay).format('DD/MM/YYYY');
                dateObj.endDate = moment(lastDay).format('DD/MM/YYYY');
            } else {
                firstDay = new Date(date.getFullYear(), date.getMonth() - (i), 1);
                lastDay = new Date(date.getFullYear(), (date.getMonth() - i) + 1, 0);
                dateObj.startDate = moment(firstDay).format('DD/MM/YYYY');
                dateObj.endDate = moment(lastDay).format('DD/MM/YYYY');
            }
            DateRange.push(dateObj);
        }
        return DateRange;
    }
}

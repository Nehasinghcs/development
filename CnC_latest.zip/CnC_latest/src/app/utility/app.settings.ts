export class AppSettings {
    public static API_ENDPOINT = 'http://172.16.17.189:8088/gateway/';
    public static LOGIN = 'http://172.16.17.189:8088/gateway/auth/oauth/token';
    // public static API_ENDPOINT = 'https://cncdev.cora.genpact.ai/gateway/';
    // public static LOGIN = 'https://cncdev.cora.genpact.ai/gateway/auth/oauth/token';

    /**Settings Services*/
    public static GET_ACCOUNTS = 'api/account/detail';
    public static ADD_ACCOUNT = 'api/account/upsertaccount';
    public static REGISTER_USER = 'api/user/register';
    public static GET_TOOLS = 'api/admin/tool/list';
    public static ADD_CONTROLLER = 'api/admin/upsertcontrollermapping';
    public static GET_CONTROLLER_LIST = 'api/controlcenter/detail';
    public static LOGOUT = 'auth/logout';

    /**Operational User Services*/
    public static GET_VERTICAL_DETAIL = 'api/vertical/detail';
    public static GET_TICKETDETAIL = 'api/ticket/detail';
    public static GET_ALERTCOUNT = 'api/alert/count';
    public static GET_ALERTDETAIL = 'api/alert/detail';
    public static GET_JOBDETAIL = 'api/job/detail';
    public static GET_CASEDETAIL = 'api/case/detail';
    public static GET_PROCESS_LIST = 'api/process/list';
    public static GET_GROUPDETAILBYID = 'api/process/groupdetailbyid';
    public static GET_PROCESS_DETAILBY_ID = 'api/process/insightsbyprocessid';
    public static GET_ROBOT_UTILIZATION = 'api/robot/utilization';
    public static GET_ROBOT_HEALTH = 'api/robot/status';
    public static GET_ROBOT_DETAILBY_ID = 'api/robot/detailbyid';
    public static GET_NOTIFICATION_ID = 'api/websocket';
    public static GET_SYSTEM_GLANCES = 'api/systemglance/detail';
    public static GET_CRR_BY_ACCOUNT_ID = 'api/analytics/crr/failedcasesbyaccountid';
    public static GET_CRR_BY_PROCESSGROUP_ID = 'api/analytics/crr/failedcasesbyprocessgroupid';
    // public static GET_CRR_BY_PROCESS_ID = 'api/analytics/crr/failedcasesbyaccountid';
    public static GET_DAYWISE_ROBOT_UTILIZATION = 'api/analytics/getdaywiserobotutilization';
    public static GET_BREACH_ACCOUNT_ID = 'api/analytics/robotuptimebyaccountid';
    public static GET_ROBOT_KPI_ACCOUNT_ID = 'api/analytics/robotkpibyaccountid';
    public static GET_BOT_COUNT = 'api/bot/count';
}

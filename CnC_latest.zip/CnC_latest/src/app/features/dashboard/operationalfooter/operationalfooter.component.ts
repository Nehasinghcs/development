import { Component, OnInit, OnDestroy } from '@angular/core';
import { DragDropDirectiveModule } from 'angular4-drag-drop';
import { Router } from '@angular/router';
import { ISubscription } from 'rxjs/Subscription';
import { SystemGlanceService } from '../systemGlances/systemGlances.service';
import { WidgetService } from '../../../../services/widget.service';
import { SharedService } from '../../../../services/shared.service';

@Component({
  selector: 'app-operationalfooter',
  templateUrl: './operationalfooter.component.html',
  styleUrls: ['./operationalfooter.component.scss'],
})
export class OperationalfooterComponent implements OnInit, OnDestroy {

  subscription_1: ISubscription;
  subscription_2: ISubscription;
  activeView: number;
  oldValue: number;
  newValue: number;
  systemGlances = [];
  activeGlances = [];
  systemGlancesData: any;

  constructor(private _systemGlanceService: SystemGlanceService, private _router: Router, private _widgetService: WidgetService, private _sharedService: SharedService) {
    this.subscription_2 = this._sharedService.changeViewEmitted.subscribe(value => {
      this.activeView = value;
    });
    this.subscription_1 = this._sharedService.widgetChange.subscribe(values => {
      if (this._widgetService.activeGlances !== undefined && this._widgetService.activeGlances.length) {
        this.activeGlances = this._widgetService.activeGlances;
      } else {
        this.activeGlances = this._widgetService.getActiveGlances();
      }
      this.systemGlances = [];
      this.oldValue = parseInt(values.split('-')[0]);
      this.newValue = parseInt(values.split('-')[1]);
      let oldItem = this.activeGlances.filter(item => item.position === this.oldValue)[0];
      let newItem = this.activeGlances.filter(item => item.position === this.newValue)[0];
      if (newItem !== undefined && oldItem !== undefined) {
        const oldItemIndex = this.activeGlances.findIndex(item => item.position === oldItem.position);
        const newItemIndex = this.activeGlances.findIndex(item => item.position === newItem.position);
        const item = this.activeGlances[oldItemIndex];
        this.activeGlances[oldItemIndex] = this.activeGlances[newItemIndex];
        this.activeGlances[newItemIndex] = item;
        this.activeGlances.forEach(element => {
          if (element.position !== this.newValue) {
            this.systemGlances.push(element);
          }
        });
      } else if (newItem === undefined) {
        newItem = this._widgetService.originalGlances.filter(item => item.position === this.newValue)[0];
        const oldItemIndex = this.activeGlances.findIndex(item => item.position === oldItem.position);
        this.activeGlances[oldItemIndex] = newItem;
        this.activeGlances.forEach(element => {
          if (element.position !== this.newValue) {
            this.systemGlances.push(element);
          }
        });
      } else if (oldItem === undefined) {
        oldItem = this._widgetService.originalGlances.filter(item => item.position === this.oldValue)[0];
        const newItemIndex = this.activeGlances.findIndex(item => item.position === newItem.position);
        this.activeGlances[newItemIndex] = oldItem;
        this.activeGlances.forEach(element => {
          if (element.position !== this.newValue) {
            this.systemGlances.push(element);
          }
        });
      }
    }
  );
  }

  editWidgets() {
    this._router.navigateByUrl('root/dashboard/widgets');
  }

  ngOnDestroy(): void {
    this.subscription_1.unsubscribe();
    this.subscription_2.unsubscribe();
  }

  getGlanceData(type) {
    let returnValue: any;
    switch (type) {
      case 'processCount':
        returnValue = this.systemGlancesData.processCount;
        break;
      case 'alertCount':
        returnValue = this.systemGlancesData.alertCount;
        break;
      case 'workforceCount':
        returnValue = this.systemGlancesData.workforceCount;
        break;
    }
    return returnValue;
  }

  ngOnInit() {
    this._systemGlanceService.getSystemGlances().subscribe(response => {
      this.systemGlancesData = response;
    });
    if (this._widgetService.activeGlances !== undefined && this._widgetService.activeGlances.length) {
      this.activeGlances = this._widgetService.activeGlances;
    } else {
      this.activeGlances = this._widgetService.getActiveGlances();
      this._widgetService.activeGlances = this.activeGlances;
    }

  }

}

import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-operational',
    template: `
    <router-outlet></router-outlet>
    `
})
// <app-header></app-header>
export class DashboardComponent { }

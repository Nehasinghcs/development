import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AutomationService } from './automation.service';
import { SharedService } from '../../../../services/shared.service';

@Component({
  selector: 'app-automationview',
  templateUrl: './automationview.component.html',
  styleUrls: ['./automationview.component.scss']
})
export class AutomationviewComponent implements OnInit {
  selectedTool = 1;
  selectedAutomation = 0;
  automationCount = 0;

  constructor(private _automationService: AutomationService, private _sharedService: SharedService, private _router: Router) {
    this._automationService.changeViewEmitted.subscribe(response => {
      setTimeout(() => this.selectedAutomation = response, 0);
    });
    this._automationService.changeCountEmitted.subscribe(response => {
      setTimeout(() => this.automationCount = response, 0);
    });
  }

  tools = [{
    id: 1,
    name: 'All'
  }, {
    id: 2,
    name: 'All 1'
  }];

  automationExceptionData = [
    { 'criticalCount': 6, 'runningCount': 23, 'account': 'All : 29' },
    { 'criticalCount': 4, 'runningCount': 12, 'account': 'BC' },
    { 'criticalCount': 2, 'runningCount': 11, 'account': 'FC' },
  /*  { "criticalCount": 1, "runningCount": 4, "account": "FC" },
    { "criticalCount": 5, "runningCount": 2, "account": "Boeing" },
    { "criticalCount": 2, "runningCount": 2, "account": "Facebook" },
    { "criticalCount": 3, "runningCount": 1, "account": "Google" }*/
  ];

  goToAccountsPage(index) {
    if (index === 1) {
      this._router.navigateByUrl('root/dashboard/view/automationview/account');
    } else if (index === 0) {
      this._router.navigateByUrl('root/dashboard/view/automationview/allaccounts');
    }
  }
  getFullScreenParameter() {
    return this._sharedService.showFullScreen;
  }
  changeViewSize() {
    this._sharedService.emitViewSizeChange(!this._sharedService.showFullScreen);
  }
  ngOnInit() {
    this._sharedService.emitWidgetChange(this._sharedService.currentView, 5);
    this._sharedService.emitViewChange(5);
  }

}

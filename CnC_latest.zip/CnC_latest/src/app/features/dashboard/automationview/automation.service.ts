import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';

@Injectable()

export class AutomationService {

    constructor() { }
    private _emitAutomationCountChange = new Subject<number>();
    changeCountEmitted = this._emitAutomationCountChange.asObservable();
    private _emitAutomationViewChange = new Subject<number>();
    changeViewEmitted = this._emitAutomationViewChange.asObservable();
    emitViewChange(change: number) {
        this._emitAutomationViewChange.next(change);
    }
    emitCountChange(change: number) {
        this._emitAutomationCountChange.next(change);
    }

}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Chart, MapChart } from 'angular-highcharts';
import { AutomationService } from '../automation.service';
import { SharedService } from '../../../../../services/shared.service';

@Component({
  selector: 'app-allaccounts',
  templateUrl: './allaccounts.component.html',
  styleUrls: ['./allaccounts.component.scss']
})
export class AllaccountsComponent implements OnInit {

  dataOne: any[] = [];
  dataTwo: any[] = [];
  constructor(private _automationService: AutomationService, private _router: Router, private _sharedService: SharedService) { }

  abubblechart = new MapChart({
    chart: {
      type: 'bubble',
      zoomType: 'xy',
      width: 600,
    },
    legend: {
      enabled: false
    },
    title: {
      text: ''
    },
    yAxis: {
      min: -40,
      max: 55,
    },
    xAxis: {
      min: -20,
      max: 27,
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },
    tooltip: {
      enabled: false
    },

    plotOptions: {
      series: {
        dataLabels: {
          enabled: true,
          format: '{point.name}'
        }
      },
      bubble: {
        minSize: 0,
        maxSize: 80,
        zMin: 0,
        zMax: 100
      }
    },

    series: [{
      color: {
        linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
        stops: [
          [0, '#ff6686'],
          [1, '#feab9e']
        ]
      },
      events: {
        click: function () {
          location.href = '#/dashboard/view/automation/process';
        }
      },
      data: [
        {
          'x': -7,
          'y': 20,
          'z': 20
        },
        {
          'x': -2,
          'y': 0,
          'z': 25
        },
        {
          'x': -2,
          'y': 17,
          'z': 4
        },
        {
          'x': -3,
          'y': -30,
          'z': 15
        },
        {
          'x': -4,
          'y': 24,
          'z': 19
        },
        {
          'x': -6,
          'y': -24,
          'z': 11
        },

      ]
    },
    {
      color: {
        radialGradient: { cx: 0.4, cy: 0.3, r: 0.7 },
        stops: [
          [0, '#6587ff'],
          [1, '#26e4fe']
        ]
      },
      marker: {
        fillColor: '#ffffff',
        borderColor: '#f04d3b'
      },
      data: [
        {
          'x': 8,
          'y': 20,
          'z': 13
        },
        {
          'x': 2,
          'y': -2,
          'z': 7
        },
        {
          'x': 19,
          'y': 1,
          'z': 8
        },
        {
          'x': 11,
          'y': -16,
          'z': 7
        },
        {
          'x': 20,
          'y': 19,
          'z': 13
        },
        {
          'x': 15,
          'y': -2,
          'z': 16
        },
        {
          'x': 14,
          'y': 20,
          'z': 22
        },
        {
          'x': 2,
          'y': -30,
          'z': 17
        },
        {
          'x': 24,
          'y': 25,
          'z': 19
        },
        {
          'x': 20,
          'y': -19,
          'z': 13
        },
        {
          'x': 5,
          'y': 1,
          'z': 17
        },
        {
          'x': 18,
          'y': -23,
          'z': 6
        },
        {
          'x': 18,
          'y': 36,
          'z': 3
        },
        {
          'x': 8,
          'y': -34,
          'z': 7
        },
        {
          'x': 3,
          'y': 32,
          'z': 24
        },
        {
          'x': 4,
          'y': -17,
          'z': 3
        },
        {
          'x': 11,
          'y': 34,
          'z': 9
        },
        {
          'x': 2,
          'y': -48,
          'z': 7
        },
        {
          'x': 18,
          'y': 27,
          'z': 3
        },
        {
          'x': 9,
          'y': -9,
          'z': 11
        },
        {
          'x': 24,
          'y': 9,
          'z': 12
        },
        {
          'x': 24,
          'y': -6,
          'z': 11
        },
        {
          'x': 4.5,
          'y': 16,
          'z': 16
        },

      ]
    }
    ]

  });

  getPlotData() {

    let i;
    let alterNate = true;
    let alterNateY1 = true;
    let alterNateY2 = true;
    for (i = 0; i < 50; i++) {
      if (alterNate) {
        this.dataOne.push({
          x: Math.floor((Math.random() * 40) + 2),
          y: alterNateY1 ? Math.floor((Math.random() * 50) + 1) : -Math.abs(Math.floor((Math.random() * 50) + 1)),
          z: Math.floor((Math.random() * 25) + 1),

        });
        alterNateY1 = !alterNateY1;
      } else {
        this.dataTwo.push({
          x: -Math.abs(Math.floor((Math.random() * 40) + 2)),
          y: alterNateY2 ? Math.floor((Math.random() * 50) + 1) : -Math.abs(Math.floor((Math.random() * 50) + 1)),
          z: Math.floor((Math.random() * 25) + 1),

        });
        alterNateY2 = !alterNateY2;
      }
      alterNate = !alterNate;
    }

  }

  ngOnInit() {
    this._automationService.emitViewChange(0);
    this._automationService.emitCountChange(6);
  }

}

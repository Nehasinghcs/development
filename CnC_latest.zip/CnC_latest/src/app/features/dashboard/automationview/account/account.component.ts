import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Chart, MapChart } from 'angular-highcharts';
import { AutomationService } from '../automation.service';
import { SharedService } from '../../../../../services/shared.service';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.scss']
})
export class AccountComponent implements OnInit {

  dataOne: any[] = [];
  dataTwo: any[] = [];

  constructor(private _automationService: AutomationService, private _router: Router, private _sharedService: SharedService) { }

  blueDataColor = {
    radialGradient: { cx: 0.4, cy: 0.3, r: 0.7 },
    stops: [
      [0, '#6587ff'],
      [1, '#26e4fe']
    ]
  };

  blueDataMarker = {
    fillColor: '#ffffff',
    borderColor: '#f04d3b'
  };
  criticalevent = {
    click: function () {
      location.href = '#/dashboard/view/automation/process';
    }
  };
  autViewDetails = new MapChart({
    chart: {
      type: 'bubble',
      zoomType: 'xy',
      width: 300,
      margin: [0, 0, 0, 0]
    },
    legend: {
      enabled: false
    },
    title: {
      text: ''
    },
    credits: {
      enabled: false
    },
    exporting: {
      enabled: false
    },
    tooltip: {
      /*  enabled: true */
      enabled: false
    },
    yAxis: {
      min: -10,
      max: 40,
    },
    xAxis: {
      min: -26,
      max: 4,
    },
    plotOptions: {
      series: {
        dataLabels: {
          enabled: false,
        }
      },
      bubble: {
        minSize: 5,
        maxSize: 70,
        zMin: 0,
        zMax: 100
      }
    },

    series: [{
      color: {
        linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
        stops: [
          [0, '#ff6686'],
          [1, '#feab9e']
        ],
        color: this.blueDataColor,
        marker: this.blueDataMarker
      },
      data: [
        {
          'x': -15,
          'y': 34,
          'z': 20,
          color: this.blueDataColor,
          marker: this.blueDataMarker,
        },
        {
          'x': -24,
          'y': 5,
          'z': 25,
          events: this.criticalevent
        },
        {
          'x': -4,
          'y': 17,
          'z': 4,
          color: this.blueDataColor,
          marker: this.blueDataMarker
        },
        // {
        //   "x": -12,
        //   "y": -30,
        //   "z": 15,
        //   color: this.blueDataColor,
        //   marker: this.blueDataMarker
        // },
        /* {
          "x": -16,
          "y": 24,
          "z": 19,
          color: this.blueDataColor,
          marker: this.blueDataMarker
        }, */
        // {
        //   "x": -22,
        //   "y": -24,
        //   "z": 11,
        //   color: this.blueDataColor,
        //   marker: this.blueDataMarker
        // },
        {
          'x': -20,
          'y': -4,
          'z': 10,
          color: this.blueDataColor,
          marker: this.blueDataMarker
        },
        // {
        //   "x": -27,
        //   "y": -4,
        //   "z": 6,
        //   color: this.blueDataColor,
        //   marker: this.blueDataMarker
        // },
        {
          'x': -20,
          'y': 6,
          'z': 12,
          color: this.blueDataColor,
          marker: this.blueDataMarker
        },
        /*  {
           "x": -7,
           "y": -10,
           "z": 1
         }, */
        // {
        //   "x": -7,
        //   "y": 34,
        //   "z": 8,
        //   color: this.blueDataColor,
        //   marker: this.blueDataMarker
        // },
        {
          'x': -2,
          'y': -4,
          'z': 24,
          color: this.blueDataColor,
          marker: this.blueDataMarker
        },
        {
          'x': -16,
          'y': 14,
          'z': 9,
          color: this.blueDataColor,
          marker: this.blueDataMarker
        },
        /* {
          "x": -8,
          "y": -23,
          "z": 1
        }, */
        {
          'x': -11,
          'y': 14,
          'z': 14,
          color: this.blueDataColor,
          marker: this.blueDataMarker
        },
        /*  {
           "x": -16,
           "y": -5,
           "z": 6,
           color: this.blueDataColor,
           marker: this.blueDataMarker
         }, */
        {
          'x': -18,
          'y': 29,
          'z': 6,
          color: this.blueDataColor,
          marker: this.blueDataMarker
        },
        {
          'x': -16,
          'y': -4,
          'z': 6,
          color: this.blueDataColor,
          marker: this.blueDataMarker
        },
        {
          'x': -20,
          'y': 20,
          'z': 23,
          color: this.blueDataColor,
          marker: this.blueDataMarker
        },
        /*  {
           "x": -5,
           "y": -14,
           "z": 14
         }, */
        {
          'x': -5,
          'y': 32,
          'z': 6,
          color: this.blueDataColor,
          marker: this.blueDataMarker
        },
        /* {
          "x": -4,
          "y": 10,
          "z": 6,
          color: this.blueDataColor,
          marker: this.blueDataMarker
        }, */
        {
          'x': -23,
          'y': 16,
          'z': 1.5,
          color: this.blueDataColor,
          marker: this.blueDataMarker
        },
        {
          'x': -13,
          'y': 1,
          'z': 22,
          events: this.criticalevent
        },
        /*  {
           "x": -11,
           "y": -14,
           "z": 18
         }, */
        {
          'x': -7,
          'y': 25,
          'z': 15,
           events: this.criticalevent
        },
        /* {
          "x": -9,
          "y": -43,
          "z": 19
         }, */
        {
          'x': -7,
          'y': 6,
          'z': 10,
           events: this.criticalevent
        }
      ]
    },



    ],

  });

  getPlotData() {

    let i;
    let alterNate = true;
    let alterNateY1 = true;
    let alterNateY2 = true;
    for (i = 0; i < 50; i++) {
      if (alterNate) {
        this.dataOne.push({
          x: Math.floor((Math.random() * 40) + 2),
          y: alterNateY1 ? Math.floor((Math.random() * 50) + 1) : -Math.abs(Math.floor((Math.random() * 50) + 1)),
          z: Math.floor((Math.random() * 25) + 1),

        });
        alterNateY1 = !alterNateY1;
      } else {
        this.dataTwo.push({
          x: -Math.abs(Math.floor((Math.random() * 40) + 2)),
          y: alterNateY2 ? Math.floor((Math.random() * 50) + 1) : -Math.abs(Math.floor((Math.random() * 50) + 1)),
          z: Math.floor((Math.random() * 25) + 1),

        });
        alterNateY2 = !alterNateY2;
      }
      alterNate = !alterNate;

    }
  }

  ngOnInit() {
    this._automationService.emitViewChange(1);
    this._automationService.emitCountChange(4);
  }
}

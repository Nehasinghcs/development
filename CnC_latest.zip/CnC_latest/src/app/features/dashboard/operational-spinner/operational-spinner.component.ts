import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operational-spinner',
  templateUrl: '../../../shared/spinner/spinner.component.html',
  styleUrls: ['../../../shared/spinner/spinner.component.scss', './operational-spinner.component.scss']
})
export class OperationalSpinnerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

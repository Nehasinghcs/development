import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-dashboard-area',
    template: `
    <app-operationalview></app-operationalview>
    <app-operationalfooter></app-operationalfooter>
    `
})

export class DashboardAreaComponent implements OnInit {
    ngOnInit(): void {
    }

}

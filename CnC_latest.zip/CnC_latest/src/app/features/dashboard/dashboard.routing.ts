import { Routes, RouterModule } from '@angular/router';
import { CriticalticketsComponent } from './tickets/criticaltickets/criticaltickets.component';
import { NotificationlistComponent } from './notifications/notificationlist/notificationlist.component';
import { HotspotviewComponent } from './hotspots/hotspotview/hotspotview.component';
import { AnalysisviewComponent } from './analysis/analysisview/analysisview.component';
import { ProcesssnapshotComponent } from './summary/processsnapshot/processsnapshot.component';
import { TicketsummaryComponent } from './summary/ticketsummary/ticketsummary.component';
import { ContinentalComponent } from './hotspots/continental/continental.component';
import { TicketmetricsComponent } from './ticketmetrics/ticketmetrics.component';
import { SlabreachesComponent } from './summary/slabreaches/slabreaches.component';
import { FullviewComponent } from './hotspots/continental/fullview/fullview.component';
import { AfricaComponent } from './hotspots/continental/africa/africa.component';
import { NamericaComponent } from './hotspots/continental/namerica/namerica.component';
import { AustraliaComponent } from './hotspots/continental/australia/australia.component';
import { SamericaComponent } from './hotspots/continental/samerica/samerica.component';
import { AsiaComponent } from './hotspots/continental/asia/asia.component';
import { EuropeComponent } from './hotspots/continental/europe/europe.component';
import { CriticalprocessComponent } from './processview/criticalprocess/criticalprocess.component';
import { CriticalprocessOffComponent } from './processview/criticalprocess/criticalprocess-off/criticalprocess-off.component';
import { CriticalprocessOnComponent } from './processview/criticalprocess/criticalprocess-on/criticalprocess-on.component';
import { WorkForceComponent } from './workforce/workforce.component';
import { AutomationviewComponent } from './automationview/automationview.component';
import { AllaccountsComponent } from './automationview/allaccounts/allaccounts.component';
import { AccountComponent } from './automationview/account/account.component';
import { HealthComponent } from './workforce/health/health.component';
import { UtilizationComponent } from './workforce/utilization/utilization.component';
import { RobotdeatailsComponent } from './workforce/robotdeatails/robotdeatails.component';
import { DragwidgetsComponent } from './dragwidgets/dragwidgets.component';
import { CustomizewidgetsComponent } from './customizewidgets/customizewidgets.component';
import { AutomationdetailsComponent } from './processview/automationdetails/automationdetails.component';
import { processGroupDetailComponent } from './processview/automationdetails/processGroupDetail/processGroupDetail.component';
import { ProcessDetailComponent } from './processview/automationdetails/processDetail/processDetail.component';
import { DashboardAreaComponent } from './dashboardarea.component';
import { DashboardComponent } from './dashboard.component';

const dashboard_routes: Routes = [
    {
        path: '', component: DashboardComponent,
        children: [{ path: '', redirectTo: '/root/dashboard/view', pathMatch: 'full' },
        {
            path: 'view', component: DashboardAreaComponent,
            children: [
                { path: '', redirectTo: '/root/dashboard/view/processview', pathMatch: 'full' },
                {
                    path: 'processview', component: CriticalprocessComponent, children: [
                        { path: '', redirectTo: '/root/dashboard/view/processview/on', pathMatch: 'full' },
                        { path: 'on', component: CriticalprocessOnComponent, pathMatch: 'full' },
                        { path: 'off', component: CriticalprocessOffComponent, pathMatch: 'full' }
                    ]
                },
                { path: 'drag', component: DragwidgetsComponent, pathMatch: 'full' },
                { path: 'criticaltickets', component: CriticalticketsComponent, pathMatch: 'full' },
                {
                    path: 'automation', component: AutomationdetailsComponent, children: [
                        { path: '', redirectTo: '/root/dashboard/view/automation/groupdetail', pathMatch: 'full' },
                        { path: 'groupdetail', component: processGroupDetailComponent, pathMatch: 'full' },
                        { path: 'process', component: ProcessDetailComponent, pathMatch: 'full' }
                    ]
                },
                { path: 'notifications', component: NotificationlistComponent, pathMatch: 'full' },
                {
                    path: 'hotspots', component: ContinentalComponent, children: [
                        { path: '', redirectTo: '/root/dashboard/view/hotspots/fullview', pathMatch: 'full' },
                        { path: 'europe', component: EuropeComponent, pathMatch: 'full' },
                        { path: 'fullview', component: FullviewComponent, pathMatch: 'full' },
                        { path: 'namerica', component: NamericaComponent, pathMatch: 'full' },
                        { path: 'samerica', component: SamericaComponent, pathMatch: 'full' },
                        { path: 'africa', component: AfricaComponent, pathMatch: 'full' },
                        { path: 'asia', component: AsiaComponent, pathMatch: 'full' },
                        { path: 'australia', component: AustraliaComponent, pathMatch: 'full' }
                    ]
                },
                { path: 'hotspotsview', component: HotspotviewComponent, pathMatch: 'full' },
                { path: 'analysis', component: AnalysisviewComponent, pathMatch: 'full' },
                {
                    path: 'workforce', component: WorkForceComponent, children: [
                        { path: '', redirectTo: '/root/dashboard/view/workforce/health', pathMatch: 'full' },
                        { path: 'health', component: HealthComponent, pathMatch: 'full' },
                        { path: 'utilization', component: UtilizationComponent, pathMatch: 'full' },
                        { path: 'robot', component: RobotdeatailsComponent, pathMatch: 'full' }
                    ]
                },
                {
                    path: 'automationview', component: AutomationviewComponent, children: [
                        { path: '', redirectTo: '/root/dashboard/view/automationview/allaccounts', pathMatch: 'full' },
                        { path: 'allaccounts', component: AllaccountsComponent, pathMatch: 'full' },
                        { path: 'account', component: AccountComponent, pathMatch: 'full' }
                    ]
                },
                { path: 'ticketmetrics', component: TicketmetricsComponent, pathMatch: 'full' }]
        }, {
            path: 'summary', children: [
                { path: '', redirectTo: '/root/dashboard/summary/processnnapshot', pathMatch: 'full' },
                { path: 'processnnapshot', component: ProcesssnapshotComponent, pathMatch: 'full' },
                { path: 'ticketsummary', component: TicketsummaryComponent, pathMatch: 'full' },
                { path: 'slabreaches', component: SlabreachesComponent, pathMatch: 'full' }]
        }, {
            path: 'widgets', component: CustomizewidgetsComponent
        }]
    }
];
export const dashboardrouting = RouterModule.forChild(dashboard_routes);

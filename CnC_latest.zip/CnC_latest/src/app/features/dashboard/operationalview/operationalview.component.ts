import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { ISubscription } from 'rxjs/Subscription';
import { SharedService } from '../../../../services/shared.service';

@Component({
  selector: 'app-operationalview',
  templateUrl: './operationalview.component.html',
  styleUrls: ['./operationalview.component.scss']
})
export class OperationalviewComponent implements OnInit, OnDestroy {

  showFullScreen = false;
  showOperationalSpinner = false;
  subscription_1: ISubscription;
  subscription_2: ISubscription;

  constructor(private _router: Router, private _sharedService: SharedService) {
    this.subscription_1 = this._sharedService.changeViewSizeEmitted.subscribe(value => {
      setTimeout(() => this.showFullScreen = value, 0);
    });
    this.subscription_2 = this._sharedService.changeOperationalSpinnerEmitted.subscribe(value => {
      setTimeout(() => this.showOperationalSpinner = value, 0);
    });
  }

  ngOnDestroy(): void {
    this.subscription_1.unsubscribe();
    this.subscription_2.unsubscribe();
  }

  dragenterEvent() {
    this._router.navigateByUrl('root/dashboard/view/drag');
  }

  addDropItem() {
  }

  ngOnInit() {
  }

}

import { Exception } from '../../../../class/operationalClasses/exception';

export class ExceptionAnalysis {
    exception: Exception;
    selected: boolean;
    constructor() {
        this.exception = new Exception();
    }
}

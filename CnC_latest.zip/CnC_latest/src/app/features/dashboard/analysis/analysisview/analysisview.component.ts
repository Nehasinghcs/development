import { Component, OnInit } from '@angular/core';
import { ExceptionAnalysysService } from '../exceptionanalysis.service';
import { ExceptionAnalysis } from './exceptionanalysis';
import { ToasterService } from 'angular2-toaster/src/toaster.service';
import { Router } from '@angular/router';
import { Exception } from '../../../../class/operationalClasses/exception';
import { UtilityService } from '../../../../utility/utility.services';
import { SharedService } from '../../../../../services/shared.service';
import { Constants } from '../../../../utility/app.constants';

@Component({
  selector: 'app-analysisview',
  templateUrl: './analysisview.component.html',
  styleUrls: ['./analysisview.component.scss']
})
export class AnalysisviewComponent implements OnInit {

  exceptionList: Exception[];
  exceptionAnalysisList: ExceptionAnalysis[];
  // selectedException: ExceptionAnalysis;
  selectedException: any;
  constructor(private _router: Router, private _utilityService: UtilityService, private _toasterService: ToasterService, private _exceptionAnalysysService: ExceptionAnalysysService, private _sharedService: SharedService) { }

  getWidth(type: string) {
    if (this.selectedException !== undefined) {
      const totalBusExce = this.exceptionAnalysisList.filter(element => element.exception.exceptionType.toLowerCase() === Constants.exceptionType_business).length;
      const totalCodeExce = this.exceptionAnalysisList.filter(element => element.exception.exceptionType.toLowerCase() === Constants.exceptionType_code).length;
      const totalInfraExce = this.exceptionAnalysisList.filter(element => element.exception.exceptionType.toLowerCase() === Constants.exceptionType_Infrastructure).length;
      let returnValue;
      switch (type.toLowerCase()) {
        case Constants.exceptionType_business:
          returnValue = ((totalBusExce / this.exceptionAnalysisList.length) * 100).toFixed(2);
          break;
        case Constants.exceptionType_code:
          returnValue = ((totalCodeExce / this.exceptionAnalysisList.length) * 100).toFixed(2);
          break;
        case Constants.exceptionType_Infrastructure:
          returnValue = ((totalInfraExce / this.exceptionAnalysisList.length) * 100).toFixed(2);
          break;
      }
      return returnValue;
    }
  }

  getFullScreenParameter() {
    return this._sharedService.showFullScreen;
  }

  selectNewException(item) {
    item.selected = true;
    this.selectedException = item;
    this.exceptionAnalysisList.forEach(element => {
      if (element.exception.id !== item.exception.id) {
        element.selected = false;
      }
    });
  }

  changeViewSize() {
    this._sharedService.emitViewSizeChange(!this._sharedService.showFullScreen);
  }

  ngOnInit() {
    this._sharedService.emitWidgetChange(this._sharedService.currentView, 4);
    this._sharedService.emitViewChange(4);
    if (this._sharedService.exceptionList !== undefined) {
      this.exceptionList = this._sharedService.exceptionList;
      this.exceptionAnalysisList = this._exceptionAnalysysService.prepareExceptionAnalysisList(this.exceptionList);
      this.selectedException = this.exceptionAnalysisList[0];
      this.selectedException.selected = true;
    } else {
      this._exceptionAnalysysService.getAlertDetail().subscribe(response => {
        this.exceptionList = this._exceptionAnalysysService.prepareExceptionList(response.logDetails);
        this._sharedService.exceptionList = this.exceptionList;
        this.exceptionAnalysisList = this._exceptionAnalysysService.prepareExceptionAnalysisList(response.logDetails);
        this.selectedException = this.exceptionAnalysisList[0];
        this.selectedException.selected = true;
      }, (error) => {
        this._utilityService.handleException(error);
      });
    }

  }

}

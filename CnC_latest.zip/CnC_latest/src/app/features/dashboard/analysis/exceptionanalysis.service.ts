import { Injectable } from '@angular/core';
import { ExceptionAnalysis } from './analysisview/exceptionanalysis';
import { DataService } from '../../../../services/data.services';
import { UtilityService } from '../../../utility/utility.services';
import { Exception } from '../../../class/operationalClasses/exception';
import { AppSettings } from '../../../utility/app.settings';

@Injectable()

export class ExceptionAnalysysService {
    constructor(private _dataService: DataService, private _utilityService: UtilityService) {
    }

    prepareExceptionAnalysisList(list) {
        // let exceptionAnalysisList = new Array<ExceptionAnalysis>();
        let exceptionAnalysisList = new Array<any>();
        /* list.forEach(element => {
             let _exceptionAnalysis: ExceptionAnalysis = new ExceptionAnalysis();
             _exceptionAnalysis.exception.id = element.id;
             _exceptionAnalysis.exception.accountId = element.accountId;
             _exceptionAnalysis.exception.businessProcessId = element.businessProcessId;
             _exceptionAnalysis.exception.category = element.category;
             _exceptionAnalysis.exception.controllerId = element.controllerId;
             _exceptionAnalysis.exception.exceptionType = element.exceptionType;
             _exceptionAnalysis.exception.inputType = element.inputtype;
             _exceptionAnalysis.exception.locationId = element.locationId;
             _exceptionAnalysis.exception.logType = element.logType;
             _exceptionAnalysis.exception.loggedOn = new Date(element.loggedOn);
             _exceptionAnalysis.exception.message = element.message;
             _exceptionAnalysis.exception.robotId = element.robotId;
             _exceptionAnalysis.exception.source = element.source;
             _exceptionAnalysis.exception.subCategory = element.subCategory;
             _exceptionAnalysis.exception.verticalId = element.verticalId;
             _exceptionAnalysis.selected = false;
             if (_exceptionAnalysis.exception.exceptionType !== "null") {
                 exceptionAnalysisList.push(_exceptionAnalysis);
             }
         });*/

        exceptionAnalysisList = [
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v2',
                    'time': '1:57AM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '2',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Robots Disconnected',
                    'robotId': '3',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Robots Disconnected ',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Robots Disconnected - VDI-KHT-109 is disconnected from AA Control Room',
                    'processaffected': 'Credit management',
                    'cause': 'Underlying element in application may have been renamed or deleted, script may be still using the old name',
                    'resolution': 'Your session might have expired. login into Control Room to renew your session',
                    'processname': 'B2B collections',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v1',
                    'time': '12.40AM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '1',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Unable to match any windows with the query term',
                    'robotId': '2',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Process Failed',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Unable to match any windows with the query term',
                    'processaffected': 'Invoicing',
                    'cause': 'Underlying element in application may have been renamed or deleted, script may be still using the old name',
                    'resolution': 'Please check whether any new version of application is deployed and update the script',
                    'processname': 'Invoicing',
                    'location': 'North America',
                    'selected': false
                }
            },

            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v3',
                    'time': '12:17AM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '3',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Cannot find window or application titled \'Vatbook.xlx\'',
                    'robotId': '4',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Validation exception',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Validation exception -Cannot find window or application titled \'Vatbook.xlx\'',
                    'processaffected': 'Accounts Receivable',
                    'cause': 'An error occurred at line number 2 of the task \'Prompt.atmx\'',
                    'resolution': 'Please open the task in the Task Editor to view the action at line number 2',
                    'processname': 'Accounts Receivable',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v4',
                    'time': '11.58PM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '4',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Automation is unable to handle the data input into the process',
                    'robotId': '5',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Automation abandoned',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Automation abandoned - Automation is unable to handle the data input into the process',
                    'processaffected': 'Accounts Receivable',
                    'cause': 'Automation is unable to handle the data input into the process. Automation abandoned',
                    'resolution': 'Restart the automation script. Download the exception details and fix the automation script to handle data input exception for long term resolution. ',
                    'processname': 'B2B collections',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v5',
                    'time': '11.49PM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '5',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Unable to connect to ERP system for processing data',
                    'robotId': '6',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'ERP System Unavailable',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Unable to match any windows with the query term',
                    'processaffected': 'Billing and invoicing',
                    'cause': 'Unable to connect to ERP system for processing data',
                    'resolution': 'Please check whether ERP system are still available. Contact Helpdesk',
                    'processname': 'Billing and invoicing',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v1',
                    'time': '11:24PM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '1',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Unable to match any windows with the query term',
                    'robotId': '2',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Process Failed',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Unable to match any windows with the query term',
                    'processaffected': 'Invoicing',
                    'cause': 'Underlying element in application may have been renamed or deleted, script may be still using the old name',
                    'resolution': 'Please check whether any new version of application is deployed and update the script',
                    'processname': 'Accounts Receivable',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v2',
                    'time': '11:20PM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '2',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Robots Disconnected',
                    'robotId': '3',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Robots Disconnected ',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Robots Disconnected - Robot is disconnected from AA Control Room',
                    'processaffected': 'Credit management',
                    'cause': 'Underlying element in application may have been renamed or deleted, script may be still using the old name',
                    'resolution': 'Your session might have expired. login into Control Room to renew your session',
                    'processname': 'B2B collections',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v3',
                    'time': '10.00PM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '3',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Cannot find window or application titled \'Vatbook.xlx\'',
                    'robotId': '4',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Validation exception',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Validation exception -Cannot find window or application titled \'Vatbook.xlx\'',
                    'processaffected': 'Credit Management',
                    'cause': 'An error occurred at line number 2 of the task \'Prompt.atmx\'',
                    'resolution': 'Please open the task in the Task Editor to view the action at line number 2',
                    'processname': 'Credit Management',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v4',
                    'time': '7.00PM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '4',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Automation is unable to handle the data input into the process',
                    'robotId': '5',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Automation abandoned',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Automation abandoned - Automation is unable to handle the data input into the process',
                    'processaffected': 'Credit Management',
                    'cause': 'Automation is unable to handle the data input into the process. Automation abandoned',
                    'resolution': 'Restart the automation script. Download the exception details and fix the automation script to handle data input exception for long term resolution. ',
                    'processname': 'B2B collections',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v5',
                    'time': '4.00PM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '5',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Unable to connect to ERP system for processing data',
                    'robotId': '6',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'ERP System Unavailable',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Unable to match any windows with the query term',
                    'processaffected': 'Billing and invoicing',
                    'cause': 'Unable to connect to ERP system for processing data',
                    'resolution': 'Please check whether ERP system are still available. Contact Helpdesk',
                    'processname': 'Credit Management',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v1',
                    'time': '3.40PM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '1',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Unable to match any windows with the query term',
                    'robotId': '2',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Process Failed',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Unable to match any windows with the query term',
                    'processaffected': 'Invoicing',
                    'cause': 'Underlying element in application may have been renamed or deleted, script may be still using the old name',
                    'resolution': 'Please check whether any new version of application is deployed and update the script',
                    'processname': 'Credit Management',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v2',
                    'time': '2.45PM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '2',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Robots Disconnected',
                    'robotId': '3',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Robots Disconnected ',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Robots Disconnected - Robot is disconnected from AA Control Room',
                    'processaffected': 'Credit management',
                    'cause': 'Underlying element in application may have been renamed or deleted, script may be still using the old name',
                    'resolution': 'Your session might have expired. login into Control Room to renew your session',
                    'processname': 'B2B collections',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v3',
                    'time': '2.45PM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '3',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Cannot find window or application titled \'Vatbook.xlx\'',
                    'robotId': '4',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Validation exception',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Validation exception -Cannot find window or application titled \'Vatbook.xlx\'',
                    'processaffected': 'Credit Management',
                    'cause': 'An error occurred at line number 2 of the task \'Prompt.atmx\'',
                    'resolution': 'Please open the task in the Task Editor to view the action at line number 2',
                    'processname': 'Credit Management',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v1',
                    'time': '1.35PM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '1',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Unable to match any windows with the query term',
                    'robotId': '2',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Process Failed',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Unable to match any windows with the query term',
                    'processaffected': 'Invoicing',
                    'cause': 'Underlying element in application may have been renamed or deleted, script may be still using the old name',
                    'resolution': 'Please check whether any new version of application is deployed and update the script',
                    'processname': 'Credit Management',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v2',
                    'time': '12.45PM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '2',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Robots Disconnected',
                    'robotId': '3',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Robots Disconnected ',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Robots Disconnected - Robot is disconnected from AA Control Room',
                    'processaffected': 'Credit management',
                    'cause': 'Underlying element in application may have been renamed or deleted, script may be still using the old name',
                    'resolution': 'Your session might have expired. login into Control Room to renew your session',
                    'processname': 'B2B collections',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v3',
                    'time': '4.55PM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '3',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Cannot find window or application titled \'Vatbook.xlx\'',
                    'robotId': '4',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Validation exception',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Validation exception -Cannot find window or application titled \'Vatbook.xlx\'',
                    'processaffected': 'Credit Management',
                    'cause': 'An error occurred at line number 2 of the task \'Prompt.atmx\'',
                    'resolution': 'Please open the task in the Task Editor to view the action at line number 2',
                    'processname': 'Credit Management',
                    'location': 'North America',
                    'selected': false
                },
            }, {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v1',
                    'time': '1.45PM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '1',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Unable to match any windows with the query term',
                    'robotId': '2',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Process Failed',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Unable to match any windows with the query term',
                    'processaffected': 'Invoicing',
                    'cause': 'Underlying element in application may have been renamed or deleted, script may be still using the old name',
                    'resolution': 'Please check whether any new version of application is deployed and update the script',
                    'processname': 'Credit Management',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v2',
                    'time': '9.45PM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '2',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Robots Disconnected',
                    'robotId': '3',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Robots Disconnected ',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Robots Disconnected - Robot is disconnected from AA Control Room',
                    'processaffected': 'Credit management',
                    'cause': 'Underlying element in application may have been renamed or deleted, script may be still using the old name',
                    'resolution': 'Your session might have expired. login into Control Room to renew your session',
                    'processname': 'B2B collections',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v3',
                    'time': '9.00AM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '3',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Cannot find window or application titled \'Vatbook.xlx\'',
                    'robotId': '4',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Validation exception',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Validation exception -Cannot find window or application titled \'Vatbook.xlx\'',
                    'processaffected': 'Credit Management',
                    'cause': 'An error occurred at line number 2 of the task \'Prompt.atmx\'',
                    'resolution': 'Please open the task in the Task Editor to view the action at line number 2',
                    'processname': 'Credit Management',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v4',
                    'time': '9.10AM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '4',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Automation is unable to handle the data input into the process',
                    'robotId': '5',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Automation abandoned',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Automation abandoned - Automation is unable to handle the data input into the process',
                    'processaffected': 'Credit Management',
                    'cause': 'Automation is unable to handle the data input into the process. Automation abandoned',
                    'resolution': 'Restart the automation script. Download the exception details and fix the automation script to handle data input exception for long term resolution. ',
                    'processname': 'B2B collections',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v5',
                    'time': '9.40AM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '5',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Unable to connect to ERP system for processing data',
                    'robotId': '6',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'ERP System Unavailable',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Unable to match any windows with the query term',
                    'processaffected': 'Billing and invoicing',
                    'cause': 'Unable to connect to ERP system for processing data',
                    'resolution': 'Please check whether ERP system are still available. Contact Helpdesk',
                    'processname': 'Credit Management',
                    'location': 'North America',
                    'selected': false
                }
            }, {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v1',
                    'time': '9.50AM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '1',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Unable to match any windows with the query term',
                    'robotId': '2',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Process Failed',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Unable to match any windows with the query term',
                    'processaffected': 'Invoicing',
                    'cause': 'Underlying element in application may have been renamed or deleted, script may be still using the old name',
                    'resolution': 'Please check whether any new version of application is deployed and update the script',
                    'processname': 'Credit Management',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v2',
                    'time': '9.25AM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '2',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Robots Disconnected',
                    'robotId': '3',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Robots Disconnected ',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Robots Disconnected - Robot is disconnected from AA Control Room',
                    'processaffected': 'Credit management',
                    'cause': 'Underlying element in application may have been renamed or deleted, script may be still using the old name',
                    'resolution': 'Your session might have expired. login into Control Room to renew your session',
                    'processname': 'B2B collections',
                    'location': 'North America',
                    'selected': false
                }
            },
            {
                'exception': {
                    'id': 'AWDGefucp0MqbTyoOZ8v3',
                    'time': '9.00AM',
                    'accountId': 'AV_i_Ky6YclInxwaTAYh',
                    'businessProcessId': '3',
                    'category': 'Robot',
                    'controllerId': 'AV_8QlDW1Pc_iwuBW58K',
                    'exceptionType': 'Business',
                    'locationId': '1',
                    'logType': 'warning',
                    'loggedOn': '2017-12-19T11:27:28.783Z',
                    'message': 'Cannot find window or application titled \'Vatbook.xlx\'',
                    'robotId': '4',
                    'source': 'Controller : TestAAController - Robot ID : 1',
                    'subCategory': 'Validation exception',
                    'verticalId': 'AV_incRfYclInxwaS8SB',
                    'summary': 'Validation exception -Cannot find window or application titled \'Vatbook.xlx\'',
                    'processaffected': 'Credit Management',
                    'cause': 'An error occurred at line number 2 of the task \'Prompt.atmx\'',
                    'resolution': 'Please open the task in the Task Editor to view the action at line number 2',
                    'processname': 'Credit Management',
                    'location': 'North America',
                    'selected': false
                },
            },

        ];
        return exceptionAnalysisList;
    }

    prepareExceptionList(list) {
        const exceptionList = new Array<Exception>();
        list.forEach(element => {
            const _exception: Exception = new Exception();
            _exception.id = element.id;
            _exception.accountId = element.accountId;
            _exception.businessProcessId = element.businessProcessId;
            _exception.category = element.category;
            _exception.controllerId = element.controllerId;
            _exception.exceptionType = element.exceptionType;
            _exception.inputType = element.inputtype;
            _exception.locationId = element.locationId;
            _exception.logType = element.logType;
            _exception.loggedOn = new Date(element.loggedOn);
            _exception.message = element.message;
            _exception.robotId = element.robotId;
            _exception.source = element.source;
            _exception.subCategory = element.subCategory;
            _exception.verticalId = element.verticalId;
            exceptionList.push(_exception);
        });
        return exceptionList;
    }

    getAlertDetail() {
        const reqData = {
            dateRange: [
                {
                    startDate: this._utilityService.getPreviousDayMonth(),
                    endDate: this._utilityService.getPreviousDayMonth()
                }
            ],
            'pageNumber': 0,
            'pageSize': 10,
           /* "processIds": [
                "2"
            ],
            "status": [
                "Active"
            ],
            "type": [
                "error"
            ]*/
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_ALERTDETAIL, reqData);
    }
}

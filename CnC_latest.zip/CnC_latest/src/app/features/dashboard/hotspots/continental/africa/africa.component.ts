import { Component, OnInit } from '@angular/core';
import { ContinentalService } from '../continental.service';
import { Constants } from '../../../../../utility/app.constants';

@Component({
  selector: 'app-africa',
  templateUrl: './africa.component.html',
  styleUrls: ['./africa.component.scss']
})
export class AfricaComponent implements OnInit {
  from;
  mapdata: any;
  constructor(private _continentalService: ContinentalService) { }

  ngOnInit() {
    this.from = 'From Africa';
    this._continentalService.emitViewChange(4);
    this._continentalService.getDataFromJSON(Constants.africa_map_jsonName).subscribe(response => {
      this.mapdata = response;
    });
  }

}

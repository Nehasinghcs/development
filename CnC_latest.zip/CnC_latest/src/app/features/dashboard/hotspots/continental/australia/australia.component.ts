import { Component, OnInit } from '@angular/core';
import { ContinentalService } from '../continental.service';
import { Constants } from '../../../../../utility/app.constants';

@Component({
  selector: 'app-australia',
  templateUrl: './australia.component.html',
  styleUrls: ['./australia.component.scss']
})
export class AustraliaComponent implements OnInit {

  from;
  mapdata: any;
  constructor(private _continentalService: ContinentalService) { }

  ngOnInit() {
    this.from = 'From Australia';
    this._continentalService.emitViewChange(6);
    this._continentalService.getDataFromJSON(Constants.australia_map_jsonName).subscribe(response => {
      this.mapdata = response;
    });
  }

}

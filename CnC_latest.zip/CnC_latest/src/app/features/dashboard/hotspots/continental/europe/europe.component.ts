import { Component, OnInit } from '@angular/core';
import { ContinentalService } from '../continental.service';
import { Constants } from '../../../../../utility/app.constants';

@Component({
  selector: 'app-europe',
  templateUrl: './europe.component.html',
  styleUrls: ['./europe.component.scss']
})
export class EuropeComponent implements OnInit {

  from;
  mapdata: any;

  constructor(private _continentalService: ContinentalService) { }

  ngOnInit() {
    this.from = 'From Europe';
    this._continentalService.emitViewChange(1);
    this._continentalService.getDataFromJSON(Constants.europe_map_jsonName).subscribe(response => {
      this.mapdata = response;
    });
  }

}

import { Component, OnInit } from '@angular/core';
import { MapviewComponent } from '../mapview/mapview.component';
import { ContinentalService } from '../continental.service';
import { Constants } from '../../../../../utility/app.constants';

@Component({
  selector: 'app-fullview',
  templateUrl: './fullview.component.html',
  styleUrls: ['./fullview.component.scss'],
  providers: [MapviewComponent]
})
export class FullviewComponent implements OnInit {

  from;
  view: any;
  mapdata: any;

  constructor(private _continentalService: ContinentalService) { }

  ngOnInit() {
    this.from = 'From Full view';
    this.view = 'full';
    this._continentalService.emitViewChange(0);
    this._continentalService.getDataFromJSON(Constants.world_map_jsonName).subscribe(response => {
      this.mapdata = response;
    });
  }

}

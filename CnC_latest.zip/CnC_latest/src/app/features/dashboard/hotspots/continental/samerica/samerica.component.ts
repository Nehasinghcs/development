import { Component, OnInit } from '@angular/core';
import { ContinentalService } from '../continental.service';
import { Constants } from '../../../../../utility/app.constants';

@Component({
  selector: 'app-samerica',
  templateUrl: './samerica.component.html',
  styleUrls: ['./samerica.component.scss']
})
export class SamericaComponent implements OnInit {

  from;
  mapdata: any;

  constructor(private _continentalService: ContinentalService) { }

  ngOnInit() {
    this.from = 'From South America';
    this._continentalService.emitViewChange(3);
    this._continentalService.getDataFromJSON(Constants.samerica_map_jsonName).subscribe(response => {
      this.mapdata = response;
    });
  }

}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ContinentalService } from './continental.service';
import { WidgetService } from '../../../../../services/widget.service';
import { SharedService } from '../../../../../services/shared.service';

@Component({
    selector: 'app-continental',
    templateUrl: './continental.component.html',
    styleUrls: ['./continental.component.scss']
})
export class ContinentalComponent implements OnInit {

    selectedComponent = 0;

    constructor(private _widgetService: WidgetService, private _continentalService: ContinentalService, private _router: Router, private _sharedService: SharedService) {
        this._continentalService.changeViewEmitted.subscribe(response => {
            setTimeout(() => this.selectedComponent = response, 0);
        });
    }

    goToMapView(pageValue) {
        switch (pageValue) {
            case 0:
                this._router.navigateByUrl('root/dashboard/view/hotspots/fullview');
                break;
            case 1:
                this._router.navigateByUrl('root/dashboard/view/hotspots/europe');
                break;
            case 2:
                this._router.navigateByUrl('root/dashboard/view/hotspots/namerica');
                break;
            case 3:
                this._router.navigateByUrl('root/dashboard/view/hotspots/samerica');
                break;
            case 4:
                this._router.navigateByUrl('root/dashboard/view/hotspots/africa');
                break;
            case 5:
                this._router.navigateByUrl('root/dashboard/view/hotspots/asia');
                break;
            case 6:
                this._router.navigateByUrl('root/dashboard/view/hotspots/australia');
        }
    }

    getFullScreenParameter() {
        return this._sharedService.showFullScreen;
    }

    changeViewSize() {
        this._sharedService.emitViewSizeChange(!this._sharedService.showFullScreen);
    }

    ngOnInit() {
        this._sharedService.emitWidgetChange(this._sharedService.currentView, 6);
        this._sharedService.emitViewChange(6);
    }

}

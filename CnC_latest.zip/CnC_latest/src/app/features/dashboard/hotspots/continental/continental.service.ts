import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { DataService } from '../../../../../services/data.services';

@Injectable()

export class ContinentalService {

    constructor(private _DataService: DataService) { }

    private _emitContinentalViewChange = new Subject<number>();
    changeViewEmitted = this._emitContinentalViewChange.asObservable();
    emitViewChange(change: number) {
        this._emitContinentalViewChange.next(change);
    }

    getDataFromJSON(map) {
        return this._DataService.getDataFromJSON(map);
    }
}

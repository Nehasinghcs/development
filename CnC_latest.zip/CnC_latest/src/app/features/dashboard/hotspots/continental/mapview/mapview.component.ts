import { Component, OnInit, Input } from '@angular/core';
import { Chart, MapChart } from 'angular-highcharts';
import { Router } from '@angular/router';
declare var require: any;
const Highcharts = require('highcharts');
require('highcharts/highcharts-more')(Highcharts);
require('highcharts/modules/solid-gauge')(Highcharts);
require('highcharts/modules/map')(Highcharts);
require('highcharts/modules/data')(Highcharts);

@Component({
  selector: 'app-mapview',
  templateUrl: './mapview.component.html',
  styleUrls: ['./mapview.component.scss']
})
export class MapviewComponent implements OnInit {

  fromPage: any;
  fromview: string;
  @Input() from: any;
  @Input() view: any;
  @Input() mapdata: any;
  mapChart: any;

  labelFormatOn: any = {
    enabled: true,
    color: '#394961',
    format: '{point.name} Critical',
    textOutline: 0,
    style: {
      // fontWeight: 'bold',
      // fontSize: 15,
      fontSize: 14,
      fontWeight: 600,
      fontFamily: 'OpenSans-Semibold',
      color: '#394961',
      fill: '#394961',
      textOutline: 0
    }
  };

  labelFormatOff: any = {
    enabled: true,
    color: '#394961',
    format: '{point.name}',
    textOutline: 0,
    style: {
      // fontWeight: 'bold',
      // fontSize: 15,
      fontSize: 14,
      fontWeight: 600,
      fontFamily: 'OpenSans-Semibold',
      color: '#394961',
      fill: '#394961',
      textOutline: 0
    }
  };

  constructor(private _router: Router) { }

  ngOnInit() {
    this.fromPage = this.from;
    this.fromview = this.view;

    this.mapChart = new MapChart({
      chart: {
        map: 'custom/world-continents',
        backgroundColor: 'transparent',
        height: this.fromview === 'snapshot' ? 100 : 340,
        width: this.fromview === 'snapshot' ? 220 : 930,
        margin: this.fromview === 'snapshot' ? [0, 0, 0, 0] : [25, 0, 0, 0],
        dataLabels: (this.fromview !== undefined) ? (this.fromview === 'snapshot' ? this.labelFormatOff : this.labelFormatOn ) : {enabled: false}
      },
      tooltip: {
        enabled: false
      },
      title: {
        text: ''
      },
      legend: {
        enabled: false
      },
      mapNavigation: {
        enabled: false,
      },
      colorAxis: {
        min: 0,
        stops: [
          [0, 'rgba(236, 60, 60, 0.4)']
        ]
      },
      plotOptions: {
        map: {
          allAreas: true,
          joinBy: ['iso-a2', 'code'],
          dataLabels: (this.fromview !== undefined) ? (this.fromview === 'snapshot' ? this.labelFormatOff : this.labelFormatOn ) : {enabled: false},
          tooltip: {
            enabled: false
          },
        },
        series: {
          point: {
            events: {
              click: function () {
                location.href = '#/dashboard/view/hotspotsview';
              }
            }
          },
          nullColor: {
            radialGradient: { cx: 0.4, cy: 0.3, r: 0.7 },
            stops: [
              [0, '#e5f4fa'],
              //  [0.5, '#ffffff'],
              [1, '#e1f2f9']
            ]
          },
          borderColor: '#00a0e7',
          borderWidth: (this.fromview !== undefined) ? (this.fromview === 'snapshot' ? 0.3 : 0.5 ) : 0.5,
        }
      },
      series: [{

        data: [
          { key: 'na', value: 18, borderColor: '#ff6686', borderWidth: this.fromview === 'snapshot' ? 0.25 : 1 }
        ],
        mapData: Highcharts.maps['custom/world-continents'] = this.mapdata,
        joinBy: ['hc-key', 'key'],
        name: 'Random data1',
        cursor: 'pointer',
        states: {
          hover: {
            borderWidth: 0.5,
            borderColor: '#ff6686',
          },
        },
        dataLabels: {
         // enabled: true,
          // textShadow: false
        },
      }]
    });
  }
}

import { Component, OnInit } from '@angular/core';
import { ContinentalService } from '../continental.service';
import { Constants } from '../../../../../utility/app.constants';

@Component({
  selector: 'app-asia',
  templateUrl: './asia.component.html',
  styleUrls: ['./asia.component.scss']
})
export class AsiaComponent implements OnInit {

  from;
  mapdata: any;
  constructor(private _continentalService: ContinentalService) { }

  ngOnInit() {
    this.from = 'From Asia';
    this._continentalService.emitViewChange(5);
    this._continentalService.getDataFromJSON(Constants.asia_map_jsonName).subscribe(response => {
      this.mapdata = response;
    });
  }

}

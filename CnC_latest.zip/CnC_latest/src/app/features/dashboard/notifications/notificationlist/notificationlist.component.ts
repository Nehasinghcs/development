import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NotificationsService } from '../notifications.service';
import { ExceptionAnalysysService } from '../../analysis/exceptionanalysis.service';
import * as moment from 'moment';
import { NotificationsClass } from '../../../../class/operationalClasses/notification';
import { UtilityService } from '../../../../utility/utility.services';
import { Exception } from '../../../../class/operationalClasses/exception';
import { SharedService } from '../../../../../services/shared.service';
import { Constants } from '../../../../utility/app.constants';

@Component({
  selector: 'app-notificationlist',
  templateUrl: './notificationlist.component.html',
  styleUrls: ['./notificationlist.component.scss']
})
export class NotificationlistComponent implements OnInit {

  notificationList: NotificationsClass[];
  selectedTool = 1;
  logType_error = Constants.logType_error;
  logType_warning = Constants.logType_warning;
  logType_info = Constants.logType_info;

  tools = [{
    id: 1,
    name: 'Exceptions'
  }, {
    id: 2,
    name: 'All'
  }];

  constructor(private _utilityService: UtilityService, private _exceptionAnalysysService: ExceptionAnalysysService, private _notificationsService: NotificationsService, private _router: Router, private _sharedService: SharedService) { }

  getCount(type) {
    if (this.notificationList !== undefined && this.notificationList.length) {
      return this.notificationList.filter(element => element.exception.logType.toLowerCase() === type).length;
    } else {
      return 0;
    }
  }

  getFullScreenParameter() {
    return this._sharedService.showFullScreen;
  }

  changeViewSize() {
    this._sharedService.emitViewSizeChange(!this._sharedService.showFullScreen);
  }

  mouseleave(item) {
    item.showActions = false;
  }
  mouseover(item) {
    item.showActions = true;
  }

  getNotificationMessage(item: Exception) {
    return this._notificationsService.getNotificationMessage(item);
  }

  displayLocalTime(item) {
    let dateString = new Date(item);
    dateString = new Date(dateString.getTime() + (dateString.getTimezoneOffset() * 60000));
    return moment(dateString).format('h:mm a');
  }

  ngOnInit() {
    this._sharedService.emitOperationalSpinnerChange(true);
    this._sharedService.emitWidgetChange(this._sharedService.currentView, 3);
    this._sharedService.emitViewChange(3);
    this._notificationsService.getAlertDetail().subscribe(response => {
      this.notificationList = this._notificationsService.prepareNotificationList(response.logDetails);
      this._sharedService.emitOperationalSpinnerChange(false);
    }, (error) => {
      this._sharedService.emitOperationalSpinnerChange(false);
      this._utilityService.handleException(error);
    });
  }

}

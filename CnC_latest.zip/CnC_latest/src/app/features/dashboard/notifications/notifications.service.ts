import { Injectable } from '@angular/core';
import { UtilityService } from '../../../utility/utility.services';
import { DataService } from '../../../../services/data.services';
import { Exception } from '../../../class/operationalClasses/exception';
import { NotificationsClass } from '../../../class/operationalClasses/notification';
import { Constants } from '../../../utility/app.constants';
import { AppSettings } from '../../../utility/app.settings';

@Injectable()

export class NotificationsService {

    logTypeError: string = Constants.logType_error.toLowerCase();
    logTypeInfo: string = Constants.logType_info.toLowerCase();
    logTypeWarning: string = Constants.logType_warning.toLowerCase();
    logTypeCategoryRobot: string = Constants.logTypeCategory_robot.toLowerCase();
    logTypeCategoryJob: string = Constants.logTypeCategory_job.toLowerCase();
    logTypeSubCategory_RobotDisconnected = Constants.logTypeSubCategory_errorRobotDisconnected.toLowerCase();
    logTypeSubCategory_RobotDeactivated = Constants.logTypeSubCategory_errorRobotDeactivated.toLowerCase();
    logTypeSubCategory_AutomationAbandoned = Constants.logTypeSubCategory_errorAutomationAbandoned.toLowerCase();
    logTypeSubCategory_AutomationStopped = Constants.logTypeSubCategory_errorAutomationStopped.toLowerCase();
    logTypeSubCategory_RobotConnected = Constants.logTypeSubCategory_infoRobotConnected.toLowerCase();
    logTypeSubCategory_AutomationCompleted = Constants.logTypeSubCategory_infoAutomationCompleted.toLowerCase();

    constructor(private _utilityService: UtilityService, private _dataService: DataService) { }

    getNotificationMessage(item: Exception) {
        let returnValue: string;
        switch (item.logType.toLowerCase()) {
            case this.logTypeError:
                switch (item.category.toLowerCase()) {
                    case this.logTypeCategoryRobot:
                        switch (item.subCategory.toLowerCase()) {
                            case this.logTypeSubCategory_RobotDisconnected:
                                returnValue = 'Robot Name : ' + item.robotName + ' belonging to Account : ' + item.accountName + ' is disconnected';
                                break;
                            case this.logTypeSubCategory_RobotDeactivated:
                                returnValue = 'Robot Name : ' + item.robotName + ' belonging to Account : ' + item.accountName + ' is deactivated from Controller ' + item.controllerName;
                                break;
                        }
                        break;
                    case this.logTypeCategoryJob:
                        switch (item.subCategory.toLowerCase()) {
                            case this.logTypeSubCategory_RobotDisconnected:
                                returnValue = 'Robot Name : ' + item.robotName + ' belonging to Account : ' + item.accountName + ' is disconnected';
                                break;
                            case this.logTypeSubCategory_RobotDeactivated:
                                returnValue = 'Robot Name : ' + item.robotName + ' belonging to Account : ' + item.accountName + ' is deactivated from Controller : ' + item.controllerName;
                                break;
                            case this.logTypeSubCategory_AutomationAbandoned:
                                returnValue = 'Automation Name : ' + item.businessProcessName + ' belonging to Account : ' + item.accountName + ' is Abandoned';
                                break;
                            case this.logTypeSubCategory_AutomationStopped:
                                returnValue = 'Automation Name : ' + item.businessProcessName + ' belonging to Account : ' + item.accountName + ' is Stopped';
                                break;
                        }
                        break;
                }
                break;
            case this.logTypeWarning:
                switch (item.category.toLowerCase()) {
                    case this.logTypeCategoryRobot:
                        // do coding here
                        break;
                    case this.logTypeCategoryJob:
                        // do coding here
                        break;
                }
                break;
            case this.logTypeInfo:
                switch (item.category.toLowerCase()) {
                    case this.logTypeCategoryRobot:
                        switch (item.subCategory.toLowerCase()) {
                            case this.logTypeSubCategory_RobotConnected:
                                returnValue = 'Robot Name : ' + item.robotName + ' belonging to Account :' + item.accountName + ' is Connected';
                                break;
                        }
                        break;
                    case this.logTypeCategoryJob:
                        switch (item.subCategory.toLowerCase()) {
                            case this.logTypeSubCategory_RobotConnected:
                                returnValue = 'Robot Name : ' + item.robotName + ' belonging to Account :' + item.accountName + ' is Connected';
                                break;
                            case this.logTypeSubCategory_AutomationCompleted:
                                returnValue = 'Automation Name : ' + item.businessProcessName + ' belonging to Account : ' + item.accountName + ' is Completed';
                                break;
                        }
                        break;
                }
                break;
        }
        return returnValue;
    }

    prepareNotificationList(list) {
        const notificationsList = new Array<NotificationsClass>();
        list.forEach(element => {
            const _notifications: NotificationsClass = new NotificationsClass();
            _notifications.exception.id = element.id;
            _notifications.exception.accountId = element.accountId;
            _notifications.exception.accountName = element.accountName;
            _notifications.exception.businessProcessId = element.businessProcessId;
            _notifications.exception.businessProcessName = element.source.split('| Process Name :')[1];
            _notifications.exception.category = element.category;
            _notifications.exception.controllerId = element.controllerId;
            _notifications.exception.controllerName = element.source.split('|')[0];
            _notifications.exception.exceptionType = element.exceptionType;
            _notifications.exception.inputType = element.inputtype;
            _notifications.exception.locationId = element.locationId;
            _notifications.exception.logType = element.logType;
            _notifications.exception.loggedOn = new Date(element.loggedOn);
            _notifications.exception.message = element.message;
            _notifications.exception.robotId = element.robotId;
            _notifications.exception.robotName = element.source.split('| Robot Name :')[1];
            _notifications.exception.hostName = element.hostName;
            _notifications.exception.source = element.source;
            _notifications.exception.subCategory = element.subCategory;
            _notifications.exception.verticalId = element.verticalId;
            _notifications.showActions = false;
            notificationsList.push(_notifications);
        });
        return notificationsList;
    }

    getAlertDetail() {
        const reqData = {
            dateRange: [
                {
                    startDate: this._utilityService.getDateInDDMMYYYY(new Date()),
                    endDate: this._utilityService.getDateInDDMMYYYY(new Date())
                }
            ],
            pageNumber: 0,
            pageSize: 1000,
            vertical: [
                {
                    accountIds: [
                        localStorage.accountId
                    ],
                    verticalId: localStorage.verticalId
                }
            ]
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_ALERTDETAIL, reqData);
    }
}

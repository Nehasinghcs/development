import { Injectable } from '@angular/core';
import { CriticalTicket } from './criticaltickets/criticaltickets';
import { DataService } from '../../../../services/data.services';
import { UtilityService } from '../../../utility/utility.services';
import { Tickets } from '../../../class/operationalClasses/tickets';
import { AppSettings } from '../../../utility/app.settings';

@Injectable()

export class TicketService {

    constructor(private _dataService: DataService, private _utilityService: UtilityService) { }

    prepareCriticalTickets(list) {
        const tickets = new Array<CriticalTicket>();
        list.forEach(element => {
            const _ticket: CriticalTicket = new CriticalTicket();
            _ticket.ticket.ticketId = element.ticketId;
            _ticket.ticket.type = element.type;
            _ticket.ticket.status = element.status;
            _ticket.ticket.description = element.description;
            _ticket.ticket.robotId = element.robotId;
            _ticket.ticket.processName = element.processName;
            _ticket.ticket.robotId = element.robotId;
            _ticket.ticket.processName = element.processName;
            _ticket.ticket.createdBy = element.createdBy;
            _ticket.ticket.createdOn = this._utilityService.convertUTCDateToLocalDate(element.createdOn);
            _ticket.ticket.location = element.location;
            _ticket.ticket.additionalInfo = element.additionalInfo;
            _ticket.ticket.affectedClientDetails = element.affectedClientDetails;
            _ticket.ticket.alertOrganisationDetails = element.alertOrganisationDetails;
            _ticket.ticket.issueDescription = element.issueDescription;
            _ticket.selected = false;
            _ticket.additionalInfoExpanded = false;
            _ticket.affectedClientExpanded = false;
            _ticket.alertOrganizationExpanded = false;
            _ticket.issueDescriptionExpanded = false;
            tickets.push(_ticket);
        });
        return tickets;
    }

    prepareTickets(list) {
        const tickets = new Array<Tickets>();
        list.forEach(element => {
            const _ticket: Tickets = new Tickets();
            _ticket.ticketId = element.ticketId;
            _ticket.type = element.type;
            _ticket.status = element.status;
            _ticket.description = element.description;
            _ticket.robotId = element.robotId;
            _ticket.processName = element.processName;
            _ticket.robotId = element.robotId;
            _ticket.processName = element.processName;
            _ticket.createdBy = element.createdBy;
            _ticket.createdOn = new Date(element.createdOn);
            _ticket.location = element.location;
            _ticket.additionalInfo = element.additionalInfo;
            _ticket.affectedClientDetails = element.affectedClientDetails;
            _ticket.alertOrganisationDetails = element.alertOrganisationDetails;
            _ticket.issueDescription = element.issueDescription;
            tickets.push(_ticket);
        });
        return tickets;
    }

    getDataFromJSON() {
        const reqData = {
            'dateRange': [
                {
                    'endDate': '01/01/2018',
                    'startDate': '20/12/2017'
                }
            ],
            'pageNumber': 0,
            'pageSize': 0,
           /* "processIds": [
                "1",
                "2",
                "3",
                "4",
                "5"
            ],
            "status": [
                "1",
                "2",
                "0"
            ],
            "type": [
                "P1",
                "P2",
                "P3"
            ]*/
        };
        // return this._dataService.getDataFromJSON('../../../../assets/ticketdetails.json');
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_TICKETDETAIL, reqData);
    }
}

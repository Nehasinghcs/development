import { Tickets } from '../../../../class/operationalClasses/tickets';

export class CriticalTicket {
    ticket: Tickets;
    selected: boolean;
    alertOrganizationExpanded: boolean;
    affectedClientExpanded: boolean;
    issueDescriptionExpanded: boolean;
    additionalInfoExpanded: boolean;
    constructor() {
        this.ticket = new Tickets();
    }
}

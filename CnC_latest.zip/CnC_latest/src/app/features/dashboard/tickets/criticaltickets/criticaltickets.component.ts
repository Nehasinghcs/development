import { Component, OnInit } from '@angular/core';
import { TicketService } from '../tickets.service';
import { CriticalTicket } from './criticaltickets';
import { Tickets } from '../../../../class/operationalClasses/tickets';
import { UtilityService } from '../../../../utility/utility.services';
import { SharedService } from '../../../../../services/shared.service';

@Component({
  selector: 'app-criticaltickets',
  templateUrl: './criticaltickets.component.html',
  styleUrls: ['./criticaltickets.component.scss']
})
export class CriticalticketsComponent implements OnInit {

  tickets: Tickets[];
  criticalTickets: CriticalTicket[];
  selectedTicket: CriticalTicket;

  constructor(private _utilityService: UtilityService, private _ticketService: TicketService, private _sharedService: SharedService) { }

  getDaysDifference(item: CriticalTicket) {
    if (item !== undefined) {
      return this._utilityService.getDaysDifference(item.ticket.createdOn, new Date());
    }
  }

  click_additionalInfo(selectedTicket: CriticalTicket) {
    selectedTicket.alertOrganizationExpanded = false;
    selectedTicket.affectedClientExpanded = false;
    selectedTicket.issueDescriptionExpanded = false;
  }

  click_affectedClient(selectedTicket: CriticalTicket) {
    selectedTicket.additionalInfoExpanded = false;
    selectedTicket.alertOrganizationExpanded = false;
    selectedTicket.issueDescriptionExpanded = false;
  }

  click_issueDescription(selectedTicket: CriticalTicket) {
    selectedTicket.additionalInfoExpanded = false;
    selectedTicket.affectedClientExpanded = false;
    selectedTicket.alertOrganizationExpanded = false;
  }

  click_alertOrganization(selectedTicket: CriticalTicket) {
    selectedTicket.additionalInfoExpanded = false;
    selectedTicket.affectedClientExpanded = false;
    selectedTicket.issueDescriptionExpanded = false;
  }

  getFullScreenParameter() {
    return this._sharedService.showFullScreen;
  }

  getWidth(type) {
    if (this.selectedTicket !== undefined) {
      const totalP1tickets = this.criticalTickets.filter(criticalTicket => criticalTicket.ticket.type === 'P1').length;
      const totalP2tickets = this.criticalTickets.filter(criticalTicket => criticalTicket.ticket.type === 'P2').length;
      const totalP3tickets = this.criticalTickets.filter(criticalTicket => criticalTicket.ticket.type === 'P3').length;
      let returnValue;
      switch (type) {
        case 'P1':
          returnValue = ((totalP1tickets / this.criticalTickets.length) * 100).toFixed(2);
          break;
        case 'P2':
          returnValue = ((totalP2tickets / this.criticalTickets.length) * 100).toFixed(2);
          break;
        case 'P3':
          returnValue = ((totalP3tickets / this.criticalTickets.length) * 100).toFixed(2);
          break;
      }
      return returnValue;
    }
  }

  selectNewTicket(item) {
    item.selected = true;
    this.selectedTicket = item;
    this.selectedTicket.alertOrganizationExpanded = true;
    this.criticalTickets.forEach(element => {
      if (element.ticket.ticketId !== item.ticket.ticketId) {
        element.selected = false;
        element.alertOrganizationExpanded = false;
        element.additionalInfoExpanded = false;
        element.affectedClientExpanded = false;
        element.issueDescriptionExpanded = false;
      }
    });
  }

  getStatus(status) {
    let returnValue;
    switch (status) {
      case '0':
        returnValue = 'Unassigned';
        break;
      case '1':
        returnValue = 'On hold';
        break;
      case '2':
        returnValue = 'In progress';
        break;
    }
    return returnValue;
  }

  getTicketsCount(type) {
    if (this.criticalTickets !== undefined) {
      return this.criticalTickets.filter(criticalTicket => criticalTicket.ticket.type === type).length;
    }
  }

  changeViewSize() {
    this._sharedService.emitViewSizeChange(!this._sharedService.showFullScreen);
  }

  ngOnInit() {
    this._sharedService.emitWidgetChange(this._sharedService.currentView, 7);
    this._sharedService.emitViewChange(7);
    if (this._sharedService.tickets !== undefined) {
      this.criticalTickets = this._ticketService.prepareCriticalTickets(this._sharedService.tickets);
      this.selectedTicket = this.criticalTickets[0];
      this.selectedTicket.selected = true;
      this.selectedTicket.alertOrganizationExpanded = true;
    } else {
      this._ticketService.getDataFromJSON().subscribe(response => {
        this.tickets = this._ticketService.prepareTickets(response.ticketDetails);
        this.criticalTickets = this._ticketService.prepareCriticalTickets(response.ticketDetails);
        this.selectedTicket = this.criticalTickets[0];
        this.selectedTicket.selected = true;
        this.selectedTicket.alertOrganizationExpanded = true;
        this._sharedService.emitCriticalTicket(this.tickets);
      });
    }
  }

}

import { NgModule } from '@angular/core';
import { OperationalviewComponent } from './operationalview/operationalview.component';
import { OperationalfooterComponent } from './operationalfooter/operationalfooter.component';
import { SummaryComponent } from './summary/summary.component';
import { DragDropDirectiveModule } from 'angular4-drag-drop';
import highchartsmore from 'highcharts/highcharts-more.src';
import { CritialticketsglancesComponent } from './systemGlances/critialticketsglances/critialticketsglances.component';
import { ExceptionhotspotsComponent } from './systemGlances/exceptionhotspots/exceptionhotspots.component';
import { ExceptionanalysisComponent } from './systemGlances/exceptionanalysis/exceptionanalysis.component';
import { NotificationsComponent } from './systemGlances/notifications/notifications.component';
import { ProcessviewglancesComponent } from './systemGlances/processviewglances/processviewglances.component';
import { WorkforceavailabilityComponent } from './systemGlances/workforceavailability/workforceavailability.component';
import { CriticalticketsComponent } from './tickets/criticaltickets/criticaltickets.component';
import { NotificationlistComponent } from './notifications/notificationlist/notificationlist.component';
import { AnalysisviewComponent } from './analysis/analysisview/analysisview.component';
import { HotspotviewComponent } from './hotspots/hotspotview/hotspotview.component';
import { ChartModule, HIGHCHARTS_MODULES } from 'angular-highcharts';
import more from 'highcharts/highcharts-more.src';
import exporting from 'highcharts/modules/exporting.src';
import highmaps from 'highcharts/modules/map.src';
import tilemap from 'highcharts/modules/tilemap.src';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProcesssnapshotComponent } from './summary/processsnapshot/processsnapshot.component';
import { TicketsummaryComponent } from './summary/ticketsummary/ticketsummary.component';
import solidgauge from 'highcharts/modules/solid-gauge.src';
import { ContinentalComponent } from './hotspots/continental/continental.component';
import { TicketmetricsComponent } from './ticketmetrics/ticketmetrics.component';
import heatmap from 'highcharts/modules/heatmap.src';
import { SlabreachesComponent } from './summary/slabreaches/slabreaches.component';
import data from 'highcharts/modules/data.src';
import { TicketService } from './tickets/tickets.service';
import { FullviewComponent } from './hotspots/continental/fullview/fullview.component';
import { EuropeComponent } from './hotspots/continental/europe/europe.component';
import { AfricaComponent } from './hotspots/continental/africa/africa.component';
import { NamericaComponent } from './hotspots/continental/namerica/namerica.component';
import { SamericaComponent } from './hotspots/continental/samerica/samerica.component';
import { AustraliaComponent } from './hotspots/continental/australia/australia.component';
import { AsiaComponent } from './hotspots/continental/asia/asia.component';
import { MapviewComponent } from './hotspots/continental/mapview/mapview.component';
import { SummarytabComponent } from './summary/todayssummary/summarytab/summarytab.component';
import { NotificationsService } from './notifications/notifications.service';
import { SlabreachestabComponent } from './summary/todayssummary/slabreachestab/slabreachestab.component';
import { ProcesssnapshottabComponent } from './summary/todayssummary/processsnapshottab/processsnapshottab.component';
import { ProcessService } from './processview/processview.service';
import { CriticalprocessOffComponent } from './processview/criticalprocess/criticalprocess-off/criticalprocess-off.component';
import { CriticalprocessComponent } from './processview/criticalprocess/criticalprocess.component';
import { CriticalprocessOnComponent } from './processview/criticalprocess/criticalprocess-on/criticalprocess-on.component';
import { ExceptionAnalysysService } from './analysis/exceptionanalysis.service';
import { WorkForceComponent } from './workforce/workforce.component';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { AutomationComponent } from './systemGlances/automation/automation.component';
import { AutomationviewComponent } from './automationview/automationview.component';
import { AllaccountsComponent } from './automationview/allaccounts/allaccounts.component';
import { AccountComponent } from './automationview/account/account.component';
import { AutomationService } from './automationview/automation.service';
import sunburst from 'highcharts/modules/sunburst.src';
import { HealthComponent } from './workforce/health/health.component';
import { RobotdeatailsComponent } from './workforce/robotdeatails/robotdeatails.component';
import { UtilizationComponent } from './workforce/utilization/utilization.component';
import { RobotService } from './workforce/robot.service';
import { DragwidgetsComponent } from './dragwidgets/dragwidgets.component';
import { CustomizewidgetsComponent } from './customizewidgets/customizewidgets.component';
import { TicketmetricsglancesComponent } from './systemGlances/ticketmetricsglances/ticketmetricsglances.component';
import { AutomationdetailsComponent } from './processview/automationdetails/automationdetails.component';
import { processGroupDetailComponent } from './processview/automationdetails/processGroupDetail/processGroupDetail.component';
import { ProcessDetailComponent } from './processview/automationdetails/processDetail/processDetail.component';
import { OperationalSpinnerComponent } from './operational-spinner/operational-spinner.component';
import { SystemGlanceService } from './systemGlances/systemGlances.service';
import { MaterialModule } from '../../shared/material/material.module';
import { DefaultPipe } from '../../pipes/defaultpipe';
import { TicketPipe } from '../../pipes/ticketpipe';
import { WidgetService } from '../../../services/widget.service';
import { dashboardrouting } from './dashboard.routing';
import { DashboardComponent } from './dashboard.component';
import { DashboardAreaComponent } from './dashboardarea.component';
import { ContinentalService } from './hotspots/continental/continental.service';
import { PieChart } from '../../shared/cnc-charts/piechart/piechart.component';
import { ColumnChart } from '../../shared/cnc-charts/columnchart/columnchart.component';
import { BubbleChartComponent } from '../../shared/cnc-charts/bubblechart/bubblechart.component';
import { AreaSplineChartComponent } from '../../shared/cnc-charts/areasplinechart/areasplinechart.component';
import { CommonModule } from '@angular/common';
import { HighchartsChartComponent } from '../../shared/cnc-charts/highcharts-chart.component';

export function highchartsModules() {
    return [more, highmaps, tilemap, solidgauge, heatmap, data, sunburst];
}
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
    suppressScrollX: true
};
@NgModule({
    imports: [
        dashboardrouting,
        MaterialModule,
        DragDropDirectiveModule,
        ChartModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        PerfectScrollbarModule
    ],
    declarations: [
        DashboardComponent,
        OperationalviewComponent,
        OperationalfooterComponent,
        SummaryComponent,
        CriticalticketsComponent,
        CritialticketsglancesComponent,
        ExceptionhotspotsComponent,
        ExceptionanalysisComponent,
        NotificationsComponent,
        ProcessviewglancesComponent,
        WorkforceavailabilityComponent,
        CriticalprocessComponent,
        CriticalprocessOffComponent,
        NotificationlistComponent,
        AnalysisviewComponent,
        HotspotviewComponent,
        DashboardAreaComponent,
        ProcesssnapshotComponent,
        HealthComponent,
        TicketsummaryComponent,
        ContinentalComponent,
        TicketmetricsComponent,
        RobotdeatailsComponent,
        SlabreachesComponent,
        FullviewComponent,
        EuropeComponent,
        AfricaComponent,
        NamericaComponent,
        SamericaComponent,
        AustraliaComponent,
        AsiaComponent,
        MapviewComponent,
        PieChart,
        DefaultPipe,
        SummarytabComponent,
        TicketPipe,
        SlabreachestabComponent,
        ProcesssnapshottabComponent,
        ColumnChart,
        CriticalprocessOnComponent,
        BubbleChartComponent,
        AreaSplineChartComponent,
        WorkForceComponent,
        UtilizationComponent,
        AutomationComponent,
        AutomationviewComponent,
        AllaccountsComponent,
        AccountComponent,
        DragwidgetsComponent,
        HighchartsChartComponent,
        CustomizewidgetsComponent,
        TicketmetricsglancesComponent,
        AutomationdetailsComponent,
        ProcessDetailComponent,
        processGroupDetailComponent,
        OperationalSpinnerComponent
    ],
    providers: [
        { provide: HIGHCHARTS_MODULES, useFactory: highchartsModules },
        { provide: PERFECT_SCROLLBAR_CONFIG, useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG },
        TicketService,
        NotificationsService,
        ProcessService,
        ExceptionAnalysysService,
        AutomationService,
        RobotService,
        WidgetService,
        SystemGlanceService,
        ContinentalService
    ]
})

export class DashboardModule {
}

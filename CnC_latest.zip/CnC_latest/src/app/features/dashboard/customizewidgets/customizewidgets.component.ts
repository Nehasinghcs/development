import { Component, OnInit } from '@angular/core';
import { element } from 'protractor';
import { Router } from '@angular/router';
import { UtilityService } from '../../../utility/utility.services';
import { SharedService } from '../../../../services/shared.service';
import { WidgetService } from '../../../../services/widget.service';

@Component({
  selector: 'app-customizewidgets',
  templateUrl: './customizewidgets.component.html',
  styleUrls: ['./customizewidgets.component.scss']
})
export class CustomizewidgetsComponent implements OnInit {

  originalGlances: any[];
  activeGlances: any[];
  draggedItem: any;

  constructor(private _utilityService: UtilityService, private _sharedService: SharedService, private _router: Router, private _widgetService: WidgetService) { }

  saveWidgetChanges() {
    this._sharedService.currentView = this.activeGlances[0].position;
    this._router.navigateByUrl(this.activeGlances[0].routeUrl);
  }

  cancelWidgetChanges() {
    this._sharedService.currentView = this.activeGlances[0].position;
    this._router.navigateByUrl(this.activeGlances[0].routeUrl);
  }

  startDrag(item) {
    this.draggedItem = item;
  }

  addDropItem(item) {
    const draggedItemIndex = this.activeGlances.findIndex(elements => elements.position === this.draggedItem.position);
    if (draggedItemIndex > -1) {
      this._utilityService.handleException(800);
    } else {
      const index = this.activeGlances.findIndex(elements => elements.position === item.position);
      this.activeGlances[index] = this.draggedItem;
      this._widgetService.activeGlances = this.activeGlances;
    }
  }

  ngOnInit() {
    this.originalGlances = this._widgetService.originalGlances;
    if (this._widgetService.activeGlances !== undefined && this._widgetService.activeGlances.length) {
      this.activeGlances = this._widgetService.activeGlances;
    } else {
      this.activeGlances = this._widgetService.getActiveGlances();
    }
  }

}

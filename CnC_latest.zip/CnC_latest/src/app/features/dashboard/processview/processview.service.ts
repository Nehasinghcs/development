import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Chart } from 'angular-highcharts';
import { Router } from '@angular/router';
import { BusinessProcessGroup } from '../../../class/operationalClasses/businessProcessGroup';
import { BusinessProcess } from '../../../class/operationalClasses/businessProcess';
import { UtilityService } from '../../../utility/utility.services';
import { Case } from '../../../class/operationalClasses/case';
import { DataService } from '../../../../services/data.services';
import { Constants } from '../../../utility/app.constants';
import { AppSettings } from '../../../utility/app.settings';

@Injectable()

export class ProcessService {
    reqData;
    selectedBusinessProcessGroup: BusinessProcessGroup;
    selectedBusinessProcess: BusinessProcess;
    processGroupParentPage: string;
    processParentPage: string;
    processLength: number;
    tilemapWidth: any;

    constructor(private _router: Router, private _utilityService: UtilityService, private _dataService: DataService) { }

    private _emitProcessData = new Subject<any>();
    emitProcessData = this._emitProcessData.asObservable();
    emitProcessDataChange(change: any) {
        this._emitProcessData.next(change);
    }

    getTotalCount(groupId, type, processList) {
        if (processList !== undefined && processList.length) {
            if (type === 'total') {
                return processList.filter(element => element.businessProcessGroupId === groupId).length;
            } else {
                return processList.filter(element => element.businessProcessGroupId === groupId && element.critical).length;
            }
        }
    }
    getTileMapWidth(processGroupLength) {
        this.tilemapWidth = (processGroupLength <= 6) ? 230 : (processGroupLength > 6 && processGroupLength <= 9) ? 270 :
            (processGroupLength > 9 && processGroupLength <= 15) ? 350 : ((processGroupLength > 15 && processGroupLength <= 20) ? 460 : 550);
        return this.tilemapWidth;
    }
    prepareDataForProcess_off(groupIdsList: any[], processList: any[]) {
        let totalCriticalCount = 0;
        let totalNonCriticalCount = 0;
        const processGroupList: any[] = new Array<any>();
        const tileElementList: any[] = new Array<any>();
        groupIdsList.forEach(element => {
            const processGroup = {
                id: element,
                name: processList.filter(process => process.businessProcessGroupId === element)[0].businessProcessGroupName,
                isCritical: (processList.filter(process => process.businessProcessGroupId === element && process.critical).length ? true : false)
            };
            processGroupList.push(processGroup);
            if (processGroup.isCritical) {
                totalCriticalCount += 1;
            } else {
                totalNonCriticalCount += 1;
            }
        });
        this.processLength = processGroupList.length;
        processGroupList.forEach((process, index) => {
            let verticalAxis = 0;
            let horizontalAxis = 1;
            if (index < ((this.processLength / 3))) {
                verticalAxis = 0;
                horizontalAxis = index;
            } else if (index < ((2 * this.processLength) / 3)) {
                verticalAxis++;
                horizontalAxis = index - (Math.round(this.processLength / 3));
            } else if (index < this.processLength) {
                verticalAxis = verticalAxis + 2;
                horizontalAxis = index - (Math.round((2 * this.processLength) / 3));
            }
            const element = {
                x: verticalAxis,
                y: horizontalAxis,
                id: process.id,
                tilename: process.name,
                totalCount: this.getTotalCount(process.id, 'total', processList),
                criticalCount: this.getTotalCount(process.id, 'critical', processList),
                value: process.isCritical ? 1 : 0,
            };
            tileElementList.push(element);
        });
        const hexagonMap = new Chart({
            chart: {
                type: 'tilemap',
                height: 250,
                width: this.getTileMapWidth(processGroupList.length),
                inverted: true
            },
            title: {
                text: ''
            },
            subtitle: {
                text: ''
            },
            xAxis: {
                visible: false
            },
            yAxis: {
                visible: false
            },
            colorAxis: {
                dataClasses: [{
                    from: 1,
                    to: 1,
                    color: {
                        radialGradient: { cx: 0.5, cy: 0.5, r: 0.5 },
                        stops: [
                            [0, '#ffffff'],
                            [1, '#ffdce0'],
                        ]
                    },
                }, {
                    from: 0,
                    to: 0,
                    color: {
                        radialGradient: { cx: 0.5, cy: 0.5, r: 0.5 },
                        stops: [
                            [0, '#ffffff'],
                            [1, 'rgba(126, 199, 231, 0.32)']
                        ]
                    },
                }]
            },
            legend: {
                enabled: false
            },
            tooltip: {
                enabled: true,
                headerFormat: '',
                useHTML: true,
                positioner: function () {
                    return { x: 33, y: 0 };
                },
                style: {
                    fontFamily: 'OpenSans-Semibold',
                    backgroundColor: 'white'
                },
                formatter: function () {
                    return `
                  <div style="">
                  <div style="background-color: #ffffff; margin: 0px 0px 0px 0px;">
                    <div style="
                          display: none;
                          text-align: center;
                          font-size: 13px;
                          font-weight: bold;
                          color: #626579;
                          font-family: OpenSans-Bold;
                          padding: 6px 0px;
                    ">{point.tilename}</div>
                    <div style="padding: 0px 19.8px 0px 20px;">
                        <table>
                        <tr>
                          <td style="font-size: 12px;font-weight: normal;color: #626579;">Total Automations</td>
                          <td style="text-align: right;font-size: 13px;font-weight: bold;color: #626579;
                          font-family: OpenSans-Bold; margin-left:15px;"> &nbsp` + this.point.totalCount + `</td>
                        </tr>
                        <tr>
                          <td style="font-size: 12px;font-weight: normal;color: #626579;">Critical Automations</td>
                          <td style="text-align: right;font-size: 13px;font-weight: bold;color: #626579;
                          font-family: OpenSans-Bold;margin-left:15px;"> &nbsp` + this.point.criticalCount + `</td>
                        </tr>
                      </table>
                    </div>
                   </div>
                   </div>
                   `;
                }
            },
            plotOptions: {
                series: {
                    events: {
                        click: this.onClick
                    },
                    dataLabels: {
                        enabled: true,
                        format: '{point.tilename}',
                        color: '#000',
                    },
                    cursor: 'pointer'
                },
            },
            series: [{
                data: tileElementList
            }]
        });
        return hexagonMap;
    }

    onClick = (event: any) => {
        this.setSelectedBusinessProcessGroup(event.point.id, event.point.tilename);
        this.processGroupParentPage = Constants.processOff;
        this._router.navigateByUrl('root/dashboard/view/automation/groupdetail');
    }

    prepareDataForProcess_on(businessProcessList: BusinessProcess[]) {
        if (businessProcessList.length) {
            const processGroupList: any = new Array<any>();
            const uniqueList: any[] = businessProcessList.map(item => item.processGroup.id).filter((value, index, self) => self.indexOf(value) === index && value !== null);
            uniqueList.forEach(element => {
                const obj = {
                    id: element,
                    name: businessProcessList.filter(item => item.processGroup.id === element)[0].processGroup.name,
                    processList: businessProcessList.filter(item => item.processGroup.id === element),
                    isCritical: (businessProcessList.filter(item => item.processGroup.id === element && item.critical).length ? true : false),
                    criticalCount: businessProcessList.filter(item => item.processGroup.id === element && item.critical).length,
                    redHexagon: (businessProcessList.filter(item => item.processGroup.id === element && item.critical).length > 20 && (businessProcessList.filter(item => item.processGroup.id === element).length > 20))
                };
                if (obj.isCritical) {
                    processGroupList.push(obj);
                }
            });
            return processGroupList;
        }
    }

    /*crrByProcessId() {
        this.reqData = {
            "businessProcessId": "string"
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_CRR_BY_PROCESS_ID, this.reqData);
    }*/

    crrByGroupProcessId() {
        this.reqData = {
            accountId: localStorage.accountId,
            businessProcessGroupId: this.selectedBusinessProcessGroup.id,
            endDate: this._utilityService.getDateInDDMMYYYY(new Date()),
            startDate: this._utilityService.getDateInDDMMYYYY(new Date()),
            tool: Constants.toolsList
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_CRR_BY_PROCESSGROUP_ID, this.reqData);
    }

    crrByAccountId() {
        this.reqData = {
            accountId: localStorage.accountId,
            endDate: this._utilityService.getDateInDDMMYYYY(new Date()),
            startDate: this._utilityService.getDateInDDMMYYYY(new Date()),
            tool: Constants.toolsList
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_CRR_BY_ACCOUNT_ID, this.reqData);
    }

    getProcessDetailbyId() {
        this.reqData = {
            businessProcessId: this.selectedBusinessProcess.id
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_PROCESS_DETAILBY_ID, this.reqData);
    }

    getGroupDetailbyId() {
        this.reqData = {
            accountId: localStorage.accountId,
            businessProcessGroupId: this.selectedBusinessProcessGroup.id
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_GROUPDETAILBYID, this.reqData);
    }

    private _emitProcessDetailPage = new Subject<boolean>();
    changeViewEmitted = this._emitProcessDetailPage.asObservable();
    emitProcessDetailPage(change: boolean) {
        this._emitProcessDetailPage.next(change);
    }

    setSelectedBusinessProcessGroup(id: string, name: string) {
        this.selectedBusinessProcessGroup = new BusinessProcessGroup(id, name);
    }

    prepareProcess(response) {
        const _process: BusinessProcess = new BusinessProcess();
        _process.outstandingTickets = response.outstandingTickets;
        _process.avgHandlingTime = response.avgHandlingTime;
        _process.throughput = response.throughput;
        _process.yield = response.yield;
        _process.slaBreachCount = response.slaBreachCount;
        return _process;
    }

    prepareProcessList(list) {
        const processList = new Array<BusinessProcess>();
        list.forEach(element => {
            const _businessProcess: BusinessProcess = new BusinessProcess();
            _businessProcess.id = element.businessProcessId;
            _businessProcess.name = element.businessProcessName;
            _businessProcess.accountId = element.accountId;
            _businessProcess.critical = element.critical;
            _businessProcess.startTime = element.startTime;
            _businessProcess.endTime = element.endTime;
            _businessProcess.status = element.processStatus;
            _businessProcess.tool = element.tool;
            _businessProcess.verticalId = element.verticalId;
            _businessProcess.desc = element.businessProcessGroupDescription;
            _businessProcess.processGroup.id = element.businessProcessGroupId;
            _businessProcess.processGroup.name = element.businessProcessGroupName;
            // _businessProcess.processGroup.desc = element.businessProcessGroupDescription;
            processList.push(_businessProcess);
        });
        return processList;
    }

    getProcessList() {
        this.reqData = {
            'tool': [
                'BP', 'AA', 'UI'
            ],
            'vertical': [
                {
                    'accountIds': [
                        localStorage.accountId
                    ],
                    'verticalId': localStorage.verticalId
                }
            ]
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_PROCESS_LIST, this.reqData);
    }

    prepareCaseList(list) {
        const caseList = new Array<Case>();
        list.forEach(element => {
            const _case: Case = new Case();
            _case.caseId = element.caseId;
            _case.hostName = element.hostName;
            _case.caseStatus = element.caseStatus;
            _case.controllerId = element.controllerId;
            _case.robotName = element.robotName;
            _case.botName = element.botName;
            _case.ipAddress = element.ipAddress;
            _case.robotId = element.robotId;
            _case.type = element.type;
            _case.errorMsg = element.errorMsg;
            _case.jobId = element.jobId;
            _case.verticalId = element.verticalId;
            _case.accountId = element.accountId;
            _case.botId = element.botId;
            _case.caseStartTime = new Date(element.caseStartTime);
            _case.caseEndTime = new Date(element.caseEndTime);
            _case.businessProcessId = element.businessProcessId;
            _case.businessProcessName = element.businessProcessName;
            _case.locationId = element.locationId;
            caseList.push(_case);
        });
        return caseList;
    }
    getBotCount() {
        this.reqData = {
            controllerIds: [
                '7f79807c-e3df-11e7-8d09-0023ae9f8800'
            ],

            tool: [
                'AA', 'BP', 'UI'
            ],
            vertical: [
                {
                    accountIds: [
                        localStorage.accountId
                    ],
                    verticalId: localStorage.verticalId
                }
            ]
        };

        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_BOT_COUNT, this.reqData);
    }
}

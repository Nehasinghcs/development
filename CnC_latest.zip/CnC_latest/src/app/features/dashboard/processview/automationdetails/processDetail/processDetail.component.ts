import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Chart, MapChart, Highcharts } from 'angular-highcharts';
import { Router } from '@angular/router';
import { ProcessService } from '../../processview.service';
import { SharedService } from '../../../../../../services/shared.service';
import { BusinessProcess } from '../../../../../class/operationalClasses/businessProcess';
import { AreaSplineChartComponent } from '../../../../../shared/cnc-charts/areasplinechart/areasplinechart.component';

@Component({
  selector: 'app-process-detail',
  templateUrl: './processDetail.component.html',
  styleUrls: ['./processDetail.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [AreaSplineChartComponent]
})
export class ProcessDetailComponent implements OnInit {
  selectedAutomation = 0;
  process: BusinessProcess;
 referenceData: number[];
 errorData = [];
  constructor(private _processService: ProcessService, private _sharedService: SharedService, private _router: Router) { }

  plotDataArray = [
    {
      'data': this.generateErrorData(),
      'legendname': 'Abandoned',
      'color': {
        linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
        stops: [
          [0, '#f04d3b'],
          [1, 'rgba(240, 77, 59, 0)']
        ]
      }
    }
  ];

  tools = [{
    id: 0,
    name: 'Automation Analytics'
  }, {
    id: 1,
    name: 'Download all'
  }, {
    id: 2,
    name: 'Standard operation procedure'
  }, {
    id: 3,
    name: 'Disaggregation sheet'
  }, {
    id: 4,
    name: 'Solution design document'
  }, {
    id: 5,
    name: 'Project tracking link'
  }, {
    id: 6,
    name: 'Automation scripts'
  }];
  splineChartSettings = {
    height: 150,
    formatteryaxis: function () {
      return (this.value * 10) / 5 + '%';
    },
    // seriesList: [
    //   {
    //     name: 'Abandoned',
    //     data: [1, 3, 4, 3, 3, 5, 4],
    //     color: {
    //       linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
    //       stops: [
    //         [0, '#f04d3b'],
    //         [1, 'rgba(240, 77, 59, 0)']
    //       ]
    //     }
    //   }
    // ]
  };
  getCurrentHour() {
    return new Date().getHours();
  }

  generateErrorData() {
    this.referenceData = [3, 6, 6, 6, 8, 9, 7, 7, 7, 4, 4, 6, 4, 4, 7, 7, 7, 7, 7, 9, 9, 9, 9, 3, 5, 7];
    this.errorData = [];
    for (let i = 0; i <= this.getCurrentHour(); i++) {
      this.errorData.push(this.referenceData[i]);
    }
    return this.errorData;
  }


  lineChart = new Chart(
    {
    chart: {
      height: 150,
      type: 'line',

    },
    tooltip: { enabled: false },

    title: {
      text: ''
    },
    // xAxis: {
    //   minorTickLength: 0,
    //   tickLength: 0,
    //   labels: {
    //     style: {
    //       color: '#9ea6a9',
    //     },
    //     type:'datetime',
    //     dateTimeLabelFormats: {
    //       hour: '%Y-%m-%d<br/>%H:%M',
    //   }
    //     // formatter: function () {
    //     //   return this.value + ' AM'; // clean, unformatted number for year
    //     // },
    //   },
    // },
    xAxis: {
      categories: ['12AM', '', '02AM', '', '04AM', '', '06AM', '', '08AM', '', '10AM', '', '12PM', '', '02PM', '', '04PM', '', '06PM', '', '08PM', '', '10PM'],
      tickLength: 0,

    },
    yAxis: {
      min: 0,
      max: 10,
      tickInterval: 5,
      title: {
        text: ''
      },
      gridLineWidth: 0,
      labels: {
        style: {
          color: '#9ea6a9',
        }
      },
    },
    plotOptions: {
      areaspline: {
        fillOpacity: 0.5,
        lineWidth: 1
      },
      series: {
        lineWidth: 1,
        color: "#f04d3b",
        marker: {
          enabled: true
        },
        pointPlacement: 'on',

      }
    },
    series: [{
      name: '',
      data: this.generateErrorData()
    }]
  }
);

  ngOnInit() {
    if (this._processService.selectedBusinessProcess !== undefined) {
      this._processService.emitProcessDetailPage(true);
      this._processService.getProcessDetailbyId().subscribe(response => {
        this.process = this._processService.prepareProcess(response);
      });
    } else {
      this._router.navigateByUrl('root/dashboard/view/processview/on');
    }
  }

}

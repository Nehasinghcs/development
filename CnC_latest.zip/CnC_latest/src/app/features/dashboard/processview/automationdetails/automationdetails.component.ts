import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { ProcessService } from '../processview.service';
import { ISubscription } from 'rxjs/Subscription';
import { SharedService } from '../../../../../services/shared.service';
import { Constants } from '../../../../utility/app.constants';

@Component({
    selector: 'app-automation-details',
    templateUrl: './automationdetails.component.html'
})

export class AutomationdetailsComponent implements OnInit, OnDestroy {

    isProcessDetailPage: boolean;
    subscription_1: ISubscription;

    constructor(private _processService: ProcessService, private _sharedService: SharedService, private _router: Router) {
        this.subscription_1 = this._processService.changeViewEmitted.subscribe(value => {
            setTimeout(() => this.isProcessDetailPage = value, 0);
        });
    }

    ngOnDestroy(): void {
        this.subscription_1.unsubscribe();
    }

    getGroupOrProcessName() {
        if (this.isProcessDetailPage) {
            if (this._processService.selectedBusinessProcess) {
                return this._processService.selectedBusinessProcess.name;
            }
        } else {
            if (this._processService.selectedBusinessProcessGroup) {
                return this._processService.selectedBusinessProcessGroup.name;
            }
        }
    }

    goToNextview() {
        if (this._processService.processParentPage !== undefined) {
            if (this._processService.processParentPage === Constants.processOn) {
                this._processService.processParentPage = undefined;
                this._processService.processGroupParentPage = undefined;
                this._router.navigateByUrl('root/dashboard/view/processview/on');
            } else if (this._processService.processParentPage === Constants.groupDetail) {
                this._processService.processParentPage = undefined;
                this._router.navigateByUrl('root/dashboard/view/automation/groupdetail');
            }
        } else if (this._processService.processGroupParentPage !== undefined) {
            if (this._processService.processGroupParentPage === Constants.processOn) {
                this._processService.selectedBusinessProcessGroup = undefined;
                this._router.navigateByUrl('root/dashboard/view/processview/on');
            } else if (this._processService.processGroupParentPage === Constants.processOff) {
                this._processService.selectedBusinessProcessGroup = undefined;
                this._router.navigateByUrl('root/dashboard/view/processview/off');
            }
        }
    }

    changeViewSize() {
        this._sharedService.emitViewSizeChange(!this._sharedService.showFullScreen);
    }

    getFullScreenParameter() {
        return this._sharedService.showFullScreen;
    }

    ngOnInit(): void {
        this._sharedService.emitWidgetChange(this._sharedService.currentView, 2);
        this._sharedService.emitViewChange(2);
    }
}

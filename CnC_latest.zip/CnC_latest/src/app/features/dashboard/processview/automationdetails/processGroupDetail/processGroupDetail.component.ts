import { Component, OnInit } from '@angular/core';
import { Chart, MapChart, Highcharts } from 'angular-highcharts';
import { ProcessService } from '../../processview.service';
import { Router } from '@angular/router';
import { BusinessProcess } from '../../../../../class/operationalClasses/businessProcess';
import { UtilityService } from '../../../../../utility/utility.services';
import { SharedService } from '../../../../../../services/shared.service';
import { Constants } from '../../../../../utility/app.constants';
import { ColumnChart } from '../../../../../shared/cnc-charts/columnchart/columnchart.component';
import { BubbleChartComponent } from '../../../../../shared/cnc-charts/bubblechart/bubblechart.component';

@Component({
  selector: 'app-process-group-detail',
  templateUrl: './processGroupDetail.component.html',
  styleUrls: ['./processGroupDetail.component.scss'],
  providers: [ColumnChart, BubbleChartComponent]
})

export class processGroupDetailComponent implements OnInit {

  logType_error: string = Constants.logType_error;
  logType_warning: string = Constants.logType_warning;
  logType_info: string = Constants.logType_info;
  processList: BusinessProcess[];
  processData: BusinessProcess;
  alertList: any[];
  columnChartCategory: any[] = [];
  columnChartData: any[] = [];
  columnChartThreshold: any[] = [];
  columnChartCategoryData: any[] = new Array();
  smallPlot: any = 10;
  processParentPage = Constants.groupDetail;
  plotType: string = Constants.type_normal;


  constructor(private _utilityService: UtilityService, private _processService: ProcessService, private _sharedService: SharedService, private _router: Router) { }

  goToProcessview() {
    this._router.navigateByUrl('root/dashboard/view/processview');
  }

  switchToSP2Details() {
    this._router.navigateByUrl('root/dashboard/view/automation/process');
  }

  getNotificationCount(logType: string) {
    if (this.alertList !== undefined && this.alertList.length) {
      return this.alertList.filter(element => element.logType === logType)[0].count;
    } else {
      return 0;
    }
  }

  getSLABreachedAutomation() {
    if (this.processData !== undefined) {
      return this.processData.slaBreachCount;
    }
  }

  getCriticalAutomation() {
    if (this.processList !== undefined) {
      return this.processList.filter(element => element.critical).length;
    }
  }

  getTotalAutomation() {
    if (this.processList !== undefined) {
      return this.processList.length;
    }
  }

  getProcessGroupName() {
    if (this._processService.selectedBusinessProcessGroup !== undefined) {
      return this._processService.selectedBusinessProcessGroup.name;
    }
  }

  getProcessGroupDesc() {
    if (this.processList !== undefined) {
      return this.processList[0].desc;
    }
  }

  isCritical(processId) {
    return this.processList.filter(element => element.id === processId && element.critical).length ? 1 : 0;
  }

  ngOnInit() {
    if (this._processService.selectedBusinessProcessGroup !== undefined) {
      this._processService.emitProcessDetailPage(false);
      this._sharedService.emitOperationalSpinnerChange(true);
      this._processService.getGroupDetailbyId().subscribe(response => {
        this.processList = this._processService.prepareProcessList(response.processDetails);
        this.processData = this._processService.prepareProcess(response);
        this.alertList = response.alertCount;
        this._sharedService.emitOperationalSpinnerChange(false);
        this._processService.crrByGroupProcessId().subscribe(crrResponse => {
          crrResponse = { 'failedCasesDetails': [{ 'failedCases': 19, 'businessProcessId': '50750fbd-00f8-11e8-885a-d067e5019012', 'businessProcessName': 'Payroll Processing' }] };
          if (crrResponse !== null && crrResponse.failedCasesDetails !== null) {
            crrResponse.failedCasesDetails.forEach(element => {
              this.columnChartCategory.push(element.businessProcessGroupName);
              this.columnChartData.push(element.failedCases);
              this.columnChartThreshold.push(this.isCritical(element.businessProcessId));
            });
            this.columnChartCategoryData.push(this.columnChartCategory, this.columnChartData, this.columnChartThreshold);
          }
        }, (error) => {
          this._utilityService.handleException(error);
        });
      }, (error) => {
        this._sharedService.emitOperationalSpinnerChange(false);
        this._utilityService.handleException(error);
      });

    } else {
      this._router.navigateByUrl('root/dashboard/view/processview/on');
    }
  }

}

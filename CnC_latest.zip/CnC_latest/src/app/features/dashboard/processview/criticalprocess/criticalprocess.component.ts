import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Chart, MapChart, Highcharts } from 'angular-highcharts';
import { ProcessService } from '../processview.service';
import { ISubscription } from 'rxjs/Subscription';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { BusinessProcess } from '../../../../class/operationalClasses/businessProcess';
import { UtilityService } from '../../../../utility/utility.services';
import { SharedService } from '../../../../../services/shared.service';
import { ColumnChart } from '../../../../shared/cnc-charts/columnchart/columnchart.component';

@Component({
  selector: 'app-criticalprocess',
  templateUrl: './criticalprocess.component.html',
  styleUrls: ['./criticalprocess.component.scss'],
  providers: [ColumnChart]
})
export class CriticalprocessComponent implements OnInit, OnDestroy {

  totalVal: number;
  show: boolean;
  isProcessViewOn: boolean;
  subscription_1: ISubscription;
  businessProcessList: BusinessProcess[];
  columnChartCategory: any[] = [];
  columnChartData: any[] = [];
  columnChartThreshold: any[] = [];
  columnChartCategoryData: any[] = new Array();

  constructor(private _utilityService: UtilityService, private _router: Router, private _sharedService: SharedService, private _processService: ProcessService) {
    this.subscription_1 = this._sharedService.changeProcessViewEmitted.subscribe(response => {
      setTimeout(() => {
        this.isProcessViewOn = response;
        this.getProcessList(this.isProcessViewOn);
      }, 0);
    });
  }

  isCrtical(groupId, processList) {
    return processList.filter(element => element.businessProcessGroupId === groupId && element.critical).length ? 1 : 0;
  }

  crrByAccountId(processList: BusinessProcess[]) {
    this._processService.crrByAccountId().subscribe(crrResponse => {
      crrResponse = { 'failedCasesDetails': [{ 'failedCases': 19, 'businessProcessGroupId': '87d06334-00c5-11e8-885a-d067e5019012', 'businessProcessGroupName': 'P2P' }] };
      if (crrResponse !== null && crrResponse.failedCasesDetails !== null) {
        crrResponse.failedCasesDetails.forEach(element => {
          this.columnChartCategory.push(element.businessProcessGroupName);
          this.columnChartData.push(element.failedCases);
          this.columnChartThreshold.push(this.isCrtical(element.businessProcessGroupId, processList));
          // this.columnChartThreshold.push(20);
        });
        this.columnChartCategoryData.push(this.columnChartCategory, this.columnChartData, this.columnChartThreshold);
      }
    });
  }

  isCritical(groupId, processDetail: any[]) {
    return processDetail.filter(element => element.businessProcessGroupId === groupId && element.critical).length ? true : false;
  }

  ngOnDestroy(): void {
    this.subscription_1.unsubscribe();
  }

  getUniqueGroupIds(list) {
    return list.map(item => item.businessProcessGroupId).filter((value, index, self) => self.indexOf(value) === index && value !== null);
  }

  getProcessList(type) {
    this._sharedService.emitOperationalSpinnerChange(true);
    this._processService.getProcessList().subscribe(response => {
      if (response !== null) {
        this.businessProcessList = this._processService.prepareProcessList(response.processDetail);
        this.crrByAccountId(this.businessProcessList);
        if (type) {
          this.prepareDataForProcess_on();
        } else {
          this.prepareDataForProcess_off(this.getUniqueGroupIds(response.processDetail), response.processDetail);
        }
      }
      this._sharedService.emitOperationalSpinnerChange(false);
    }, (error) => {
      this._sharedService.emitOperationalSpinnerChange(false);
      this._utilityService.handleException(error);
    });
  }

  prepareDataForProcess_off(groupIdsList: any[], processList: any[]) {
    this._processService.emitProcessDataChange(this._processService.prepareDataForProcess_off(groupIdsList, processList));
  }

  prepareDataForProcess_on() {
    if (this.businessProcessList.length) {
      const processGroupList = this._processService.prepareDataForProcess_on(this.businessProcessList);
      this._processService.emitProcessDataChange(processGroupList);
      if (processGroupList.length > 4) {
        this._router.navigateByUrl('root/dashboard/view/processview/off');
      }
    }
  }

  getCount(type) {
    if (this.businessProcessList !== undefined) {
      let returnValue = 0;
      switch (type) {
        case 'critical':
          returnValue = this.businessProcessList.filter(element => element.critical).length;
          break;
        case 'noncritical':
          returnValue = this.businessProcessList.filter(element => !element.critical).length;
          break;
        case 'others':
          returnValue = this.totalVal - (this.businessProcessList.length);
      }
      return returnValue;
    }
  }

  getFullScreenParameter() {
    return this._sharedService.showFullScreen;
  }

  changeViewSize() {
    this._sharedService.emitViewSizeChange(!this._sharedService.showFullScreen);
  }

  switchToprocessView() {
    if (this.isProcessViewOn) {
      this.isProcessViewOn = false;
      this._router.navigateByUrl('root/dashboard/view/processview/off');
    } else {
      this.isProcessViewOn = true;
      this._router.navigateByUrl('root/dashboard/view/processview/on');
    }
  }

  showdropdown() {
    if (!this.show) {
      this.show = true;
    } else {
      this.show = false;
    }
  }

  getbotCountVal() {
    /*this._processService.getBotCount().subscribe(response => {
      this.totalVal = response.count;
    })*/
    this.totalVal = 84; // Hard coded as per 10-Feb requirement

  }

  ngOnInit() {
    this.show = false;
    this._sharedService.emitWidgetChange(this._sharedService.currentView, 2);
    this._sharedService.emitViewChange(2);
    this.getbotCountVal();
  }

}

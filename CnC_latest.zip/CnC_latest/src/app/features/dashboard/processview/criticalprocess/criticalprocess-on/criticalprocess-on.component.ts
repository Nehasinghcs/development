import { Component, OnInit, OnDestroy } from '@angular/core';
import { Chart, MapChart, Highcharts } from 'angular-highcharts';
import { Router } from '@angular/router';
import { ProcessService } from '../../processview.service';
import { ISubscription } from 'rxjs/Subscription';
import { SharedService } from '../../../../../../services/shared.service';
import { Constants } from '../../../../../utility/app.constants';
import { BubbleChartComponent } from '../../../../../shared/cnc-charts/bubblechart/bubblechart.component';

@Component({
  selector: 'app-criticalprocess-on',
  templateUrl: './criticalprocess-on.component.html',
  styleUrls: ['../criticalprocess.component.scss'],
  providers: [BubbleChartComponent]
})
export class CriticalprocessOnComponent implements OnInit, OnDestroy {

  processGroupList: any = new Array<any>();
  smallPlot: any = 11;
  processParentPage: string = Constants.processOn;
  plotType: string = Constants.type_hexagon;
  subscription_1: ISubscription;

  constructor(private _processService: ProcessService, private _router: Router, private _sharedService: SharedService) {
    this.subscription_1 = this._processService.emitProcessData.subscribe(value => {
      setTimeout(() => {
        this.processGroupList = value;
      }, 0);
    });
  }

  ngOnDestroy(): void {
    this.subscription_1.unsubscribe();
  }

  switchToGroupDetail(groupId: string, groupName: string) {
    this._processService.setSelectedBusinessProcessGroup(groupId, groupName);
    this._processService.processGroupParentPage = Constants.processOn;
    this._router.navigateByUrl('root/dashboard/view/automation/groupdetail');
  }

  isCritical(groupId, processDetail: any[]) {
    return processDetail.filter(element => element.businessProcessGroupId === groupId && element.critical).length ? true : false;
  }

  ngOnInit() {
    this._sharedService.emitIsProcessViewChange(true);
  }

}

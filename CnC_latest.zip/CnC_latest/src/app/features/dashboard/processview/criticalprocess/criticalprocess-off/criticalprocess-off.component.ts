import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Chart, Highcharts, HIGHCHARTS_MODULES } from 'angular-highcharts';
import { ProcessService } from '../../processview.service';
import { ISubscription } from 'rxjs/Subscription';
import { SharedService } from '../../../../../../services/shared.service';

@Component({
    selector: 'app-criticalprocess-off',
    templateUrl: './criticalprocess-off.component.html',
    styleUrls: ['./criticalprocess-off.component.scss']
})
export class CriticalprocessOffComponent implements OnInit {

    hexagonMap: any;
    subscription_1: ISubscription;
    processGroupList: any;

    constructor(private _processService: ProcessService, private _sharedService: SharedService) {
        this.subscription_1 = this._processService.emitProcessData.subscribe(hexagonMap => {
            setTimeout(() => {
                this.hexagonMap = hexagonMap;
                if (hexagonMap.options !== undefined) {
                    this.processGroupList = hexagonMap.options.series[0].data.length;
                }
            }, 0);
        });
    }

    ngOnInit() {
        this._sharedService.emitIsProcessViewChange(false);
    }

}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Chart, MapChart } from 'angular-highcharts';
import { TicketService } from '../tickets/tickets.service';
import { SharedService } from '../../../../services/shared.service';

@Component({
  selector: 'app-ticketmetrics',
  templateUrl: './ticketmetrics.component.html',
  styleUrls: ['./ticketmetrics.component.scss']
})
export class TicketmetricsComponent implements OnInit {


  dataLoaded: boolean;
  pieChartSettings = {
    dlenabled: true,
    y: 22,
    x: 5,
    margin: [0, 0, 0, 0],
    height: 0,
    startAngle: -180,
    endAngle: 180,
    center: ['50%', '55%'],
    p1: 0,
    p2: 0,
    p3: 0,
    titleText: ''
  };
  constructor(private _sharedService: SharedService, private _ticketService: TicketService, private _router: Router) { }

  changeViewSize() {
    this._sharedService.emitViewSizeChange(!this._sharedService.showFullScreen);
  }

  getFullScreenParameter() {
    return this._sharedService.showFullScreen;
  }
  ngOnInit() {
    this._sharedService.emitWidgetChange(this._sharedService.currentView, 8);
    this._sharedService.emitViewChange(8);

    this.pieChartSettings.p1 = 35;
    this.pieChartSettings.p2 = 30;
    this.pieChartSettings.p3 = 35;
    this.pieChartSettings.height = 200;
    this.pieChartSettings.margin = [20, 0, 0];
    this.pieChartSettings.titleText =
    '<span style="font-family: OpenSans;font-size: 28px;font-weight: bold;text-align: center;color: #394961;">'
    + (this.pieChartSettings.p1 + this.pieChartSettings.p2 + this.pieChartSettings.p3)
    + '</span><br><span style="font-size: 14px; text-align: center; font-family: OpenSans;color: #394961;">Total</span>';
    this.dataLoaded = true;
  }
}

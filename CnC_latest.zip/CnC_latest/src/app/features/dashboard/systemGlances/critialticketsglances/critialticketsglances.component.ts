import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TicketService } from '../../tickets/tickets.service';
import { Tickets } from '../../../../class/operationalClasses/tickets';
import { UtilityService } from '../../../../utility/utility.services';
import { SharedService } from '../../../../../services/shared.service';
import { PieChart } from '../../../../shared/cnc-charts/piechart/piechart.component';

@Component({
  selector: 'app-critialticketsglances',
  templateUrl: './critialticketsglances.component.html',
  styleUrls: ['../systemglances.scss'],
  providers: [PieChart]

})

export class CritialticketsglancesComponent implements OnInit {

  dataLoaded: boolean;
  tickets: Tickets[];
  totalP1tickets: number;
  totalP2tickets: number;
  totalP3tickets: number;
  pieChartSettings = {
    margin: [30, 0, 0, 0],
    height: 0,
    startAngle: -180,
    endAngle: 180,
    center: ['50%', '60%'],
    size: '79%',
    y: 2,
    x: 4,
    p1: 4,
    p2: 2,
    p3: 3,
    titleText: ''
  };

  constructor(private _utilityService: UtilityService, private _sharedService: SharedService,
    private _ticketService: TicketService, private _router: Router) { }

  releaseDrop() {
    this._router.navigateByUrl('root/dashboard/view/criticaltickets');
  }

  ngOnInit() {
    this.pieChartSettings.titleText =
    '<span style="font-family: OpenSans;font-size: 28px;font-weight: bold;text-align: center;color: #394961;">'
    + (this.pieChartSettings.p1 + this.pieChartSettings.p2 + this.pieChartSettings.p3)
    + '</span><br><span style="font-size: 14px; text-align: center; font-family: OpenSans;color: #394961;">Total</span>';
    if (this._sharedService.tickets !== undefined) {
      this.tickets = this._sharedService.tickets;
      this.totalP1tickets = this.tickets.filter(ticket => ticket.type === 'P1').length;
      this.totalP2tickets = this.tickets.filter(ticket => ticket.type === 'P2').length;
      this.totalP3tickets = this.tickets.filter(ticket => ticket.type === 'P3').length;
      this.pieChartSettings.p1 = this.totalP1tickets;
      this.pieChartSettings.p2 = this.totalP2tickets;
      this.pieChartSettings.p3 = this.totalP3tickets;
      this.pieChartSettings.height = 105;
      this.pieChartSettings.margin = [-20, 0, 0];
      this.dataLoaded = true;
    } else {
      this._ticketService.getDataFromJSON().subscribe(response => {
        this.tickets = this._ticketService.prepareTickets(response.ticketDetails);
        this.totalP1tickets = this.tickets.filter(ticket => ticket.type === 'P1').length;
        this.totalP2tickets = this.tickets.filter(ticket => ticket.type === 'P2').length;
        this.totalP3tickets = this.tickets.filter(ticket => ticket.type === 'P3').length;
        this._sharedService.emitCriticalTicket(this.tickets);
        this.pieChartSettings.p1 = this.totalP1tickets;
        this.pieChartSettings.p2 = this.totalP2tickets;
        this.pieChartSettings.p3 = this.totalP3tickets;
        this.pieChartSettings.height = 105;
        this.pieChartSettings.margin = [-10, 0, 0];
        this.dataLoaded = true;
      }, (error) => {
        this._utilityService.handleException(error);
      });
    }
  }

}

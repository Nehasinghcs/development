import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { Constants } from '../../../../utility/app.constants';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss', '../systemglances.scss']
})
export class NotificationsComponent implements OnInit {

  @Input() glancesdata: any[];
  logType_info: string = Constants.logType_info;
  logType_error: string = Constants.logType_error;
  logType_warning: string = Constants.logType_warning;

  constructor(private _router: Router) { }

  releaseDrop() {
    this._router.navigateByUrl('root/dashboard/view/notifications');
  }

  getLogCount(logType) {
    if (this.glancesdata !== undefined) {
      let returnValue: number;
      switch (logType) {
        case this.logType_error:
          returnValue = (this.glancesdata.filter(element =>
            element.logType === this.logType_error).length) ?
             this.glancesdata.filter(element => element.logType === this.logType_error)[0].count : 0;
          break;
        case this.logType_warning:
          returnValue = (this.glancesdata.filter(element =>
            element.logType === this.logType_warning).length)
            ? this.glancesdata.filter(element => element.logType === this.logType_warning)[0].count : 0;
          break;
        case this.logType_info:
          returnValue = (this.glancesdata.filter(element =>
            element.logType === this.logType_info).length)
            ? this.glancesdata.filter(element => element.logType === this.logType_info)[0].count : 0;
          break;
      }
      return returnValue;
    } else {
      return 0;
    }
  }

  ngOnInit() {
  }

}

import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-automation',
  templateUrl: './automation.component.html',
  styleUrls: ['./automation.component.scss', '../systemglances.scss']
})
export class AutomationComponent implements OnInit {

  @Input() glancesdata: any;
  pieChartSettings = {
    height: 105,
    startAngle: -180,
    endAngle: 180,
    center: ['50%', '25%'],
    size: '150%',
    y: -10,
    x: 0,
    p1: 6,
    p2: 0,
    p3: 23,
    titleText: ''
  };
  constructor(private _router: Router) { }

  releaseDrop() {
    this._router.navigateByUrl('root/dashboard/view/automationview/allaccounts');
  }

  ngOnInit() {
    this.pieChartSettings.titleText =
    '<span style="font-family: OpenSans;font-size: 28px;font-weight: bold;text-align: center;color: #394961;">'
    + (this.pieChartSettings.p1 + this.pieChartSettings.p2 + this.pieChartSettings.p3)
    + '</span><br><span style="font-size: 14px; text-align: center; font-family: OpenSans;color: #394961;">Total</span>';
  }

}

import { Directive, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Chart, MapChart } from 'angular-highcharts';
import { ExceptionAnalysysService } from '../../analysis/exceptionanalysis.service';
import { ToasterService } from 'angular2-toaster/src/toaster.service';
import { Exception } from '../../../../class/operationalClasses/exception';
import { UtilityService } from '../../../../utility/utility.services';
import { SharedService } from '../../../../../services/shared.service';
import { PieChart } from '../../../../shared/cnc-charts/piechart/piechart.component';

@Component({
  selector: 'app-exceptionanalysis',
  templateUrl: './exceptionanalysis.component.html',
  styleUrls: ['./exceptionanalysis.component.scss', '../systemglances.scss'],
  providers: [PieChart]
})
export class ExceptionanalysisComponent implements OnInit {

  exceptionList: Exception[];
  dataLoaded: boolean;
  businessExceptionCount = 0;
  codeExceptionCount = 0;
  infraExceptionCount = 0;

  pieChartSettings = {
    height: 105,
    startAngle: -90,
    endAngle: 90,
    center: ['50%', '90%'],
    size: '280%',
    y: 0,
    p1: 0,
    p2: 0,
    p3: 0,
    titleText: ''
  };

  constructor(private _utilityService: UtilityService, private _toasterService: ToasterService,
    private _sharedService: SharedService, private _exceptionAnalysysService: ExceptionAnalysysService, private _router: Router) { }

  releaseDrop() {
    this._router.navigateByUrl('root/dashboard/view/analysis');
  }

  ngOnInit() {
    this.pieChartSettings.p1 = this.businessExceptionCount;
    this.pieChartSettings.p2 = this.codeExceptionCount;
    this.pieChartSettings.p3 = this.infraExceptionCount;
    this.pieChartSettings.titleText =
    '<span style="font-family: OpenSans;font-size: 28px;font-weight: bold;text-align: center;color: #394961;">'
    + (this.pieChartSettings.p1 + this.pieChartSettings.p2 + this.pieChartSettings.p3)
    + '</span><br><span style="font-size: 14px; text-align: center; font-family: OpenSans;color: #394961;">Total</span>';
    // if (this._sharedService.exceptionList !== undefined) {
    //   this.exceptionList = this._sharedService.exceptionList;
    //   this.businessExceptionCount = this.exceptionList.filter(element => element.exceptionType.toLowerCase() === Constants.exceptionType_business).length;
    //   this.codeExceptionCount = this.exceptionList.filter(element => element.exceptionType.toLowerCase() === Constants.exceptionType_code).length;
    //   this.infraExceptionCount = this.exceptionList.filter(element => element.exceptionType.toLowerCase() === Constants.exceptionType_Infrastructure).length;
    //   this.pieChartSettings.p1 = this.businessExceptionCount;
    //   this.pieChartSettings.p2 = this.codeExceptionCount;
    //   this.pieChartSettings.p3 = this.infraExceptionCount;
    //   this.pieChartSettings.titleText= '<span style="font-family: OpenSans;font-size: 28px;font-weight: bold;text-align: center;color: #394961;">' + (this.pieChartSettings.p1 + this.pieChartSettings.p2 + this.pieChartSettings.p3) + '</span><br><span style="font-size: 14px; text-align: center; font-family: OpenSans;color: #394961;">Total</span>'
    //   this.dataLoaded = true;
    // } else {
    //   this._exceptionAnalysysService.getAlertDetail().subscribe(response => {
    //     this.exceptionList = this._exceptionAnalysysService.prepareExceptionList(response.logDetails);
    //     this._sharedService.exceptionList = this.exceptionList;
    //     this.businessExceptionCount = this.exceptionList.filter(element => element.exceptionType.toLowerCase() === Constants.exceptionType_business).length;
    //     this.codeExceptionCount = this.exceptionList.filter(element => element.exceptionType.toLowerCase() === Constants.exceptionType_code).length;
    //     this.infraExceptionCount = this.exceptionList.filter(element => element.exceptionType.toLowerCase() === Constants.exceptionType_Infrastructure).length;
    //     this.pieChartSettings.p1 = this.businessExceptionCount;
    //     this.pieChartSettings.p2 = this.codeExceptionCount;
    //     this.pieChartSettings.p3 = this.infraExceptionCount;
    //     this.pieChartSettings.titleText= '<span style="font-family: OpenSans;font-size: 28px;font-weight: bold;text-align: center;color: #394961;">' + (this.pieChartSettings.p1 + this.pieChartSettings.p2 + this.pieChartSettings.p3) + '</span><br><span style="font-size: 14px; text-align: center; font-family: OpenSans;color: #394961;">Total</span>'
    //     this.dataLoaded = true;
    //   }, (error) => {
    //     this._utilityService.handleException(error);
    //   });
    // }

  }

}

import { Injectable } from '@angular/core';
import { UtilityService } from '../../../utility/utility.services';
import { DataService } from '../../../../services/data.services';
import { AppSettings } from '../../../utility/app.settings';

@Injectable()

export class SystemGlanceService {
    constructor(private _utilityService: UtilityService, private _dataService: DataService) { }

    getSystemGlances() {
        const reqData = {
            tool: [
                'BP', 'AA', 'UI'
            ],
            vertical: [
                {
                    accountIds: [
                        localStorage.accountId
                    ],
                    verticalId: localStorage.verticalId
                }
            ]
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_SYSTEM_GLANCES, reqData);
    }
}

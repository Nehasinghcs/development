import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ContinentalService } from '../../hotspots/continental/continental.service';
import { Constants } from '../../../../utility/app.constants';

@Component({
  selector: 'app-exceptionhotspots',
  templateUrl: './exceptionhotspots.component.html',
  styleUrls: ['../systemglances.scss']
})
export class ExceptionhotspotsComponent implements OnInit {

  view: any;
  mapdata: any;

  constructor(private _continentalService: ContinentalService, private _router: Router) { }

  releaseDrop() {
    this._router.navigateByUrl('root/dashboard/view/hotspots');
  }

  ngOnInit() {
    this.view = 'snapshot';
    this._continentalService.getDataFromJSON(Constants.world_map_jsonName).subscribe(response => {
      this.mapdata = response;
    });
  }

}

import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { Constants } from '../../../../utility/app.constants';

@Component({
  selector: 'app-workforceavailability',
  templateUrl: './workforceavailability.component.html',
  styleUrls: ['./workforceavailability.component.scss', '../systemglances.scss']
})
export class WorkforceavailabilityComponent implements OnInit {

  @Input() glancesdata: any;
  busyRobots = Constants.busyRobots;
  idleRobots = Constants.idleRobots;
  criticalRobots = Constants.criticalRobots;
  _undefined = Constants._undefined;

  constructor(private _router: Router) { }

  getWidth(type) {
    if (this.glancesdata !== undefined) {
      let returnValue: number;
      const total = this.glancesdata.busyRobots + this.glancesdata.idleRobots + this.glancesdata.criticalRobots;
      switch (type) {
        case this.criticalRobots:
          returnValue = (this.glancesdata.criticalRobots / total) * 100;
          break;
        case this.busyRobots:
          returnValue = (this.glancesdata.busyRobots / total) * 100;
          break;
        case this.idleRobots:
          returnValue = (this.glancesdata.idleRobots / total) * 100;
          break;
      }
      return returnValue + '%';
    } else {
      return 0;
    }
  }

  getWorkForceCount(type) {
    if (this.glancesdata !== undefined) {
      let returnValue: number;
      switch (type) {
        case undefined:
          returnValue = this.glancesdata.busyRobots + this.glancesdata.idleRobots + this.glancesdata.criticalRobots;
          break;
        case this.criticalRobots:
          returnValue = this.glancesdata.criticalRobots;
          break;
        case this.busyRobots:
          returnValue = this.glancesdata.busyRobots;
          break;
        case this.idleRobots:
          returnValue = this.glancesdata.idleRobots;
          break;
      }
      return returnValue;
    } else {
      return 0;
    }
  }

  releaseDrop() {
    this._router.navigateByUrl('root/dashboard/view/workforce');
  }

  ngOnInit() {
  }

}

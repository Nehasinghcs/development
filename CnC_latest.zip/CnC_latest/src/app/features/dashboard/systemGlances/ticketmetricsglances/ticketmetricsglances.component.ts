import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ticketmetricsglances',
  templateUrl: './ticketmetricsglances.component.html',
  styleUrls: ['./ticketmetricsglances.component.scss', '../systemglances.scss']
})
export class TicketmetricsglancesComponent implements OnInit {

  pieChartSettings = {
    height: 74.3,
    startAngle: -180,
    endAngle: 180,
    center: ['50%', '70%'],
    size: '350%',
    y: 6,
    x: -1,
    p1: 35,
    p2: 35,
    p3: 30,
    titleText: ''
  };
  constructor(private _router: Router) { }

  releaseDrop() {
    this._router.navigateByUrl('root/dashboard/view/ticketmetrics');
  }

  ngOnInit() {
    this.pieChartSettings.titleText =
    '<span style="font-family: OpenSans;font-size: 12px;font-weight: normal;text-align: center;color: #394961;">'
     + (this.pieChartSettings.p1 + this.pieChartSettings.p2 + this.pieChartSettings.p3) + '</span>';
  }
}

import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { ProcessService } from '../../processview/processview.service';
import { Constants } from '../../../../utility/app.constants';

@Component({
  selector: 'app-processviewglances',
  templateUrl: './processviewglances.component.html',
  styleUrls: ['./processviewglances.component.scss', '../systemglances.scss']
})
export class ProcessviewglancesComponent implements OnInit {

  @Input() glancesdata: any;
  nonCriticalProcessCount: string = Constants.nonCriticalProcessCount;
  criticalProcessCount: string = Constants.criticalProcessCount;

  constructor(private _processService: ProcessService, private _router: Router) { }

  getProcessCount(type) {
    if (this.glancesdata !== undefined) {
      let returnValue = 0;
      switch (type) {
        case this.criticalProcessCount:
          returnValue = this.glancesdata.criticalProcessCount;
          break;
        case this.nonCriticalProcessCount:
          returnValue = this.glancesdata.nonCriticalProcessCount;
          break;
      }
      return returnValue;
    } else {
      return 0;
    }
  }

  releaseDrop() {
    this._router.navigateByUrl('root/dashboard/view/processview');
  }

  ngOnInit() {
  }

}

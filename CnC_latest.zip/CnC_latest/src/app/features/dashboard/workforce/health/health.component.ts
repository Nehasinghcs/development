import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Chart, MapChart, Highcharts, HIGHCHARTS_MODULES } from 'angular-highcharts';
import { RobotService } from '../robot.service';
import { Subject } from 'rxjs/Subject';
import { Response } from '@angular/http/src/static_response';
import { UtilityService } from '../../../../utility/utility.services';
import { SharedService } from '../../../../../services/shared.service';
import { Constants } from '../../../../utility/app.constants';

@Component({
  selector: 'app-workforceview',
  templateUrl: './health.component.html',
  styleUrls: ['./health.component.scss']
})
export class HealthComponent implements OnInit {

  constructor(private _utilityService: UtilityService, private _robotService: RobotService,
    private _router: Router, private _sharedService: SharedService) { }

  robotList: any[];
  robotStatusDisconnected: string = Constants.robotStatusDisconnected.toLowerCase();
  robotStatusBusy: string = Constants.robotStatusBusy.toLowerCase();
  robotStatusIdle: string = Constants.robotStatusIdle.toLowerCase();
  _undefined = Constants._undefined;
  runningColor = '#5cd78d';
  criticalColor = '#ff5965';
  idleColor = '#aaaaaa';
  robotBorderColor = '#ffffff';
  robothealth;
  plotDataArray = [];

  getRobotCount_Status(status) {
    let returnValue = 0;
    if (this.robotList !== undefined && this.robotList !== null && this.robotList.length) {
      switch (status) {
        case undefined:
          this.robotList.forEach(element => {
            element.accounts.forEach(accountElement => {
              returnValue += accountElement.robots.filter(
                _robot => _robot.robotStatus.toLowerCase() === this.robotStatusDisconnected).length +
                accountElement.robots.filter(_robot => _robot.robotStatus.toLowerCase() === this.robotStatusBusy).length +
                accountElement.robots.filter(_robot => _robot.robotStatus.toLowerCase() === this.robotStatusIdle).length;
            });
          });
          break;
        case this.robotStatusDisconnected:
          this.robotList.forEach(element => {
            element.accounts.forEach(accountElement => {
              returnValue += accountElement.robots.filter(_robots => _robots.robotStatus.toLowerCase() === status.toLowerCase()).length;
            });
          });
          break;
        case this.robotStatusBusy:
          this.robotList.forEach(element => {
            element.accounts.forEach(accountElement => {
              returnValue += accountElement.robots.filter(_robots => _robots.robotStatus.toLowerCase() === status.toLowerCase()).length;
            });
          });
          break;
        case this.robotStatusIdle:
          this.robotList.forEach(element => {
            element.accounts.forEach(accountElement => {
              returnValue += accountElement.robots.filter(_robots => _robots.robotStatus.toLowerCase() === status.toLowerCase()).length;
            });
          });
          break;
      }
    }
    return returnValue;
  }

  generateWorkforceHealthData(verticals: any[]) {
    if (verticals !== null) {
      const parentArray = [];
      const verticalColor = '#ffffff';
      const accountColor = '#dddddd';
      const parentNode = {
        id: '0',
        parent: '',
        name: 'Robot Health'
      };
      parentArray.push(parentNode);

      verticals.forEach((element, index) => {
        const obj = {
          id: 1 + index.toString(),
          parent: parentNode.id,
          name: element.verticalName,
          color: verticalColor
        };
        parentArray.push(obj);
        element.accounts.forEach((account, accountIndex) => {
          const accountObj = {
            id: 100 + index.toString() + accountIndex.toString(),
            parent: obj.id,
            name: account.accountName,
            color: accountColor
          };
          parentArray.push(accountObj);
          account.robots.forEach(robot => {
            if (robot.robotStatus.toLowerCase() === this.robotStatusDisconnected
              || robot.robotStatus.toLowerCase() === this.robotStatusBusy || robot.robotStatus.toLowerCase() === this.robotStatusIdle) {
              const robotObj = {
                id: robot.robotId,
                parent: accountObj.id,
                name: robot.robotName,
                hostName: robot.hostName,
                color: (robot.robotStatus.toLowerCase() ===
                  this.robotStatusDisconnected ?
                  this.criticalColor : (robot.robotStatus.toLowerCase() === this.robotStatusBusy) ? this.runningColor : this.idleColor),
                value: 1,
                location: robot.locationId,
                isRobot: true,
                account: accountObj.name,
                vertical: obj.name
              };
              parentArray.push(robotObj);
            }
          });
        });
      });
      return parentArray;
    }
  }

  onClick = (event: any) => {
    if (event.point.isRobot !== undefined) {
      this._robotService.selectedRobot = {
        name: event.point.name,
        status: event.point.status,
        from: 'health',
        id: event.point.id,
        accountName: event.point.account,
        hostName: event.point.hostName,
      };
      this._robotService.emitSelectedRobot(this._robotService.selectedRobot);
      this._router.navigateByUrl('root/dashboard/view/workforce/robot');
    }
  }

  getSunburstChartConfiguration() {
    return new MapChart({
      chart: {
      },
      title: {
        text: ''
      },
      series: [{
        type: 'sunburst',
        data: this.plotDataArray,
        allowDrillToNode: false,
        cursor: 'pointer',
        events: {
          click: this.onClick
        },
        dataLabels: {
          format: '{point.name}',
          filter: {
            property: 'innerArcLength',
            operator: '>',
            value: 60
          },
          style: {
            textOutline: 'transparent',
            fontFamily: 'OpenSans-Semibold',
            whiteSpace: 'normal',
            overflow: 'hidden',
            textOverflow: 'inherit'
          }
        },
        levels: [{
          level: 1,
          levelIsConstant: false,
          dataLabels: {
            rotationMode: 'parallel',
            /* filter: {
                property: 'outerArcLength',
                operator: '<',
                value: 64
            } */
          }
        }, {
          level: 2,
          colorByPoint: true,
          colorVariation: {
            key: 'brightness',
            to: 0.5
          },
          dataLabels: {
            //  rotation: 10
            rotationMode: 'parallel'
          }
        },
        {
          level: 3,
          colorVariation: {
            key: 'brightness',
            to: -0.5
          },
          dataLabels: {
            rotation: 0
            // rotationMode: 'parallel'
          }
        }, {
          level: 4,
          dataLabels: {
            enabled: false
          },
          lineWidth: 5,
          colorVariation: {
            key: 'brightness',
            to: 0.5
          }
        }],

      }],
      /* plotOptions: {
         sunburst: {
           borderColor: '#9EA6A9',
         },
       },*/
      tooltip: {
        formatter: function () {
          if (this.point.isRobot === true) {

            return `
            <div style="background-color: #ffffff; margin: -7px -8px -8px -7px;cursor:pointer;">
              <div style="
                    text-align: center;
                    font-size: 13px;
                    font-weight: bold;
                    color: #626579;
                    font-family: OpenSans-Bold;
                    padding: 6px 0px;cursor:pointer;
              ">` + this.point.hostName + `</div>
              <div style="padding: 12px 19.8px 12px 20px;">
                  <table>
                  <tr>
                    <td style="font-size: 12px;font-weight: normal;color: #626579;">Vertical</td>
                    <td style="text-align: right;font-size: 13px;font-weight: bold;color: #626579;
                    font-family: OpenSans-Bold; margin-left:15px;">` + this.point.vertical + `</td>
                  </tr>
                  <tr>
                    <td style="font-size: 12px;font-weight: normal;color: #626579;">Geography</td>
                    <td style="text-align: right;font-size: 13px;font-weight: bold;color: #626579;
                    font-family: OpenSans-Bold;margin-left:15px;">` + this.point.location + `</td>
                  </tr>
                  <tr>
                    <td style="font-size: 12px;font-weight: normal;color: #626579;">Account</td>
                    <td style="text-align: right;font-size: 13px;font-weight: bold;color: #626579;
                    font-family: OpenSans-Bold;margin-left:15px;">` + this.point.account + `</td>
                  </tr>
                </table>
              </div>
             </div>
             `;
          } else {
            return false;
          }
        },
        useHTML: true,
        style: {
          fontFamily: 'OpenSans-Semibold',
          backgroundColor: 'white'
        },
      }
    });
  }

  ngOnInit() {
    this._sharedService.emitSpinnerChange(false);
    this._sharedService.emitOperationalSpinnerChange(true);
    Highcharts.getOptions().colors.splice(0, 0, 'transparent');
    this._robotService.emitIsRobotView(0);
    this._robotService.getRobotHealth().subscribe(response => {
      this.robotList = response.verticals;
      this.plotDataArray = this.generateWorkforceHealthData(response.verticals);
      this.robothealth = this.getSunburstChartConfiguration();
      this._sharedService.emitOperationalSpinnerChange(false);
    }, (error) => {
      this._sharedService.emitOperationalSpinnerChange(false);
      this._utilityService.handleException(error);
    });
  }
}

import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { UtilityService } from '../../../utility/utility.services';
import { DataService } from '../../../../services/data.services';
import { Robot } from '../../../class/operationalClasses/robot';
import { AppSettings } from '../../../utility/app.settings';
import { Constants } from '../../../utility/app.constants';

@Injectable()

export class RobotService {

    constructor(private _utilityService: UtilityService, private _dataService: DataService) { }
    reqData: any;
    selectedRobot: any;
    currentdate = new Date();
    private _emitSelectedRobot = new Subject<any>();
    changeRobotEmitted = this._emitSelectedRobot.asObservable();
    private _emitRobotSelected = new Subject<boolean>(); // 0 Health, 1- Utilization, 2 - Robot details
    emitRobotSelectionChange = this._emitRobotSelected.asObservable();
    private _emitRobotView = new Subject<number>();
    changeRobotViewEmitted = this._emitRobotView.asObservable();

    emitSelectedRobot(change: any) {
        this._emitSelectedRobot.next(change);
    }
    emitRobotSelected(change: boolean) {
        this._emitRobotSelected.next(change);
    }
    emitIsRobotView(change: number) {
        this._emitRobotView.next(change);
    }

    getRobotDetailById() {
        this.reqData = {
            robotId: this.selectedRobot.id
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_ROBOT_DETAILBY_ID, this.reqData);
    }

    getRobotHealth() {
        this.reqData = {
            tool: Constants.toolsList,
            vertical: [
                {
                    accountIds: [
                        localStorage.accountId
                    ],
                    verticalId: localStorage.verticalId
                }
            ]
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_ROBOT_HEALTH, this.reqData);
    }

    getRobotUpDowntime() {
        this.reqData = {
            accountId: localStorage.accountId,
            dateRange: {
                startDate: this._utilityService.getPreviousDayMonth(),
                endDate: this._utilityService.getPreviousDayMonth()
            },
            tool: Constants.toolsList
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_BREACH_ACCOUNT_ID, this.reqData);
    }

    getRobotKPIDetails() {
        this.reqData = {
            dateRange: {
                endDate: this._utilityService.getPreviousDayMonth(),
                startDate: this._utilityService.getPreviousDayMonth()
            },
            tool: Constants.toolsList,
            vertical: [
                {
                    accountIds: [
                        localStorage.accountId
                    ],
                    verticalId: localStorage.verticalId
                }
            ]
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_ROBOT_KPI_ACCOUNT_ID, this.reqData);
    }

    prepareRobot(element) {
        const _robot: Robot = new Robot();
        _robot.robotId = element.robotId;
        _robot.name = element.robotName;
        _robot.hostName = element.hostName;
        _robot.status = element.robotStatus;
        _robot.location = element.locationId;
        _robot.type = (element.type === 'AA') ? 'Automation Anywhere' : (element.type === 'BP') ? 'Blue Prism' : 'UI';
        _robot.expiryDate = (element.licenseExpiryDate === null) ? 'Not Available' : 'Not Available';
        // _robot.expiryDate = (element.licenseExpiryDate === null) ? new Date() : new Date(element.licenseExpiryDate);
        _robot.controller = element.controllerId;
        _robot.process.id = element.jobDetail.businessProcessId;
        _robot.process.status = element.jobDetail.jobStatus;
        _robot.process.name = element.jobDetail.businessProcessName;
        return _robot;
    }

    prepareRobotList(list) {
        const robotList = new Array<Robot>();
        list.forEach((element, index) => {
            const _robot: Robot = new Robot();
            _robot.id = index;
            _robot.robotId = element.robotId;
            _robot.name = element.robotName;
            _robot.hostName = element.hostName;
            _robot.status = element.robotStatus;
            _robot.type = element.type;
            _robot.location = element.location;
            _robot.accountName = element.accountName;
            _robot.vertical = element.vertical;
            _robot.controller = element.controller;
            _robot.utilization = (element.durationInSeconds / 86400) * 100;
            robotList.push(_robot);
        });
        return robotList;
    }

    getDayWiseRobotUtilization() {
        this.reqData = {
            controllerIds: [
                '7f79807c-e3df-11e7-8d09-0023ae9f8800'
            ],
            endDate: this._utilityService.getLastDayMonth(),
            region: '',
            robotIds: [
                this.selectedRobot.id
            ],
            startDate: this._utilityService.getFirstDayMonth(),
            tool: Constants.toolsList,
            vertical: [
                {
                    accountIds: [
                        localStorage.accountId
                    ],
                    verticalId: localStorage.verticalId
                }
            ]
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_DAYWISE_ROBOT_UTILIZATION, this.reqData);
    }

    getRobotUtilization() {
        this.reqData = {
            dateRange: {
                endDate: this._utilityService.getPreviousDayMonth(),
                startDate: this._utilityService.getPreviousDayMonth()
            },
            tool: Constants.toolsList,
            vertical: [
                {
                    accountIds: [
                        localStorage.accountId
                    ],
                    verticalId: localStorage.verticalId
                }
            ]
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_ROBOT_UTILIZATION, this.reqData);
    }


    getAlertCount() {
        this.reqData = {
            category: [
                'string'
            ],
            controllerId: [
                'string'
            ],
            dateRange: this._utilityService.getCalendarDates(),

            exceptionType: [
                'string'
            ],
            inputType: [
                'string'
            ],
            locationId: [
                'string'
            ],
            logType: [
                'string'
            ],
            robotId: [
                'string'
            ],
            subCategory: [
                'string'
            ],
            tool: Constants.toolsList,
            vertical: [
                {
                    accountIds: [
                        localStorage.accountId
                    ],
                    verticalId: localStorage.verticalId
                }
            ]
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_ALERTCOUNT, this.reqData);
    }
}

import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Chart, MapChart } from 'angular-highcharts';
import { RobotService } from '../robot.service';
import { ISubscription } from 'rxjs/Subscription';
import { Robot } from '../../../../class/operationalClasses/robot';
import { UtilityService } from '../../../../utility/utility.services';
import { SharedService } from '../../../../../services/shared.service';

declare var require: any;
const Highcharts = require('highcharts');
require('highcharts/highcharts-more.js')(Highcharts);
export { Highcharts };

@Component({
    selector: 'app-workforcerobot',
    templateUrl: './robotdeatails.component.html',
    styleUrls: ['./robotdeatails.component.scss']
})

export class RobotdeatailsComponent implements OnInit, OnDestroy {

    robot: Robot;
    showalertareachart: boolean;
    showutilizationareachart: boolean;
    selectedRobot: any;

    selected = 'Utilization Over Time';
    selectedtimetype = '0';
    timetypes = [
        { value: '0', viewValue: 'Utilization Over Time' },
        { value: '1', viewValue: 'Alert Over Time' }
    ];

    todayTimeStamp: any;
    oneDayTimeStamp: any;
    diff: any;
    columndata: any[] = [];
    utilizationCategories: number[];
    utilizationData: any;
    dateNUntilizationList: any[] = [];
    columnChart: any;
    subscription_1: ISubscription;

    constructor(private _utilityService: UtilityService, private _router: Router, private _robotService: RobotService, private _sharedService: SharedService) {
        this.subscription_1 = this._robotService.emitRobotSelectionChange.subscribe(response => {
            setTimeout(() => {
                if (response) {
                    this.getRobotData();
                }
            }, 0);
        });
    }

    solidgauge = new Chart({
        chart: {
            type: 'solidgauge',
            height: 150,
            width: 170,
        },
        exporting: { enabled: false },
        title: {
            text: '',
            style: {
                display: 'none'
            }
        },
        tooltip: {
            borderWidth: 0,
            backgroundColor: 'none',
            shadow: false,
            style: {
                fontSize: '16px'
            },
            pointFormat: '{series.name}<br><span style="font-size:12px; color: {point.color}; font-weight: bold">{point.y}%</span>',
            positioner: function (labelWidth) {
                return {
                    x: (this.chart.chartWidth - labelWidth) / 2,
                    y: (this.chart.plotHeight / 2) - 14
                };
            }
        },
        pane: {
            startAngle: 0,
            endAngle: 360,
            background: [{
                outerRadius: '110%',
                innerRadius: '95%',
                backgroundColor: Highcharts.Color('#a1c6de')
                    .setOpacity(0.3)
                    .get(),
                borderWidth: 0
            }, {
                outerRadius: '85%',
                innerRadius: '70%',
                backgroundColor: Highcharts.Color('#a1c6de')
                    .setOpacity(0.3)
                    .get(),
                borderWidth: 0
            }, {
                outerRadius: '60%',
                innerRadius: '45%',
                backgroundColor: Highcharts.Color('#a1c6de')
                    .setOpacity(0.3)
                    .get(),
                borderWidth: 0
            }]
        },
        yAxis: {
            min: 0,
            max: 100,
            lineWidth: 0,
            tickPositions: []
        },
        plotOptions: {
            solidgauge: {
                dataLabels: {
                    enabled: false
                },
                linecap: 'round',
                stickyTracking: false
            }
        },
        series: [{
            name: 'CPU',
            data: [{
                color: '#227eba',
                radius: '110%',
                innerRadius: '95%',
                y: 80
            }]
        }, {
            name: 'RAM',
            data: [{
                color: '#31b1ea',
                radius: '85%',
                innerRadius: '70%',
                y: 77
            }]
        }, {
            name: 'HDD',
            data: [{
                color: '#a1c6de',
                radius: '60%',
                innerRadius: '45%',
                y: 20
            }]
        }]
    });
    /*end activity gauge implementation*/

    /*start utilization areachart*/
    utilizationareachart = new Chart({
        chart: {
            type: 'area',
            height: 100
        },
        title: {
            text: ''
        },
        subtitle: {
            text: '',
            floating: true,
            align: 'right',
            verticalAlign: 'bottom',
            y: 15
        },
        legend: {
            layout: 'vertical',
            align: 'left',
            verticalAlign: 'top',
            x: 150,
            y: 100,
            floating: true,
            borderWidth: 1,
        },
        xAxis: {
            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            minorTickLength: 0,
            tickLength: 0,
            labels: {
                style: {
                    color: '#9ea6a9',

                }
            }
        },
        yAxis: {
            title: {
                text: ''
            },
            min: 0,
            max: 100,
            labels: {
                formatter: function () {
                    return this.value + '%';
                },
                style: {
                    color: '#9ea6a9',
                }
            },
        },
        exporting: { enabled: false },
        tooltip: {
            formatter: function () {
                return this.x + ': ' + this.y + '%';
            },

        },
        plotOptions: {
            area: {
                pointStart: 0,
                lineWidth: 2,
                lineColor: '#05A1E7',
                fillColor: {
                    linearGradient: {
                        x1: 0,
                        y1: 0,
                        x2: 0,
                        y2: 1
                    },
                    stops: [
                        [0, '#00a0e7'],
                        [1, 'rgba(71, 167, 245, 0)']
                    ]
                }
            },
            series: {
                marker: {
                    enabled: false,
                },
                showInLegend: false
            }
        },
        credits: {
            enabled: false
        },
        series: [{
            data: [45, 67, 45, 87, 68, 42, 63, 47, 95, 65, 35, 65]
        }]

    });
    /*end utilization areachart*/

    /*start alert chart implementation*/
    alertareachart = new Chart({
        chart: {
            type: 'column',
            height: 100,
        },
        title: {
            text: ''
        },
        xAxis: {
            minorTickLength: 0,
            tickLength: 0,
            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            labels: {
                style: {
                    color: '#9ea6a9',
                }
            },
        },
        yAxis: {
            min: 0,
            max: 100,
            // tickInterval: 50,
            title: {
                text: ''
            },
            labels: {
                formatter: function () {
                    return this.value;
                },
                style: {
                    color: '#9ea6a9',
                }
            },
            gridLineDashStyle: 'ShortDash'
        },
        tooltip: {
            formatter: function () {
                return this.x + ': ' + this.y;
            }
        },
        plotOptions: {
            series: {
                marker: {
                    symbol: 'c-rect',
                    lineWidth: 2,
                    lineColor: Highcharts.getOptions().colors[1],
                    radius: 10
                },
                showInLegend: false,

            }
        },
        series: [
            {
                pointWidth: 15,
                data: [20, 67, 45, 87, 68, 42, 63, 47, 95, 65, 35, 65],
                color: {
                    linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
                    stops: [
                        [0, '#70cdff'],
                        [1, '#2c90f7']
                    ]
                },
            }
        ]
    });
    /*start alert chart implementation*/

    getProcessId() {
        if (this.robot !== undefined) {
            return this.robot.process.id;
        }
    }

    getLastUpdate() {
        if (this.robot !== undefined) {
            return this.robot.process.name + ' ' + this.robot.process.status + ' for';
        }
    }

    ngOnDestroy(): void {
        this.subscription_1.unsubscribe();
    }

    getDate(date) {
        return parseInt(date.split('/')[0]);
    }

    getDateNUtilizationList(response, dayCount) {
        const dataList: any[] = [];
        response.dayWiseRobotUtilizationInfos.forEach(element => {
            const obj = {
                date: this.getDate(element.utilizationInfoProcessDate),
                utilization: (element.robotWiseUtilizationInfos.durationInSeconds / (60 * 60 * 24)) * 100
            };
            dataList.push(obj);
        });
        return dataList;
    }


    getColor(response, date) {
        let returnValue: string = '#f04d3b';
        let isGoing: boolean = true;
        response.dayWiseRobotUtilizationInfos.forEach(element => {
            if (isGoing) {
                if (parseInt(element.utilizationInfoProcessDate.split('/')[0]) === date) {
                    const utilization = (element.robotWiseUtilizationInfos[0].durationInSeconds / (60 * 60 * 24)) * 100;
                    if (utilization < 20) {
                        returnValue = '#f04d3b';
                    } else if (utilization >= 20 && utilization < 40) {
                        returnValue = '#ff9ca3';
                    } else if (utilization >= 40 && utilization < 60) {
                        returnValue = '#ffcf83';
                    } else if (utilization >= 60 && utilization < 80) {
                        returnValue = '#bfea91';
                    } else {
                        returnValue = '#5cd78d';
                    }
                    isGoing = false;
                } else {
                    returnValue = '#f04d3b';
                }
            }
        });
        return returnValue;
    }

    createUtilizationChart(response) {
        this.columndata = [];
        this.todayTimeStamp = +new Date;
        this.oneDayTimeStamp = 1000 * 60 * 60 * 24;
        this.diff = this.todayTimeStamp - this.oneDayTimeStamp;
        const yesterdayDate: any = new Date(this.diff);
        const yesterday = parseInt(yesterdayDate.getDate());
        const daysCount = this._utilityService.getDaysCountInMonth(this._utilityService.getCurrentMonth() + 1, this._utilityService.getCurrentYear());
        this.dateNUntilizationList = this.getDateNUtilizationList(response, daysCount);
        for (let i = 1; i <= yesterday; i++) {
            this.columndata.push({ y: 50, color: this.getColor(response, i) });
        }
        for (let j = yesterday + 1; j <= daysCount; j++) {
            this.columndata.push({ y: 50, color: 'rgb(158, 166, 169)' });
        }
        this.columnChart = new Chart({
            chart: {
                type: 'column',
                height: 97
            },
            title: {
                text: ''
            },
            xAxis: {
                minorTickLength: 0,
                tickLength: 0,
                categories: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 35, 26, 27, 28, 29, 30, 31],
                labels: {
                    style: {
                        color: '#9ea6a9',
                    },
                },
            },
            tooltip: {
                enabled: false
            },
            yAxis: {
                title: {
                    text: ''
                },
                min: 0,
                max: 100,
                labels: {
                    enabled: false,
                    formatter: function () {
                        return this.value + '%';
                    },
                    style: {
                        color: '#9ea6a9',
                    }
                }
            },
            plotOptions: {
                series: {
                    marker: {
                        symbol: 'c-rect',
                        lineWidth: 2,
                        radius: 10
                    },
                    showInLegend: false
                }
            },
            series: [
                {
                    pointWidth: 13.3,
                    data: this.columndata
                }
            ]
        });
    }

    onChange(event) {
        if (event === '0') {
            this.showutilizationareachart = true;
            this.showalertareachart = false;
        } else {
            this.showalertareachart = true;
            this.showutilizationareachart = false;
        }
    }

    getDayWiseutilization(response) {
        const daysList: number[] = this._utilityService.getDaysInMonth(this._utilityService.getCurrentMonth(), this._utilityService.getCurrentYear());

    }

    /*Alert Over Time */
    getAlertOverTime() {
        this._robotService.getAlertCount().subscribe(response => {
        });
    }

    getRobotData() {
        this._sharedService.emitOperationalSpinnerChange(true);
        this.selectedRobot = this._robotService.selectedRobot;
        this.showutilizationareachart = true;
        this.showalertareachart = false;
        this._robotService.emitIsRobotView(2);
        this._robotService.getRobotDetailById().subscribe(response => {
            response = {
                'controllerId': '0ae48399-00da-11e8-885a-d067e5019012',
                'controllerName': 'EDT-233',
                'id': 'AWGeStskV1aWNT54V78X',
                'hostName': 'EDT-138.estblr.com',
                'robotId': '479388B1-940C-46CB-8C46-EA9776284671',
                'robotName': 'EDT-138',
                'robotStatus': 'Disconnected',
                'type': 'BP',
                'licenseExpiryDate': null,
                'locationId': 'Hyderabad, India',
                'kpis': {
                    'mttf': null,
                    'mtbr': null,
                    'uptime': null
                },
                'jobDetail': {
                    'botId': '9F5BACA5-3E07-43CB-A100-A1752F643E4D',
                    'robotId': '479388B1-940C-46CB-8C46-EA9776284671',
                    'jobStatus': 'Successful',
                    'jobStartTime': '2018-02-01T13:55:06.993Z',
                    'jobEndTime': '2018-02-01T13:55:07.197Z',
                    'botName': 'Collection Example',
                    'robotName': 'EDT-138',
                    'controllerId': '0ae48399-00da-11e8-885a-d067e5019012',
                    'verticalId': '9094344d-003b-11e8-885a-d067e5019012',
                    'accountId': 'fdc4ab6e-003c-11e8-885a-d067e5019012',
                    'tool': 'BP',
                    'id': 'AWGeUFpqV1aWNT54V8F_',
                    'critical': false,
                    'errorMsg': null,
                    'jobId': '7FFD50A0-01E4-49E4-A6AA-02537DD7E6D4',
                    'businessProcessId': '50862a54-00f8-11e8-885a-d067e5019012',
                    'businessProcessName': 'Churney Net Revenue',
                    'locationId': 'c8be0305-00d4-11e8-885a-d067e5019012',
                    'taskCompleted': 'true',
                    'businessProcessGroupId': '87d06334-00c5-11e8-885a-d067e5019012',
                    'businessProcessGroupName': 'P2P'
                }
            };
            this.robot = this._robotService.prepareRobot(response);
            this._sharedService.emitOperationalSpinnerChange(false);
        });
        this._robotService.getDayWiseRobotUtilization().subscribe(response => {
            this.createUtilizationChart(response);
        });
    }

    ngOnInit() {
        if (this._robotService.selectedRobot !== undefined) {
            this.getRobotData();
        } else {
            this._router.navigateByUrl('root/dashboard/view/workforce');
        }
        this.getAlertOverTime();
        this._utilityService.getCalendarDates();

    }

}

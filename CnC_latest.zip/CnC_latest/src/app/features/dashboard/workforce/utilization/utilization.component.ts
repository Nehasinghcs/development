import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RobotService } from '../robot.service';
import { UtilityService } from '../../../../utility/utility.services';
import { Robot } from '../../../../class/operationalClasses/robot';
import { SharedService } from '../../../../../services/shared.service';

@Component({
  selector: 'app-digitalworkforce',
  templateUrl: './utilization.component.html',
  styleUrls: ['./utilization.component.scss']
})
export class UtilizationComponent implements OnInit {

  mtbrInHrs: string = '0';
  mtbfInHrs: string = '0';
  upTimeInHrs: string = '0';
  downTimeInHrs: string = '0';
  robotList: Robot[];
  numberList: any[] = [
    { id: '0', showToolTip: false },
    { id: '1', showToolTip: false },
    { id: '2', showToolTip: false },
    { id: '3', showToolTip: false },
    { id: '4', showToolTip: false },
    { id: '5', showToolTip: false },
    { id: '6', showToolTip: false },
    { id: '7', showToolTip: false },
    { id: '8', showToolTip: false },
    { id: '9', showToolTip: false }
  ];
  verticalDivlist: any = new Array<any>(); // no of columns

  constructor(private _utilityService: UtilityService, private _robotService: RobotService, private _router: Router, private _sharedService: SharedService) {
  }

  goToRobotDetails(i: number, j: number) {
    let ii;
    if (i) {
      ii = i.toString();
    } else {
      ii = i;
    }
    const _robot: Robot = this.robotList[ii + j];

    this._robotService.selectedRobot = {
      id: _robot.robotId,
      name: _robot.name,
      status: _robot.status,
      from: 'utilization',
      accountName: _robot.accountName,
      hostName: _robot.hostName,
    };
    this._robotService.emitSelectedRobot(this._robotService.selectedRobot);
    this._router.navigateByUrl('root/dashboard/view/workforce/robot');
  }

  getRobotDetails(i: number, j: number, type: string) {
    let ii;
    if (i) {
      ii = i.toString();
    } else {
      ii = i;
    }
    let returnValue;
    const _robot: Robot = this.robotList[ii + j];
    if (_robot !== undefined) {
      switch (type) {
        case 'name':
          returnValue = _robot.hostName;
          break;
        case 'utilization':
          returnValue = _robot.utilization;
          break;
        case 'accountName':
          returnValue = _robot.accountName;
          break;
        case 'type':
          returnValue = _robot.type;
          break;
      }
      return returnValue;
    }
  }

  getColorCode(i: number, j: number) {
    let ii;
    if (i) {
      ii = i.toString();
    } else {
      ii = i;
    }
    let returnValue;
    const listItemIndex = ii + j;
    const _robot: Robot = this.robotList[listItemIndex];
    if (_robot !== undefined) {
      if (_robot.utilization <= 20) {
        returnValue = 'utilization-20';
      } else if (_robot.utilization > 20 && _robot.utilization <= 40) {
        returnValue = 'utilization-40';
      } else if (_robot.utilization > 40 && _robot.utilization <= 60) {
        returnValue = 'utilization-60';
      } else if (_robot.utilization > 60 && _robot.utilization <= 80) {
        returnValue = 'utilization-80';
      } else {
        returnValue = 'utilization-100';
      }
      return returnValue;
    }
  }

  showTooltip(div, item) {
    div.showToolTip = true;
    item.showToolTip = true;
  }

  hideTooltip(div, item) {
    div.showToolTip = false;
    item.showToolTip = false;
  }

  isElementExists(_index, _number) {
    let returnValue = false;
    let index;
    if (!_index) {
      index = _number;
    } else {
      index = _index + _number;
    }
    index = Number(index);
    if (this.robotList !== undefined && this.robotList.length) {
      const ary = this.robotList.filter(element => element.id === index);
      if (ary !== undefined && ary.length) {
        returnValue = true;
      }
    }
    return returnValue;
  }

  changeViewSize() {
    this._sharedService.emitViewSizeChange(!this._sharedService.showFullScreen);
  }

  getRobotTimeDetails() {
    this._robotService.getRobotUpDowntime().subscribe(response => {
      if (response.robotUptimeList !== null) {
        this.upTimeInHrs = this._utilityService.millSecondsToTimeString(response.robotUptimeList[0].upTimeInMilliSec);
        this.downTimeInHrs = this._utilityService.millSecondsToTimeString(response.robotUptimeList[0].downTimeInMilliSec);
      }
    }, (error) => {
    });
  }

  getKpiDetails() {
    this._robotService.getRobotKPIDetails().subscribe(response => {
      if (!response.kpiList) {
        this.mtbfInHrs = this._utilityService.millSecondsToTimeString(response.kpiList[0].mtbfInMillisec);
        this.mtbrInHrs = this._utilityService.millSecondsToTimeString(response.kpiList[0].mttrInMillisec);
      } else {
        this.mtbfInHrs = '0';
        this.mtbrInHrs = '0';
      }

    }, (error) => {
    });
  }

  ngOnInit() {
    this._sharedService.emitOperationalSpinnerChange(true);
    this._robotService.emitIsRobotView(1);
    this._robotService.getRobotUtilization().subscribe(response => {
      this.robotList = this._robotService.prepareRobotList(response.robotKpis);
      const lineDivCount: number = Math.ceil(this.robotList.length / 10);
      for (let index = 0; index < lineDivCount; index++) {
        const obj = {
          id: index,
          showToolTip: false
        };
        this.verticalDivlist.push(obj);
      }
      this._sharedService.emitOperationalSpinnerChange(false);
    }, (error) => {
      this._sharedService.emitOperationalSpinnerChange(false);
      this._utilityService.handleException(error);
    });
    this.getRobotTimeDetails();
    this.getKpiDetails();
  }

}

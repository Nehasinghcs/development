import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { RobotService } from './robot.service';
import { ISubscription } from 'rxjs/Subscription';
import { SharedService } from '../../../../services/shared.service';

@Component({
    selector: 'app-workforce',
    templateUrl: './workforce.component.html',
    styleUrls: ['./robotdeatails/robotdeatails.component.scss']
})

export class WorkForceComponent implements OnInit, OnDestroy {

    subscription_1: ISubscription;
    subscription_2: ISubscription;
    robotView = 0;
    selectedRobot: any;

    constructor(private _robotService: RobotService, private _router: Router, private _sharedService: SharedService) {
        this.subscription_1 = this._robotService.changeRobotViewEmitted.subscribe(response => {
            setTimeout(() => this.robotView = response, 0);
        });
        this.subscription_2 = this._robotService.changeRobotEmitted.subscribe(response => {
            setTimeout(() => this.selectedRobot = response, 0);
        });
    }

    ngOnDestroy(): void {
        this.subscription_1.unsubscribe();
        this.subscription_2.unsubscribe();
    }

    switchToMainView() {
        if (this.selectedRobot !== undefined) {
            if (this.selectedRobot.from === null || this.selectedRobot.from.toLowerCase() === 'health') {
                this._robotService.selectedRobot = undefined;
                this.goToRobotHealth();
            } else {
                this.goToRobotUtilization();
                this._robotService.selectedRobot = undefined;
            }
        }
    }

    goToRobotUtilization() {
        this._router.navigateByUrl('root/dashboard/view/workforce/utilization');
    }

    goToRobotHealth() {
        this._router.navigateByUrl('root/dashboard/view/workforce/health');
    }
    changeViewSize() {
        this._sharedService.emitViewSizeChange(!this._sharedService.showFullScreen);
    }

    getFullScreenParameter() {
        return this._sharedService.showFullScreen;
    }

    ngOnInit(): void {
        this._sharedService.emitWidgetChange(this._sharedService.currentView, 1);
        this._sharedService.emitViewChange(1);
        if (this._robotService.selectedRobot !== undefined && this.selectedRobot === undefined) {
            this.selectedRobot = this._robotService.selectedRobot;
        }
    }

}

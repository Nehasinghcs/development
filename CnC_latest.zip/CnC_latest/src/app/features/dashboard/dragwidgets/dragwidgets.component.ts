import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dragwidgets',
  templateUrl: './dragwidgets.component.html',
  styleUrls: ['./dragwidgets.component.scss']
})
export class DragwidgetsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { Chart, MapChart, Highcharts } from 'angular-highcharts';
import { Router } from '@angular/router';

@Component({
  selector: 'app-slabreachestab',
  templateUrl: './slabreachestab.component.html',
  styleUrls: ['../../summary.component.scss'],

})
export class SlabreachestabComponent implements OnInit {
  breachChart: any;
  constructor(private _router: Router) {
  }

  goToTicketsMetrics() {
    this._router.navigateByUrl('root/dashboard/summary/slabreaches');
  }

  ngOnInit() {
    this.breachChart = new Chart({
      chart: {
        type: 'gauge',
        plotBackgroundColor: null,
        plotBackgroundImage: null,
        plotBorderWidth: 0,
        plotShadow: false,
        height: '83px',
      },
      title: {
        text: '',
      },
      pane: {
        center: ['50%', '95%'],
        size: '220%',
        startAngle: -90,
        endAngle: 90,
        background: [{
          shape: 'arc',
          backgroundColor: '#DDD',
          borderWidth: 1,
          outerRadius: '50%',
        }]
      },
      plotOptions: {
        gauge: {
          pivot: {
            radius: 0,
            borderWidth: 0,
          },
          dataLabels: {
            enabled: true,
            borderWidth: 0,
            y: 4,
            x: -3,
            style: {
              fontFamily: 'OpenSans-Semibold',
              fontSize: '20px',
              fontWeight: '600',
              color: '#394961'
            },
            zIndex: 5,
          },
          dial: {
            backgroundColor: '#838282',
            baseLength: '0%',
            radius: '100%',
            rearLength: '0%',
            topWidth: 1,
          },
        }
      },
      yAxis: {
        labels: {
          enabled: false,
        },
        title: {
          text: 'Breaches',
          y: 45,
          style: {
            fontFamily: 'OpenSans',
            fontSize: '12px',
            color: '#626579'
          }
        },
        tickInterval: 100,
        tickWidth: 0,
        minorTickLength: 0,
        min: 0,
        max: 100,

        plotBands: [{
          from: 0,
          to: 6,
          color: '#F04D3B',
          thickness: '17%'
        }, {
          from: 6,
          to: 100,
          color: '#DADEDF',
          thickness: '17%'
        }]
      },
      tooltip: {
        enabled: false
      },
      series: [{
        name: 'Speed',
        data: [6],
      }],
    });
  }
}

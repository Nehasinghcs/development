import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TicketService } from '../../../tickets/tickets.service';
import { Tickets } from '../../../../../class/operationalClasses/tickets';
import { SharedService } from '../../../../../../services/shared.service';

@Component({
  selector: 'app-summarytab',
  templateUrl: './summarytab.component.html',
  styleUrls: ['../../summary.component.scss']
})
export class SummarytabComponent implements OnInit {
  unAssignedTickets: number;
  onHoldTickets: number;
  inProgressTickets: number;
  tickets: Tickets[];

  constructor(private _ticketService: TicketService, private _router: Router, private _sharedService: SharedService) {
    // this._sharedService.criticalTicketEmitted.subscribe(response => {
    //   this.unAssignedTickets = response.filter(element => element.status === '0').length;
    //   this.onHoldTickets = response.filter(element => element.status === '1').length;
    //   this.inProgressTickets = response.filter(element => element.status === '2').length;
    // });
  }

  goToTicketsSummary() {
    this._router.navigateByUrl('root/dashboard/summary/ticketsummary');
  }

  ngOnInit() {
    this._ticketService.getDataFromJSON().subscribe(response => {
      this.tickets = this._ticketService.prepareTickets(response.ticketDetails);
      this.unAssignedTickets = this.tickets.filter(element => element.status === '0').length;
      this.onHoldTickets = this.tickets.filter(element => element.status === '1').length;
      this.inProgressTickets = this.tickets.filter(element => element.status === '2').length;
      this._sharedService.emitCriticalTicket(this.tickets);
    });
  }

}

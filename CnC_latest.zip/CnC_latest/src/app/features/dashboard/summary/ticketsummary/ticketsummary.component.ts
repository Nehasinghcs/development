import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TicketService } from '../../tickets/tickets.service';
import { Tickets } from '../../../../class/operationalClasses/tickets';
import { WidgetService } from '../../../../../services/widget.service';
import { UtilityService } from '../../../../utility/utility.services';
import { SharedService } from '../../../../../services/shared.service';

@Component({
  selector: 'app-ticketsummary',
  templateUrl: './ticketsummary.component.html',
  styleUrls: ['./ticketsummary.component.scss']
})
export class TicketsummaryComponent implements OnInit {
  tickets: Tickets[];
  onhold: boolean;
  unassigned: boolean;
  inprogress: boolean;
  selectedTab: string;

  constructor(private _widgetService: WidgetService, private _utilityService: UtilityService, private _sharedService: SharedService, private _ticketService: TicketService, private _router: Router) { }

  getDaysDifference(ticket: Tickets) {
    if (ticket !== undefined) {
      return this._utilityService.getDaysDifference(ticket.createdOn, new Date()) + ' days';
    }
  }

  getTicketCount(status) {
    if (this.tickets !== undefined) {
      return this.tickets.filter(element => element.status === status).length;
    }
  }

  goToView() {
    this._router.navigateByUrl(this._widgetService.activeGlances[0].routeUrl);
  }

  inprogressbtn() {
    this.inprogress = true;
    this.onhold = false;
    this.unassigned = false;
    this.selectedTab = '2';
  }

  unassignedbtn() {
    this.unassigned = true;
    this.onhold = false;
    this.inprogress = false;
    this.selectedTab = '0';
  }

  onholdbtn() {
    this.onhold = true;
    this.inprogress = false;
    this.unassigned = false;
    this.selectedTab = '1';
  }

  ngOnInit() {
    if (this._sharedService.tickets !== undefined) {
      this.tickets = this._sharedService.tickets;
    } else {
      this._ticketService.getDataFromJSON().subscribe(response => {
        this.tickets = this._ticketService.prepareTickets(response.ticketDetails);
        this._sharedService.emitCriticalTicket(this.tickets);
      }, (error) => {
        this._utilityService.handleException(error);
      });
    }
    this.inprogressbtn();
  }

}

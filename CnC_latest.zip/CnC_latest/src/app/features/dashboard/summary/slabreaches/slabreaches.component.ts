import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Chart, MapChart, Highcharts } from 'angular-highcharts';
import { WidgetService } from '../../../../../services/widget.service';
import { SharedService } from '../../../../../services/shared.service';
import { AreaSplineChartComponent } from '../../../../shared/cnc-charts/areasplinechart/areasplinechart.component';

@Component({
  selector: 'app-slabreaches',
  templateUrl: './slabreaches.component.html',
  styleUrls: ['./slabreaches.component.scss'],
  providers: [AreaSplineChartComponent]
})
export class SlabreachesComponent implements OnInit {
  slabreachJson: any[] = [
    {
      id: 1,
      name: 'Average Handling Time',
      processaffected: 'O2C',
      time: '12/20/2017 5:40PM',
      plotData: [{
        data: [3, 4, 3, 5, 4, 10, 12],
        legendname: 'Abandoned',
        color: {
          linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
          stops: [
            [0, '#f04d3b'],
            [1, 'rgba(240, 77, 59, 0)']
          ]
        }
      }]
    },
    {
      id: 2,
      name: 'Average Time To Resolve Tickets',
      processaffected: 'S2P',
      time: '12/21/2017 4:40PM',
      plotData: [{
        data: [1, 3, 4, 3, 3, 5, 4],
        legendname: 'Abandoned',
        color: {
          linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
          stops: [
            [0, '#f04d3b'],
            [1, 'rgba(240, 77, 59, 0)']
          ]
        }
      }]
    },
    {
      id: 3,
      name: 'Uptime Of Robots',
      processaffected: 'O2C',
      time: '12/22/2017 7:40PM',
      plotData: [{
        data: [4, 6, 2, 7, 4, 10, 12],
        legendname: 'Abandoned',
        color: {
          linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
          stops: [
            [0, '#f04d3b'],
            [1, 'rgba(240, 77, 59, 0)']
          ]
        }
      }]
    },
    {
      id: 4,
      name: 'Errors Per 100 Transactions',
      processaffected: 'S2P',
      time: '12/23/2017 6:40PM',
      plotData: [{
        data: [1, 13, 4, 23, 6, 25, 14],
        legendname: 'Abandoned',
        color: {
          linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
          stops: [
            [0, '#f04d3b'],
            [1, 'rgba(240, 77, 59, 0)']
          ]
        }
      }]
    },
    {
      id: 6,
      name: 'Throughput',
      processaffected: 'S2P',
      time: '12/25/2017 4:40PM',
      plotData: [{
        data: [1, 3, 4, 3, 3, 5, 4],
        legendname: 'Abandoned',
        color: {
          linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
          stops: [
            [0, '#f04d3b'],
            [1, 'rgba(240, 77, 59, 0)']
          ]
        }
      }]
    },
    {
      id: 6,
      name: 'Acknowledgement Time Per Ticket',
      processaffected: 'R2R',
      time: '12/27/2017 8:40PM',
      plotData: [{
        data: [12, 2, 14, 3, 23, 1, 23],
        legendname: 'Abandoned',
        color: {
          linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
          stops: [
            [0, '#f04d3b'],
            [1, 'rgba(240, 77, 59, 0)']
          ]
        }
      }]
    }
  ];


  switchOn = true;

  splineChartSettings = {
    xAxisVisible: false,
    yAxisvisible: false,
    height: 60,
    formatteryaxis: function () {
      return '';
    },
    formatterXaxis: function () {
      return this.value + 'AM';
    },
    linestyle: 'longdash',
    stepXaxis: 3
  };

  constructor(private _widgetService: WidgetService, private _sharedService: SharedService, private _router: Router) { }

  toggeleSwitch() {
    this.switchOn = !this.switchOn;
  }

  goToView() {
    this._router.navigateByUrl(this._widgetService.activeGlances[0].routeUrl);
  }

  ngOnInit() {
  }

}

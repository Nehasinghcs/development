import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Chart, MapChart, Highcharts } from 'angular-highcharts';
import { WidgetService } from '../../../../../services/widget.service';
import { SharedService } from '../../../../../services/shared.service';
import { AreaSplineChartComponent } from '../../../../shared/cnc-charts/areasplinechart/areasplinechart.component';

@Component({
  selector: 'app-processsnapshot',
  templateUrl: './processsnapshot.component.html',
  styleUrls: ['./processsnapshot.component.scss'],
  providers: [AreaSplineChartComponent]
})

export class ProcesssnapshotComponent implements OnInit {

  selectedTool = 1;
  plotData: any[];
  splineChartSettings: any;
  running = 1;
  completed = 2;
  failed = 3;
  processsnapshotJson: any[] = [{
    id: 1,
    BUname: 'Beauty Care',
    name: 'Order Management',
    crrRate: '23%',
    location: 'North America'

  }, {
    id: 2,
    BUname: 'Beauty Care',
    name: 'Order Managementt',
    crrRate: '27%',
    location: 'North America'
  }, {
    id: 3,
    BUname: 'Feminine Care',
    name: 'Invoicing',
    crrRate: '35%',
    location: 'North America'
  }, {
    id: 4,
    BUname: 'Feminine Care',
    name: 'Invoicing',
    crrRate: '17%',
    location: 'North America'
  }, {
    id: 5,
    BUname: 'Beauty Care',
    name: 'Dispute management',
    crrRate: '33%',
    location: 'North America'
  }, {
    id: 6,
    BUname: 'Beauty Care',
    name: 'Order Management',
    crrRate: '32%',
    location: 'North America'
  }];
  constructor(private _widgetService: WidgetService, private _sharedService: SharedService, private _router: Router) { }

  tools = [{
    id: 1,
    name: 'Real Time'
  }, {
    id: 2,
    name: 'Real Time 1'
  }];

  goToView() {
    this._router.navigateByUrl(this._widgetService.activeGlances[0].routeUrl);
  }
  getCurrentHour() {
    return new Date().getHours();
  }
  generateProcessData(type: number) {
    const runningData = [29, 29, 27, 23, 23, 23, 19, 19, 15, 15, 15, 10, 10, 10, 10, 10, 10, 23, 23, 25, 25, 25, 27, 23, 23, 23];
    const completedData = [0, 0, 2, 5, 5, 5, 7, 7, 10, 10, 10, 13, 13, 13, 13, 13, 13, 15, 15, 16, 16, 18, 18, 18, 18, 18];
    const failedData = [0, 0, 0, 1, 1, 1, 3, 3, 3, 3, 3, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6];
    const data = [];
    for (let i = 0; i <= this.getCurrentHour(); i++) {
      if (type === this.running) {
        data.push(runningData[i]);
      } else if (type === this.completed) {
        data.push(completedData[i]);
      } else {
        data.push(failedData[i]);
      }
    }
    return data;
  }


  ngOnInit() {
    this.plotData = [
      {
        'data': this.generateProcessData(this.running),
        'legendname': 'Running',
        'color': {
          linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
          stops: [
            [0, '#00a0e7'],
            [1, 'rgba(71, 167, 245, 0)']
          ]
        }
      },
      {
        'data': this.generateProcessData(this.failed),
        'legendname': 'Abandoned',
        'color': {
          linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
          stops: [
            [0, '#f04d3b'],
            [1, 'rgba(240, 77, 59, 0)']
          ]
        }
      }
    ];
    this.splineChartSettings = {
      xAxisVisible: true,
      yAxisvisible: true,
      height: 290,
      formatteryaxis: function () {
        return '';
      },
      formatterXaxis: function () {
        return this.value + 'AM';
      },
      linestyle: 'longdash',
      stepXaxis: 3
    };
  }

}

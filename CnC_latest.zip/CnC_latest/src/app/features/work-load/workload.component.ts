import { Component } from '@angular/core';

@Component({
    selector: 'app-work-load-component',
    template: 'Work load'
})

export class WorkLoadComponent { }

import { NgModule } from '@angular/core';
import { WorkLoadComponent } from './workload.component';
import { workloadrouting } from './workload.roting';

@NgModule({
    declarations: [
        WorkLoadComponent
    ],
    imports: [
        workloadrouting
    ]
})

export class WorkLoadModule {

}

import { Routes, RouterModule } from '@angular/router';
import { WorkLoadComponent } from './workload.component';

const workload_routes: Routes = [
    {
        path: '', component: WorkLoadComponent
    }
];

export const workloadrouting = RouterModule.forChild(workload_routes);

import { Injectable } from '@angular/core';
import { DataService } from '../../../../services/data.services';
import { AppSettings } from '../../../utility/app.settings';

@Injectable()

export class LoginService {
    constructor(private _dataService: DataService) { }

    reqData = {};
    login(reqData) {
        const request: string = 'grant_type=password&username=' + reqData.username + '&password=' + reqData.password + '&client_id=client&client_secret=secret';
        return this._dataService.login(AppSettings.LOGIN, request);
    }
}

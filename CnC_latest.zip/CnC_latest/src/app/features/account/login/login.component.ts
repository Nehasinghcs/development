import { Component, OnInit } from '@angular/core';
import { LoginService } from './login.service';
import { Router } from '@angular/router';
import { User } from '../../../class/user';
import { SharedService } from '../../../../services/shared.service';
import { UtilityService } from '../../../utility/utility.services';
declare var jquery: any;
declare var $: any;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: [User]
})
export class LoginComponent implements OnInit {
  user;
  constructor(private _sharedService: SharedService, private _utilityService: UtilityService, private _LoginService: LoginService, private router: Router, private _user: User) {
    this.user = _user;
  }

  onSubmit(formValues: any) {
    if (formValues.valid) {
      this._sharedService.emitSpinnerChange(true);
      this._LoginService.login({ username: formValues.value.username, password: formValues.value.password }).subscribe(response => {
        localStorage.username = formValues.value.username;
        localStorage.token_type = response.token_type;
        localStorage.access_token = response.access_token;
        localStorage.refresh_token = response.refresh_token;
        localStorage.verticalId = response.verticalId;
        localStorage.accountId = response.accountId;
        this.router.navigateByUrl('root/dashboard/view/workforce');
      }, (error) => {
        this._sharedService.emitSpinnerChange(false);
        this._utilityService.handleException(error);
      });
    }
  }

  ngOnInit() {
    this._sharedService.emitSpinnerChange(false);
    this._sharedService.emitOperationalSpinnerChange(false);
  }

}

import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';

const account_routes: Routes = [
    { path: '', component: LoginComponent }
];

export const account_routing = RouterModule.forChild(account_routes);

import { NgModule } from '@angular/core';
import { LoginComponent } from './login/login.component';
import { LoginService } from './login/login.service';
import { account_routing } from './account.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { BrowserModule } from '@angular/platform-browser';
import { MaterialModule } from '../../shared/material/material.module';
import { CommonModule } from '@angular/common';

@NgModule({
    declarations: [
        LoginComponent
    ],
    imports: [
        account_routing,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        CommonModule
        // BrowserModule
    ],
    providers: [
        LoginService
    ]
})
export class AccountModule { }

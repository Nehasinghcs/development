import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-createprocessgroup',
  templateUrl: './createprocessgroup.component.html',
  styleUrls: ['./createprocessgroup.component.scss']
})
export class CreateprocessgroupComponent implements OnInit {

  constructor( private router: Router) { }

  cancel() {
    this.router.navigateByUrl('root/settings/home');
  }

  ngOnInit() {
  }

}

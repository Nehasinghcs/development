import { Injectable } from '@angular/core';
import { DataService } from '../../../../services/data.services';
import { Roles } from '../../../class/roles';
import { AppSettings } from '../../../utility/app.settings';

@Injectable()

export class AdduserService {
    constructor(private _dataService: DataService) {
    }

    createUser(reqData) {
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.REGISTER_USER, reqData);
    }

    prepareRoles(list) {
        const rolesList: Roles[] = [];
        list.forEach(element => {
            const _roles: Roles = new Roles();
            _roles.id = element.id;
            _roles.name = element.name;
            rolesList.push(_roles);
        });
        return rolesList;
    }

    getRoles() {
        return this._dataService.getDataFromJSON('roles.json');
    }
}

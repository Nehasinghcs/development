import { Component, OnInit } from '@angular/core';
import { ControllerService } from '../controllers/controllers.service';
import { AdduserService } from './adduser.service';
import { RouterEvent } from '@angular/router/src/events';
import { Router } from '@angular/router';
import { User } from '../../../class/user';
import { Roles } from '../../../class/roles';
import { SharedService } from '../../../../services/shared.service';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.scss'],
  providers: [User]
})
export class AdduserComponent implements OnInit {

  rolesList: Roles[];
  user: User;

  constructor(private _sharedService: SharedService, private _adduserService: AdduserService, private _user: User, private router: Router) {
    this.user = _user;
  }

  cancel() {
    this.router.navigateByUrl('root/settings/home');
  }

  onSubmit(form) {
    if (form.valid) {
      this._sharedService.emitSpinnerChange(true);
      const reqData = {
        accountId: 0,
        createdBy: '',
        email: form.user.emailId,
        firstName: form.user.firstName,
        lastName: form.user.lastName,
        roleId: 0,
        updatedBy: '',
        userName: ''
      };
      this._adduserService.createUser(reqData).subscribe(response => {

      });
    }
  }

  getRoles() {
    this._adduserService.getRoles().subscribe(response => {
      this.rolesList = this._adduserService.prepareRoles(response);
    });
  }

  ngOnInit() {
    this.getRoles();
  }

}

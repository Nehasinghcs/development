import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AccountsService } from '../accounts/accounts.service';
import { ToasterService } from 'angular2-toaster/src/toaster.service';
import { Accounts } from '../../../class/account';
import { Verticals } from '../../../class/verticals';
import { SharedService } from '../../../../services/shared.service';
import { Constants } from '../../../utility/app.constants';

@Component({
  selector: 'app-createaccount',
  templateUrl: './createaccount.component.html',
  styleUrls: ['./createaccount.component.scss'],
  providers: [Accounts]
})

export class CreateaccountComponent implements OnInit {

  verticals: Verticals[];
  accounts;

  constructor(private _accounts: Accounts, private _toasterService: ToasterService,
    private _AccountsService: AccountsService, private router: Router, private _sharedService: SharedService) {
    this.accounts = _accounts;
  }

  onSubmit(form) {
    if (form.valid) {
      this._sharedService.emitSpinnerChange(true);
      const reqData = {
        accountId: null,
        accountName: form.value.accountName,
        createdBy: '',
        description: form.value.opsLocation,
        status: Constants.active,
        updatedBy: '',
        verticalId: form.value.verticalId
      };
      this._AccountsService.addAccount(reqData).subscribe(response => {
        this._toasterService.pop('success', '', 'Account added successfully');
        this.router.navigateByUrl('root/settings/accounts');
      }, (err) => {
        this._sharedService.emitSpinnerChange(false);
        if (err.status === 1014) {
          this._toasterService.pop('error', '', 'This Account already registered');
        } else {
          this._toasterService.pop('error', '', 'Server Error');
        }
      });
    }
  }

  cancel() {
    this.router.navigateByUrl('root/settings/home');
  }

  ngOnInit() {
    this._sharedService.emitSpinnerChange(true);
    this._AccountsService.getVerticals().subscribe(response => {
      this.verticals = this._AccountsService.prepareVerticals(response.verticalList);
      this._sharedService.emitSpinnerChange(false);
    }, (err) => {
      this._toasterService.pop('error', '', err);
      this._sharedService.emitSpinnerChange(false);
    });
  }

}




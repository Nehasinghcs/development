import { Routes, RouterModule } from '@angular/router';
import { AccountsComponent } from './accounts/accounts.component';
import { AddcontrollerComponent } from './addcontroller/addcontroller.component';
import { ProcessComponent } from './process/process.component';
import { CreateaccountComponent } from './createaccount/createaccount.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ControllersComponent } from './controllers/controllers.component';
import { AddprocessComponent } from './addprocess/addprocess.component';
import { SlaconfigComponent } from './slaconfig/slaconfig.component';
import { LicensecostComponent } from './licensecost/licensecost.component';
import { AdduserComponent } from './adduser/adduser.component';
import { CreateprocessgroupComponent } from './createprocessgroup/createprocessgroup.component';
import { SettingsComponent } from './settings.component';
import { HomescreenComponent } from './homescreen/homescreen.component';
import { AssignprocessgroupComponent } from './assignprocessgroup/assignprocessgroup.component';

const settings_routes: Routes = [
    {
        path: '', component: SettingsComponent,
        children: [{ path: '', redirectTo: '/root/settings/home', pathMatch: 'full' },
        { path: 'accounts', component: AccountsComponent, pathMatch: 'full' },
        { path: 'addaccount', component: CreateaccountComponent, pathMatch: 'full' },
        { path: 'addcontroller', component: AddcontrollerComponent, pathMatch: 'full' },
        { path: 'process', component: ProcessComponent, pathMatch: 'full' },
        { path: 'controllers', component: ControllersComponent, pathMatch: 'full' },
        { path: 'addprocess', component: AddprocessComponent, pathMatch: 'full' },
        { path: 'slaconfig', component: SlaconfigComponent, pathMatch: 'full' },
        { path: 'licensecost', component: LicensecostComponent, pathMatch: 'full' },
        { path: 'adduser', component: AdduserComponent, pathMatch: 'full' },
        { path: 'createprocessgroup', component: CreateprocessgroupComponent, pathMatch: 'full' },
        { path: 'home', component: HomescreenComponent, pathMatch: 'full' },
        { path: 'assignprocessgroup', component: AssignprocessgroupComponent, pathMatch: 'full' }]
    }
];

export const settingsrouting = RouterModule.forChild(settings_routes);

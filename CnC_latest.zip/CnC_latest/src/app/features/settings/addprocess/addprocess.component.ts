import { Component, OnInit } from '@angular/core';
import { ControllerService } from '../controllers/controllers.service';
import { Router } from '@angular/router';
import { SharedService } from '../../../../services/shared.service';

@Component({
  selector: 'app-addprocess',
  templateUrl: './addprocess.component.html'
})
export class AddprocessComponent implements OnInit {
  masterfiles: any[];

  constructor(private _controllerService: ControllerService, private _sharedService: SharedService, private router: Router) { }

  Controllers = [
    { value: '0', viewValue: 'CON-224' },
    { value: '1', viewValue: 'CON-225' },
    { value: '2', viewValue: 'CON-226' },
    { value: '2', viewValue: 'CON-227' }
  ];
  automations = [
    { value: '0', viewValue: 'automation0' },
    { value: '1', viewValue: 'automation1' },
    { value: '2', viewValue: 'automation2' },
    { value: '3', viewValue: 'automation3' },
    { value: '4', viewValue: 'automation4' }
  ];
  processgroups = [
    { value: '0', viewValue: 'S2P' },
    { value: '1', viewValue: 'P2R' },
    { value: '2', viewValue: 'O2C' },
    { value: '3', viewValue: 'R2R' },
  ];

  cancel() {
    this.router.navigateByUrl('root/settings/home');
  }

  ngOnInit() {
    this._sharedService.emitSpinnerChange(true);
    const reqData = {
      pageNumber: 0,
      pageSize: 10,
      tool: [
        'string'
      ],
      vertical: [
        {
          accountIds: [
            'string'
          ],
          verticalId: 'string'
        }
      ]
    };
    this._controllerService.getControllerList(reqData).subscribe(response => {
      this._sharedService.emitSpinnerChange(false);
    }, (err) => {
      this._sharedService.emitSpinnerChange(false);
    });
  }

}

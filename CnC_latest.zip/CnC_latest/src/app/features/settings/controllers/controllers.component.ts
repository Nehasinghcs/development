import { Component, OnInit } from '@angular/core';
import { ControllerService } from './controllers.service';
import { SharedService } from '../../../../services/shared.service';

@Component({
  selector: 'app-controllers',
  templateUrl: './controllers.component.html',
  styleUrls: ['./controllers.component.scss']
})
export class ControllersComponent implements OnInit {
  showicon: boolean;
  editable: boolean;

  constructor(private _controllerService: ControllerService, private _sharedService: SharedService) { }
  show = false;
  ngOnInit() {
    this.editable = false;
    this.showicon = true;
    this._sharedService.emitSpinnerChange(true);
    const reqData = {
      pageNumber: 0,
      pageSize: 10,
      tool: [
        'string'
      ],
      vertical: [
        {
          accountIds: [
            'string'
          ],
          verticalId: 'string'
        }
      ]
    };
    this._controllerService.getControllerList(reqData).subscribe(response => {
      this._sharedService.emitSpinnerChange(false);
    }, (err) => {
      this._sharedService.emitSpinnerChange(false);
    });
  }
  showActionItems(item) {
   this.editable = true;
   this.showicon = false;
      }
  //  removeActionItem(){
  //      this.showicon=true;
  //       this.editable=false;
  //     }


}

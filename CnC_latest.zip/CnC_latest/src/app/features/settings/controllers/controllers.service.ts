import { Injectable } from '@angular/core';
import { DataService } from '../../../../services/data.services';
import { AppSettings } from '../../../utility/app.settings';

@Injectable()

export class ControllerService {
    constructor(private _DataService: DataService) { }

    getControllerList(reqData) {
        return this._DataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_CONTROLLER_LIST, reqData);
    }

    addController(form, propertyList) {
        const ary = new Array<any>();
        propertyList.forEach(element => {
            const obj = {
                property: '',
                value: ''
            };
            obj.property = element.name;
            obj.value = element.code;
            ary.push(obj);
        });
        const reqData = {
            accountId: 'string',
            controllerId: form.value.controllerUserId,
            controllerName: form.value.controllerName,
            controllerUserEmail: form.value.controllerUserEmail,
            controllerUserName: form.value.controllerUserName,
            controllerUserPassword: form.value.controllerPassword,
            databaseDetail: {
                databaseName: form.value.dbName,
                databaseUserName: form.value.dbUserName,
                databaseUserPassword: form.value.dbPassword,
                instanceName: form.value.dbInstanceName,
                properties: ary,
                serverName: form.value.dbServerName
            },
            hostName: form.value.hostName,
            location: form.value.location,
            status: 'Active',
            tool: form.value.tools,
            toolVersion: form.value.version,
            url: form.value.url
        };
        return this._DataService.postData(AppSettings.API_ENDPOINT + AppSettings.ADD_CONTROLLER, reqData);
    }

    getTools() {
        // return this._DataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_TOOLS, undefined);
        return this._DataService.getTools();
    }
}

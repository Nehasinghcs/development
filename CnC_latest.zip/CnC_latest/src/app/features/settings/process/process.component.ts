import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-process',
  templateUrl: './process.component.html',
  styleUrls: ['./process.component.scss']
})
export class ProcessComponent implements OnInit {

  serialNo: any;
  process: string;
  tool: string;
  controllers: number;
  uautomation: number;
  robot: number;
  users: number;
  createdby: Date;
  createdon: Date;

  accountDetails = [
    {
      serialNo: '#1',
      process: 'Invoice Processing',
      tool: 'AA',
      controllers: '1',
      automation: '12',
      robot: '12',
      users: '12',
      createdby: '06/20/2017',
      createdon: '06/20/2017'
    },
    {
      serialNo: '#2',
      process: 'Payment Processing',
      tool: ' AA',
      controllers: '1',
      automation: '19',
      robot: '19',
      users: '19',
      createdby: '06/04/2017',
      createdon: '06/12/2017'
    },
    {
      serialNo: '#3',
      process: 'Clearing',
      tool: ' AA',
      controllers: '1',
      automation: '18',
      robot: '18',
      users: '18',
      createdby: '03/20/2017',
      createdon: '05/20/2017'
    }
  ];
  constructor() { }

  ngOnInit() {
  }

}

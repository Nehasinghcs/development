import { Injectable } from '@angular/core';
import { DataService } from '../../../../services/data.services';
import { Verticals } from '../../../class/verticals';
import { Accounts } from '../../../class/account';
import { AppSettings } from '../../../utility/app.settings';

@Injectable()

export class AccountsService {
    reqData: any = {};
    constructor(private _dataService: DataService) { }

    getVerticals() {
        this.reqData = {
            status: [
                'Active'
            ]
        };
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_VERTICAL_DETAIL, this.reqData);
    }

    registerUser(reqData) {
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.REGISTER_USER, reqData);
    }
    addAccount(reqData) {
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.ADD_ACCOUNT, reqData);
    }
    getAccounts() {
        return this._dataService.postData(AppSettings.API_ENDPOINT + AppSettings.GET_ACCOUNTS, undefined);
        // return this._DataService.getAccounts();
    }

    prepareVerticals(list) {
        const verticals = new Array<Verticals>();
        list.forEach(element => {
            const _vertical: Verticals = new Verticals();
            _vertical.id = element.id;
            _vertical.name = element.verticalName;
            verticals.push(_vertical);
        });
        return verticals;
    }
    prepareAccounts(list) {
        const accounts = new Array<Accounts>();
        list.forEach(element => {
            const _account: Accounts = new Accounts();
            _account.accountId = element.accountId;
            _account.accountName = element.accountName;
            _account.vertical = element.verticalName;
            _account.accountAdmin = element.accountAdmin;
            _account.email = element.email;
            _account.editable = false;
            accounts.push(_account);
        });
        accounts.sort(function (a, b) { return a.accountId - b.accountId; });
        return accounts;
    }
}

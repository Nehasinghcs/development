import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountsService } from './accounts.service';
import { ToasterService } from 'angular2-toaster/src/toaster.service';
import { Accounts } from '../../../class/account';
import { SharedService } from '../../../../services/shared.service';

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.scss']
})
export class AccountsComponent implements OnInit {

  constructor(private _toasterService: ToasterService, private router: Router,
    private _accountsService: AccountsService, private _sharedService: SharedService) { }

  accounts: Accounts[];

  cancel() {
    this.router.navigateByUrl('root/settings/home');
  }

  goToCreateAccount() {
    this.router.navigateByUrl('root/settings/addaccount');
  }

  addUserToAccount(account) {
    this.router.navigateByUrl('root/settings/adduser');
  }

  ngOnInit() {
    this._sharedService.emitSpinnerChange(true);
    this._accountsService.getAccounts().subscribe(response => {
      this.accounts = this._accountsService.prepareAccounts(response);
      this._sharedService.emitSpinnerChange(false);
    }, (err) => {
      this._toasterService.pop('error', '', err);
      this._sharedService.emitSpinnerChange(false);
    });
  }

  showActionItems(item) {
    for (let i = 0; i < this.accounts.length; i++) {
      if (item.accountName === this.accounts[i].accountName) {
        this.accounts[i].editable = true;
      } else {
        this.accounts[i].editable = false;
      }
    }
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slaconfig',
  templateUrl: './slaconfig.component.html',
  styleUrls: ['./slaconfig.component.scss']
})
export class SlaconfigComponent implements OnInit {

  constructor() { }
  email: string;
  mtbtf= false;
  downtime = false;
  uptime = false;
  throughput = false;
  resolve = false;
  handletime= false;
  error = false;

  durations = [
    { value: 'Daily', viewValue: 'Daily' },
    { value: 'Weekly', viewValue: 'Weekly' },
    { value: 'Monthly', viewValue: 'Monthly' },
    { value: 'Quaterly', viewValue: 'Quaterly' },
  ];

  processes = [
    { value: 'Procure to pay', viewValue: 'Procure to pay' },
    { value: 'Order to cash', viewValue: 'Order to cash' },
    { value: 'Record to report', viewValue: 'Record to report' },
  ];

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-assignprocessgroup',
  templateUrl: './assignprocessgroup.component.html',
  styleUrls: ['./assignprocessgroup.component.scss']
})
export class AssignprocessgroupComponent implements OnInit {
  processGroups = ['Procure To Pay', 'Record To Report', 'Order To Cash', 'Source To Pay'];
  selected = false;
  constructor(private router: Router) { }

  cancel() {
    this.router.navigateByUrl('root/settings/home');
  }
  toggle() {
    if (this.selected) {
      this.selected = false;
    } else {
      this.selected = true;
    }
  }
  ngOnInit() {
  }

}

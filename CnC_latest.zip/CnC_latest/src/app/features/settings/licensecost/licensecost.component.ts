import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-licensecost',
  templateUrl: './licensecost.component.html',
  styleUrls: ['./licensecost.component.scss']
})
export class LicensecostComponent implements OnInit {
  Tools = [
    { value: '0', viewValue: 'AA' },
    { value: '1', viewValue: 'BP' },
    { value: '2', viewValue: 'UI PATH' }
  ];
  ALicenses = [
    { value: '0', viewValue: 'Development License' },
    { value: '1', viewValue: 'Runtime License' },
  ];
  BLicenses = [
    { value: '0', viewValue: 'Enterprise' }

  ];
  showAA: any;
  showBP: boolean;
  onChange(drowpdownvalue) {
    if (drowpdownvalue === '0') {
      this.showAA = true;
      this.showBP = false;
    } else if (drowpdownvalue === '1') {
      this.showBP = true;
      this.showAA = false;
    } else {
      this.showBP = false;
      this.showAA = false;
    }
  }
  constructor() { }
  ngOnInit() {
    this.showAA = false;
    this.showBP = false;
  }
}

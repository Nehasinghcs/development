import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-homescreen',
  templateUrl: './homescreen.component.html',
  styleUrls: ['./homescreen.component.scss']
})
export class HomescreenComponent implements OnInit {

  constructor(private router: Router) { }

  switchTo(pageName, event) {
    event.stopPropagation();
    switch (pageName) {
      case 'addprocesss':
        this.router.navigateByUrl('root/settings/addprocess');
        break;
      case 'adduser':
        this.router.navigateByUrl('root/settings/adduser');
        break;
      case 'createprocessgroup':
        this.router.navigateByUrl('root/settings/createprocessgroup');
        break;
      case 'addcontroller':
        this.router.navigateByUrl('root/settings/addcontroller');
        break;
      case 'addaccount':
        this.router.navigateByUrl('root/settings/addaccount');
        break;
      case 'accounts':
        this.router.navigateByUrl('root/settings/accounts');
        break;
      case 'assignprocessgroup':
        this.router.navigateByUrl('root/settings/assignprocessgroup');
        break;
    }
  }

  ngOnInit() {
  }

}

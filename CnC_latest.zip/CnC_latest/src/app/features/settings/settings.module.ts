import { NgModule } from '@angular/core';
import { AccountsComponent } from './accounts/accounts.component';
import { FooterComponent } from './footer/footer.component';
import { AddcontrollerComponent } from './addcontroller/addcontroller.component';
import { AccountsService } from './accounts/accounts.service';
import { ProcessComponent } from './process/process.component';
import { CreateaccountComponent } from './createaccount/createaccount.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { ControllersComponent } from './controllers/controllers.component';
import { ControllerService } from './controllers/controllers.service';
import { AddprocessComponent } from './addprocess/addprocess.component';
import { SlaconfigComponent } from './slaconfig/slaconfig.component';
import { LicensecostComponent } from './licensecost/licensecost.component';
import { AdduserComponent } from './adduser/adduser.component';
import { CreateprocessgroupComponent } from './createprocessgroup/createprocessgroup.component';
import { SettingsComponent } from './settings.component';
import { settingsrouting } from './settings.routing';
import { HomescreenComponent } from './homescreen/homescreen.component';
import { AdduserService } from './adduser/adduser.service';
import { AssignprocessgroupComponent } from './assignprocessgroup/assignprocessgroup.component';
import { MaterialModule } from '../../shared/material/material.module';
import { CommonModule } from '@angular/common';

@NgModule({
    imports: [
        settingsrouting,
        CommonModule,
        MaterialModule,
        FormsModule,
        ReactiveFormsModule
    ],
    declarations: [
        SettingsComponent,
        AccountsComponent,
        FooterComponent,
        AddcontrollerComponent,
        CreateaccountComponent,
        ProcessComponent,
        ControllersComponent,
        AddprocessComponent,
        SlaconfigComponent,
        LicensecostComponent,
        AdduserComponent,
        CreateprocessgroupComponent,
        HomescreenComponent,
        AssignprocessgroupComponent
    ],
    providers: [
        AccountsService,
        ControllerService,
        AdduserService
    ]
})

export class SettingsModule { }

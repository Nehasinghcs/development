import { Component, OnInit } from '@angular/core';
import { ControllerService } from '../controllers/controllers.service';
import { Router } from '@angular/router';
import { Controller } from '../../../class/controller';
import { AssociatedProperty } from '../../../class/associatedProperty';
import { SharedService } from '../../../../services/shared.service';

@Component({
  selector: 'app-addcontroller',
  templateUrl: './addcontroller.component.html',
  styleUrls: ['./addcontroller.component.scss'],
  providers: [Controller]
})

export class AddcontrollerComponent implements OnInit {
  controller;
  tools: string[];
  propertyList: Array<AssociatedProperty> = [];

  constructor(private router: Router, private _controller: Controller, private _controllerService: ControllerService,
    private _sharedService: SharedService) {
    this.controller = _controller;
  }

  cancel() {
    this.router.navigateByUrl('root/settings/home');
  }

  onSubmit(form: any, propertyForm: any) {
    propertyForm.submitted = true;
    if (form.valid && propertyForm.valid) {
      this._sharedService.emitSpinnerChange(true);
      this._controllerService.addController(form, this.propertyList).subscribe(response => {
        this._sharedService.emitSpinnerChange(false);
      }, (err) => {
        this._sharedService.emitSpinnerChange(false);
      });
    }
  }

  addProperty_row(formValues: any) {
    if (formValues.valid) {
      const _associatedProperty: AssociatedProperty = new AssociatedProperty();
      _associatedProperty.code = '';
      _associatedProperty.name = '';
      this.propertyList.push(_associatedProperty);
    }
  }

  deleteProperty(index) {
    this.propertyList.splice(index, 1);
  }

  ngOnInit() {
    this._sharedService.emitSpinnerChange(true);
    this._controllerService.getTools().subscribe(response => {
      this.tools = response.tools;
      this._sharedService.emitSpinnerChange(false);
      const _associatedProperty: AssociatedProperty = new AssociatedProperty();
      _associatedProperty.code = '';
      _associatedProperty.name = '';
      this.propertyList.push(_associatedProperty);
    });
  }

}

export class AssociatedProperty {
    code: string;
    name: string;
}

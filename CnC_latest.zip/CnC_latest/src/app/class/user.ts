import { Roles } from './roles';

export class User {
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    role: Roles;
    constructor() {
        this.role = new Roles();
    }
}

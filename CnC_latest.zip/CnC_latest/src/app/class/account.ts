export class Accounts {
    accountId: number;
    accountName: string;
    verticalId: number;
    vertical: string;
    accountAdmin: string;
    email: string;
    editable: boolean;
}

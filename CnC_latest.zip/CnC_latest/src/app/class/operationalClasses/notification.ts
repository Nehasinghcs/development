import { Exception } from './exception';

export class NotificationsClass {
    exception: Exception;
    showActions: boolean;
    constructor() {
        this.exception = new Exception();
    }
}

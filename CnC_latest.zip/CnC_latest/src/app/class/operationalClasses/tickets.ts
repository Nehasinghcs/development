export class Tickets {
    ticketId: string;
    type: string;
    status: string;
    description: string;
    robotId: string;
    processName: string;
    createdBy: string;
    createdOn: Date;
    location: string;
    alertOrganisationDetails: string;
    affectedClientDetails: string;
    issueDescription: string;
    additionalInfo: string;
}

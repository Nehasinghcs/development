export class Case {
    caseId: string;
    hostName: string;
    caseStatus: string;
    controllerId: string;
    robotName: string;
    botName: string;
    ipAddress: string;
    robotId: string;
    type: string;
    errorMsg: string;
    jobId: string;
    verticalId: string;
    accountId: string;
    botId: string;
    caseStartTime: Date;
    caseEndTime: Date;
    businessProcessId: string;
    businessProcessName: string;
    locationId: string;
}

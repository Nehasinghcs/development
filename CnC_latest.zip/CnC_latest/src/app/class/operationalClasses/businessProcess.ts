import { BusinessProcessGroup } from './businessProcessGroup';

export class BusinessProcess {
    id: string;
    name: string;
    critical: boolean;
    startTime: string;
    endTime: string;
    status: string;
    tool: string;
    verticalId: string;
    accountId: string;
    avgHandlingTime: number;
    throughput: number;
    yield: number;
    outstandingTickets: number;
    desc: string;
    slaBreachCount: number;
    processGroup: BusinessProcessGroup;
    constructor() {
        this.processGroup = new BusinessProcessGroup('', '');
    }
}

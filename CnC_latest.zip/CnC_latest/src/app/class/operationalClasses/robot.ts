import { BusinessProcess } from './businessProcess';

export class Robot {
    hostName: string;
    id: number;
    robotId: string;
    name: string;
    status: string;
    type: string;
    utilization: number;
    vertical: string;
    location: string;
    accountName: string;
    expiryDate: string;
    controller: string;
    process: BusinessProcess;
    constructor() {
        this.process = new BusinessProcess();
    }
}

export class Exception {
    id: string;
    accountId: string;
    accountName: string;
    businessProcessId: string;
    businessProcessName: string;
    category: string;
    controllerId: string;
    controllerName: string;
    exceptionType: string;
    inputType: string;
    locationId: string;
    logType: string;
    loggedOn: Date;
    message: string;
    robotId: string;
    robotName: string;
    hostName: string;
    source: string;
    subCategory: string;
    verticalId: string;
}

export class Process {
    serialNo: number;
    accountName: string;
    vertical: string;
    accountAdmin: string;
    noOfUsers: string;
}

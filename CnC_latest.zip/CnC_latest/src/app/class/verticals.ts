export class Verticals {
    id: string;
    name: string;
}

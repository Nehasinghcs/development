export class Controller {
    controllerName: string;
    selectedTool: string;
    version: string;
    url: string;
    hostName: string;
    location: string;
    controllerUserName: string;
    controllerUserId: string;
    controllerUserEmail: string;
    controllerPassword: string;
    dbServerName: string;
    dbInstanceName: string;
    dbName: string;
    dbUserName: string;
    dbPassword: string;
}

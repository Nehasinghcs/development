import { Directive, Component, Input, OnInit } from '@angular/core';
import { Chart, MapChart } from 'angular-highcharts';

@Component({
    selector: 'pie-chart',
    templateUrl: './piechart.component.html'
})

export class PieChart implements OnInit {
    @Input() pieChartSettings: any;
    pieChart: any;
    constructor() { }

    getTotal() {
        if (this.pieChartSettings !== undefined) {
            return this.pieChartSettings.p1 + this.pieChartSettings.p2 + this.pieChartSettings.p3;
        }
    }

    ngOnInit() {
        if (this.pieChartSettings !== undefined) {
            this.pieChart = new MapChart({
                chart: {
                    type: 'pie',
                    margin: this.pieChartSettings.margin,
                    height: this.pieChartSettings.height
                },
                title: {
                    text: this.pieChartSettings.titleText,

                    // text: '<span style="font-family: OpenSans;font-size: 28px;font-weight: bold;text-align: center;color: #394961;">' + (this.pieChartSettings.p1 + this.pieChartSettings.p2 + this.pieChartSettings.p3) + '</span><br><span style="font-size: 14px; text-align: center; font-family: OpenSans;color: #394961;">Total</span>',
                    align: 'center',
                    verticalAlign: 'middle',
                    y: this.pieChartSettings.y,
                    x: this.pieChartSettings.x,
                },
                plotOptions: {
                    pie: {
                        allowPointSelect: false,
                        cursor: 'pointer',
                        dataLabels: {
                            enabled: this.pieChartSettings.dlenabled,
                            connectorColor: 'transparent',
                            distance: 15,
                            formatter: function () {
                                return this.y + '%';
                            },
                            style: {
                                font: '20px OpenSans',
                                color: '#394961',
                                fontSize: 14,
                                fontWeight: 600
                            }
                        },
                        startAngle: this.pieChartSettings.startAngle,
                        endAngle: this.pieChartSettings.endAngle,
                        center: this.pieChartSettings.center
                    },
                    series: {
                        showInLegend: false,
                        states: {
                            hover: false
                        }
                    }
                },
                tooltip: {
                    enabled: false
                },

                series: [{
                    borderWidth: 0,
                    data: [
                        { name: 'P1', y: this.pieChartSettings.p1, color: '#f04d3b' },
                        { name: 'P2', y: this.pieChartSettings.p2, color: '#fcb137' },
                        { name: 'P3', y: this.pieChartSettings.p3, color: '#00a0e7' }
                    ],
                    size: this.pieChartSettings.size,
                    innerSize: '85%',
                    showInLegend: false
                }]
            });
        }
    }
}

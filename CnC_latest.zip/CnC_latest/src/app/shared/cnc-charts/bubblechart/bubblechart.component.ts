import { Directive, Component, Input, OnInit, AfterViewInit, ChangeDetectorRef, DoCheck } from '@angular/core';
import { Chart, MapChart } from 'angular-highcharts';
import { Router } from '@angular/router';
import { ProcessService } from '../../../features/dashboard/processview/processview.service';
import { BusinessProcess } from '../../../class/operationalClasses/businessProcess';

@Component({
    selector: 'app-bubble-chart',
    templateUrl: './bubbleChart.component.html',
    styleUrls: ['./bubbleChart.component.scss']
})

export class BubbleChartComponent implements OnInit {
    s2pJobDetailsSmall: { 'botId': string; 'robotId': string; 'jobStatus': string; 'jobStartTime': string; 'jobEndTime': string; 'botName': string; 'robotName': string; 'controllerId': string; 'verticalId': string; 'accountId': string; 'tool': string; 'id': string; 'critical': boolean; 'errorMsg': any; 'jobId': string; 'businessProcessId': string; 'businessProcessName': string; 'locationId': string; 'taskCompleted': string; }[];

    // @Input() bubbleChartSettings: any;
    @Input() plotType: string;
    @Input() isSmall: any;
    @Input() isDetail: any;
    @Input() processList: any;
    @Input() processParentPage: string;

    bubbleChart: any;
    bubbleChartSettings: any = {};
    s2pProcessDetailsPlotData: any[] = [];
    plotDataArray = [];
    critData = [];
    nonCritData = [];
    countCritical = 0;
    countNonCritical = 0;
    rproi: any;
    xyDataPlot: any[] = [];

    constructor(private _router: Router, private cdr: ChangeDetectorRef, private _processService: ProcessService) {
    }

    generateData() {
        let x,
            y,
            xMin,
            altX = true,
            xInc = 15,
            xN,
            yN;
        const xMaxPlot = this.isSmall ? 20 : 30,
            yMaxPlot = 40,
            yInc = 5,
            ynInc = 5;

        let yIterate = 1;


        // Y axis limits
        const smallRowUpperY = 20;
        const smallRowLowerY = this.isSmall ? -35 : -15;

        // Row spacing
        const normalRowSpacing = this.isSmall ? 6 : 7;
        const smallRowSpacing = 6;

        // Row height
        const ySpacing = this.isSmall ? 15 : 8;



        // Default X row start point
        const xDefaultMin = this.isSmall ? 3 : 4;

        // X plot start point
        const xPlotStart = this.isSmall ? 9 : 14;

        // Default Y plotting start point
        const yPlotStart = this.isSmall ? -37 : -21;


        const smallRowUpperSpacing = 8;
        const smallRowXLowerMin = this.isSmall ? 0 : 5;
        const smallRowXUpperMin = 4;
        let xMax;
        let xLastPlotted;

        let yLastPlotted = yPlotStart;

        for (y = yPlotStart; yIterate <= this.countCritical; y += ySpacing) {// Change 10
            altX = (y === yPlotStart) ? altX : !altX;
            xInc = (y === yPlotStart) ? xMaxPlot : ((y < smallRowLowerY || y === smallRowUpperY) ? smallRowSpacing : normalRowSpacing);
            xMin = (y === yPlotStart) ? xPlotStart : ((y < smallRowLowerY) ? smallRowXLowerMin : (altX ? 0 : xDefaultMin));
            xMax = xMaxPlot;
            for (x = xMin; x <= xMax; x += xInc) {
                this.critData.push({
                    x: x,
                    y: y
                });
                yIterate++;
                xMax = (yIterate <= this.countCritical) ? xMax : x;
                xLastPlotted = x;
                yLastPlotted = y;
            }
        }
        let yNIterate = 1;
        const smallNRowY = -5;

        // Row spacing
        const smallNRowSpacing = 12;
        const smallNRowXmin = 12;

        const yNInit = (xLastPlotted >= xMaxPlot) ? (this.countCritical === 0 ? yLastPlotted : yLastPlotted + 10) : yLastPlotted;
        const xNInit = this.countCritical === 0 ? (altX ? 5 : 0) : ((xLastPlotted >= xMaxPlot) ? (altX ? xDefaultMin : 0) : x);

        for (yN = yNInit; yNIterate <= (this.countNonCritical); yN += ySpacing) {
            // xInc = (yN >= smallRowUpperY) ? smallRowSpacing : (this.isSmall ? 10 : 10);
            xInc = (yN >= smallRowUpperY) ? smallRowSpacing : normalRowSpacing;
            xMin = (yN === yNInit) ? xNInit : ((yN >= smallRowUpperY) ? smallRowXUpperMin : (altX ? 0 : xDefaultMin));
            // xMax = (yN < 0) ? (this.isSmall ? 15 : 30) : (yN >= smallRowUpperY ? 25 : (altX ? xMaxPlot : xMaxPlot));
            xMax = xMaxPlot;
            for (xN = xMin; xN <= xMax; xN += xInc) {
                this.nonCritData.push({
                    x: xN,
                    y: yN
                });
                yNIterate++;
                xMax = (yNIterate <= this.countNonCritical) ? xMax : xN;
            }
            altX = !altX;
        }
    }

    onClick = (event: any) => {
        // if (event.point.isCritical) {
        const businessProcess: BusinessProcess = new BusinessProcess();
        businessProcess.id = event.point.id;
        businessProcess.name = event.point.name;
        this._processService.selectedBusinessProcess = businessProcess;
        this._processService.processParentPage = this.processParentPage;
        this._router.navigateByUrl('root/dashboard/view/automation/process');
        // }
    }

    formatHexagonChart() {
        this.plotDataArray = this.processList;
        const onlyCritical = (this.processList.length > 20) ? true : false;
        this.countCritical = this.plotDataArray.filter((obj) => obj.critical === true).length;
        this.countNonCritical = this.plotDataArray.filter((obj) => obj.critical === false).length;
        this.plotDataArray.sort(function (a, b) {
            if (a.critical) {
                return 1;
            } else {
                return 0;
            }
        });

        const xIncrement = 0;
        const alterNate = true;

        const seriesOne = {
            pointPlacement: -0.55,
            data: [],
            showInLegend: false,
        };

        // let seriesTwo = {
        //     pointPlacement: 0.5,
        //     data: [],
        //     showInLegend: false,
        // }

        const arrayOne = [];
        const arrayTwo = [];

        let count = 1;
        let alternateFlag = true;
        let yVal = 5;
        let isCritical = false;
        let firstCritical = true;
        const zCritical = this.isSmall ? 3 : 4;
        const zNonCritical = this.isSmall ? 3 : 4;

        this.generateData();

        const criticalPlotArray: any[] = this.critData;

        const nonCriticalPlotArray: any[] = this.nonCritData;
        let iterateCritical = 0;
        let iterateNonCritical = 0;
        for (let i of this.plotDataArray) {
            isCritical = i.critical;
            const addToarray = isCritical ? true : (onlyCritical ? false : true);
            if (addToarray) {

                arrayOne.push({
                    x: isCritical ? criticalPlotArray[iterateCritical].x : nonCriticalPlotArray[iterateNonCritical].x,
                    y: isCritical ? criticalPlotArray[iterateCritical].y : nonCriticalPlotArray[iterateNonCritical].y,
                    z: isCritical ? zCritical : zNonCritical,
                    id: i.accountId,
                    name: i.name,
                    isCritical: isCritical,
                    color: isCritical ? {
                        linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
                        stops: [
                            [0, '#ff6686'],
                            [1, '#feab9e']
                        ]
                    } : {
                            radialGradient: { cx: 0.4, cy: 0.3, r: 0.7 },
                            stops: [
                                [0, '#6587ff'],
                                [1, '#26e4fe']
                            ]
                        },
                    marker: isCritical ? {} : {
                        fillColor: '#ffffff',
                        borderColor: '#f04d3b'
                    },
                    // events: isCritical ? {
                    //      click: this.onClick
                    //     // click: function () {
                    //     //     if (isCritical) {
                    //     //         console.log(this.id)
                    //     //         alert(this.id)
                    //     //         location.href = '#/dashboard/view/automation/process'
                    //     //     }
                    //     // }
                    // } : {
                    //     }
                });
            }

            count++;
            isCritical ? iterateCritical++ : iterateNonCritical++;
            yVal = alternateFlag ? ((firstCritical && isCritical) ? Math.abs(yVal) + 5 : -Math.abs(yVal)) : ((count % 4) === 0 ? Math.abs(yVal) + 4 : (isCritical ? Math.abs(yVal) + 5 : Math.abs(yVal) + 1.5));
            alternateFlag = !alternateFlag;
            firstCritical = !isCritical;
        }

        seriesOne.data = arrayOne;
        // seriesTwo.data = arrayTwo;
        this.s2pProcessDetailsPlotData.push(seriesOne);

        // Bubble chart settings
        this.bubbleChartSettings.chartHeight = this.isSmall ? 110 : 160; // Height
        this.bubbleChartSettings.chartWidth = this.isSmall ? 110 : (this.isDetail ? 140 : 160); // Width


        this.bubbleChartSettings.isxAxisVisible = false; //  X axis settings
        this.bubbleChartSettings.xMax = this.isSmall ? 22 : 32;
        this.bubbleChartSettings.xMin = this.isSmall ? -4 : -5;

        this.bubbleChartSettings.isyAxisVisible = false; //  Y axis settings
        this.bubbleChartSettings.yMax = this.isSmall ? -35 : -25;
        this.bubbleChartSettings.yMin = this.isSmall ? 5 : 20;

        this.bubbleChartSettings.isToolTipEnabled = false;

        this.bubbleChartSettings.seriesData = this.s2pProcessDetailsPlotData;


        this.plotBubbleChart();

    }

    // Plot Bubble chart

    plotBubbleChart() {
        if (this.bubbleChartSettings !== undefined) {
            this.bubbleChart = new Chart({
                chart: {
                    type: 'bubble',
                    margin: [0, 0, 0, 0],
                    height: this.bubbleChartSettings.chartHeight,
                    width: this.bubbleChartSettings.chartWidth,
                    backgroundColor: 'transparent'
                },
                title: { text: null },
                xAxis: {
                    visible: this.bubbleChartSettings.isxAxisVisible,
                    gridLineWidth: 1,
                    max: this.bubbleChartSettings.xMax,
                    min: this.bubbleChartSettings.xMin,
                },
                yAxis: {
                    visible: this.bubbleChartSettings.isyAxisVisible,
                    min: this.bubbleChartSettings.yMax,
                    max: this.bubbleChartSettings.yMin
                },
                tooltip: {
                    enabled: this.bubbleChartSettings.isToolTipEnabled
                },
                plotOptions: {
                    bubble: {
                        minSize: 0,
                        maxSize: 100,
                        zMin: 0,
                        zMax: 100
                    },
                },
                series: this.bubbleChartSettings.seriesData
            });
        }


    }

    prePlotData() {
        // PrePlot data

        const xMidPoint = 0;
        const dataPerCol = 3;

        const dataCount = 60;


        const xthreshold = (dataCount / dataPerCol) / 2; // max : this.bubbleChartSettings.xMax
        const yThreshold = 8; // this.bubbleChartSettings.yMin

        this.xyDataPlot = [];
        let altColumn = false;
        for (let xVal = xMidPoint; xVal < xMidPoint + xthreshold; xVal += 2) {
            for (let yVal = (altColumn ? 2.5 : 0); yVal <= yThreshold; yVal += 5) {
                this.xyDataPlot.push({
                    x: xVal,
                    y: yVal,
                });
                if (yVal !== 0) {
                    this.xyDataPlot.push({
                        x: xVal,
                        y: -Math.abs(yVal),

                    });
                }
            }
            altColumn = !altColumn;
        }
        // altColumn = !altColumn;
        for (let xVal = xMidPoint - 2; xVal > (xMidPoint - (xthreshold)); xVal -= 2) {
            for (let yVal = (altColumn ? 2.5 : 0); yVal <= yThreshold; yVal += 5) {
                this.xyDataPlot.push({
                    x: xVal,
                    y: yVal,
                    z: 4
                });
                if (yVal !== 0) {
                    this.xyDataPlot.push({
                        x: xVal,
                        y: -Math.abs(yVal),
                        z: 4
                    });
                }
            }
            altColumn = !altColumn;
        }


    }

    formatNormalChart() {
        this.plotDataArray = this.processList;
        this.countCritical = this.plotDataArray.filter((obj) => obj.critical === true).length;
        this.countNonCritical = this.plotDataArray.filter((obj) => obj.critical === false).length;
        this.plotDataArray.sort(function (a, b) {
            if (a.critical) {
                return 0;
            } else {
                return 1;
            }
        });

        const xIncrement = 0;
        const alterNate = true;

        const seriesOne = {
            pointPlacement: -0.55,
            data: [],
            showInLegend: false,
        };

        const arrayOne = [];
        const arrayTwo = [];

        const count = 1;
        const alternateFlag = true;
        const yVal = 5;
        let isCritical = false;
        const firstCritical = true;
        const zCritical = this.isSmall ? 3 : 4;
        const zNonCritical = this.isSmall ? 3 : 4;


        const xyDataPlot: any[] = this.xyDataPlot;

        const criticalPlotArray: any[] = this.critData;

        const nonCriticalPlotArray: any[] = this.nonCritData;
        const iterateCritical = 0;
        const iterateNonCritical = 0;

        let plotIndex = 0;
        for (const i of this.plotDataArray) {
            isCritical = i.critical;
            arrayOne.push({
                // x: isCritical ? criticalPlotArray[iterateCritical].x : nonCriticalPlotArray[iterateNonCritical].x,
                x: this.xyDataPlot[plotIndex].x,
                // y: isCritical ? criticalPlotArray[iterateCritical].y : nonCriticalPlotArray[iterateNonCritical].y,
                y: this.xyDataPlot[plotIndex].y,
                z: 4,
                id: i.accountId,
                name: i.name,
                isCritical: isCritical,
                color: isCritical ? {
                    linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
                    stops: [
                        [0, '#ff6686'],
                        [1, '#feab9e']
                    ]
                } : {
                        radialGradient: { cx: 0.4, cy: 0.3, r: 0.7 },
                        stops: [
                            [0, '#6587ff'],
                            [1, '#26e4fe']
                        ]
                    },
                marker: isCritical ? {} : {
                    fillColor: '#ffffff',
                    borderColor: '#f04d3b'
                },
                events: {
                    click: this.onClick
                }
            });

            plotIndex++;

        }

        // seriesOne.data = arrayOne;
        // this.s2pProcessDetailsPlotData.push(seriesOne);

        // Bubble chart settings
        this.bubbleChartSettings.chartHeight = 200; // Height
        this.bubbleChartSettings.chartWidth = 400; // Width


        this.bubbleChartSettings.isxAxisVisible = false; //  X axis settings
        this.bubbleChartSettings.xMax = 20;
        this.bubbleChartSettings.xMin = -20;

        this.bubbleChartSettings.isyAxisVisible = false; //  Y axis settings
        this.bubbleChartSettings.yMax = -15;
        this.bubbleChartSettings.yMin = 15;

        this.bubbleChartSettings.isToolTipEnabled = false;


        this.bubbleChartSettings.seriesData = [
            {
                'pointPlacement': -0.55,
                'data': arrayOne,
                showInLegend: false,

            }
        ];

        this.plotBubbleChart();

    }

    ngOnInit() {
        if (this.processList.length) {
            if (this.plotType === 'hexagon') {
                this.formatHexagonChart();
            } else if (this.plotType === 'normal') {
                this.prePlotData();
                this.formatNormalChart();
            }

        }
    }

}

import { Component, Input, OnInit } from '@angular/core';
import { Chart, Highcharts } from 'angular-highcharts';

@Component({
    selector: 'column-chart',
    templateUrl: './columnchart.component.html'
})

export class ColumnChart implements OnInit {
    @Input() columnChartCategoryData: any[];
    columnChart: any;
    constructor() { }
    
    ngOnInit() {
        if (this.columnChartCategoryData !== undefined && this.columnChartCategoryData.length) {
            this.columnChart = new Chart({
                chart: {
                    type: 'column',
                    height: 160
                },
                title: {
                    text: ''
                },
                tooltip: {
                    enabled: false
                },
                xAxis: {
                    categories: this.columnChartCategoryData[0],
                    labels: {
                        style: {
                            color: '#9ea6a9',
                        }
                    },
                    tickLength: 0,
                },
                yAxis: {
                    min: 0,
                    max: 100,
                    tickInterval: 25,
                    title: {
                        text: ''
                    },
                    labels: {
                        formatter: function () {
                            return this.value;
                        },
                        style: {
                            color: '#9ea6a9',
                        }
                    },
                    gridLineDashStyle: 'ShortDash'
                },
                plotOptions: {
                    column: {
                        pointWidth: 15,
                        zones: [{
                            value: 1,
                            color: {
                                linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
                                stops: [
                                    [0, '#70cdff'],
                                    [1, '#2c90f7']
                                ]
                            }
                        }, {
                            color: {
                                linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
                                stops: [
                                    [0, '#feab9e'],
                                    [1, '#ff6686']
                                ]
                            }
                        }]
                    },
                    series: {
                        color: {
                            linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
                            stops: [
                                [0, '#feab9e'],
                                [1, '#ff6686']
                            ]
                        },
                        marker: {
                            symbol: 'c-rect',
                            lineWidth: 2,
                            lineColor: '#626579',
                            radius: 10,
                            states: {
                                hover: {
                                    enabled: false
                                }
                            }
                        },
                        showInLegend: false
                    }
                },
                series: [
                    {
                        data: this.columnChartCategoryData[1]

                    },
                    {
                        type: 'scatter',
                        data: this.columnChartCategoryData[2]
                    }
                ],
            });
        }
        Highcharts.Renderer.prototype.symbols['c-rect'] = function (x, y, w, h) {
            return ['M', x, y + h / 2, 'L', x + w, y + h / 2];
        };
    }


}

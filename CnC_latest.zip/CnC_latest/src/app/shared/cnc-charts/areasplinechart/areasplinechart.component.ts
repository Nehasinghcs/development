import { Component, Input, OnInit } from '@angular/core';
import { Chart, MapChart } from 'angular-highcharts';

@Component({
  selector: 'spline-chart',
  templateUrl: './areasplinechart.component.html'
})

export class AreaSplineChartComponent implements OnInit {

  @Input() splineChartSettings: any;
  @Input() plotData: any;

  areasplineChart: any;
  constructor() { }

  ngOnInit() {
    if (this.splineChartSettings !== undefined && this.plotData !== undefined) {
      this.areasplineChart = new Chart({
        chart: {
          type: 'areaspline',
          height: this.splineChartSettings.height
        },
        title: {
          text: ''
        },
        tooltip: {
          enabled: false
        },
        xAxis: {
          categories: ['12AM', '', '02AM', '', '04AM', '', '06AM', '', '08AM', '', '10AM', '', '12PM', '', '02PM', '', '04PM', '', '06PM', '', '08PM', '', '10PM'],

          visible: this.splineChartSettings.xAxisVisible,
          allowDecimals: false,
          minorTickLength: 0,
          tickLength: 0,
          lineWidth: 0,
         /* labels: {
            step: this.splineChartSettings.stepXaxis,
            formatter: function () {
              return this.value + '';
            },
            type: 'datetime',
            dateTimeLabelFormats: {
              hour: '%H:%M'
            },
          }*/
        },
        yAxis: {
          visible: this.splineChartSettings.yAxisvisible,
          title: {
            text: ''
          },
          labels: {
            formatter: this.splineChartSettings.formatteryaxis
          },
          gridLineDashStyle: this.splineChartSettings.linestyle,
          gridLineWidth: 1
        },
        credits: {
          enabled: true
        },
        legend: {
          align: 'left',
          layout: 'horizontal',
          margin: -1,
          verticalAlign: 'bottom',
          y: 20,
          symbolWidth: 12
        },
        plotOptions: {
          areaspline: {
            fillOpacity: 0.3
          },
          series: {
            marker: {
              enabled: false
            },
            showInLegend: false,
            lineWidth: 1
          }
        },
        series: this.plotData
      });
    }
  }
}

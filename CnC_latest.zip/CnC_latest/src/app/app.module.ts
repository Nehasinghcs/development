import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { routing } from './app.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DataService } from '../services/data.services';
import { HttpModule } from '@angular/http';
import 'hammerjs';
import { SharedService } from '../services/shared.service';
import { ToasterModule, ToasterService } from 'angular2-toaster';
import { UtilityService } from './utility/utility.services';
import { SpinnerComponent } from './shared/spinner/spinner.component';
import { RootComponent } from './root.component';
import { HeaderModule } from './header/header.module';

@NgModule({
  declarations: [
    AppComponent,
    RootComponent,
    SpinnerComponent
  ],
  imports: [
    BrowserModule,
    routing,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    HttpModule,
    ToasterModule,
    HeaderModule
  ],
  providers: [DataService, SharedService, UtilityService],
  bootstrap: [AppComponent]
})
export class AppModule { }

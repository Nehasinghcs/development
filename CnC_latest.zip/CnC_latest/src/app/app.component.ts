import { Component } from '@angular/core';
import { SharedService } from '../services/shared.service';

@Component({
  selector: 'app-root',
  template: `<router-outlet></router-outlet>
  <app-spinner [style.display]="showSpinner? 'block' : 'none'"></app-spinner>
  <toaster-container></toaster-container>`
})
export class AppComponent {
  showSpinner = false;
  constructor(private _sharedService: SharedService) {
    this._sharedService.changeEmitted.subscribe(value => {
      if (value) {
        this._sharedService.emitOperationalSpinnerChange(false);
      }
      this.showSpinner = value;
    });
  }
}


import { Routes, RouterModule } from '@angular/router';
import { RootComponent } from './root.component';

const app_routes: Routes = [
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: 'login', loadChildren: 'app/features/account/account.module#AccountModule' },
    {
        path: 'root', component: RootComponent, children: [
            { path: '', redirectTo: '/root/settings', pathMatch: 'full' },
            { path: 'settings', loadChildren: 'app/features/settings/settings.module#SettingsModule' },
            { path: 'dashboard', loadChildren: 'app/features/dashboard/dashboard.module#DashboardModule' },
            { path: 'workload', loadChildren: 'app/features/work-load/workload.module#WorkLoadModule' }
        ]
    }
];

export const routing = RouterModule.forRoot(app_routes);

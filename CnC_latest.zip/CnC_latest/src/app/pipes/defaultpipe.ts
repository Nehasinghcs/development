import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'defalutsearch'
})

export class DefaultPipe implements PipeTransform {
    transform(values: any[], search: string, attr: string, key: string) {
        if (values !== undefined && search !== undefined && search.length) {
            return values.filter(element => element[attr][key].toString().toLowerCase().includes(search.toLowerCase()));
        } else {
            return values;
        }
    }
}

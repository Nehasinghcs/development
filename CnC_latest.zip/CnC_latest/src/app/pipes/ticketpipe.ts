import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'ticketfilter'
})

export class TicketPipe implements PipeTransform{
    transform(values: any[], status: string) {
        // var returnValues: any[];
        if (values !== undefined && status !== undefined) {
            return values.filter(element => element.status === status);
        } else {
            return values;
        }
    }
}

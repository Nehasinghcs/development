import { NgModule } from '@angular/core';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { HeaderComponent } from './header.component';
import { MaterialModule } from '../shared/material/material.module';
import { ChatService } from './chart.service';
import { WebsocketService } from './websocket.service';
import { CommonModule } from '@angular/common';
import { NotificationsService } from '../features/dashboard/notifications/notifications.service';
import { WidgetService } from '../../services/widget.service';
import { RobotService } from '../features/dashboard/workforce/robot.service';

const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
    suppressScrollX: true
};

@NgModule({
    declarations: [
        HeaderComponent
    ],
    imports: [
        MaterialModule,
        CommonModule,
        PerfectScrollbarModule
    ],
    exports: [
        HeaderComponent
    ],
    providers: [
        { provide: PERFECT_SCROLLBAR_CONFIG, useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG },
        ChatService,
        WebsocketService,
        NotificationsService,
        WidgetService,
        RobotService
    ]
})

export class HeaderModule { }

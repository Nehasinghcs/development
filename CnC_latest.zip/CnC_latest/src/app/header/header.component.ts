import { Component, OnInit } from '@angular/core';
import { MatSidenav } from '@angular/material';
import { Router } from '@angular/router';
import { Data } from '@angular/router/src/config';
import { Subject } from 'rxjs';
import { ChatService } from './chart.service';
import * as moment from 'moment';
import { NotificationsClass } from '../class/operationalClasses/notification';
import { WidgetService } from '../../services/widget.service';
import { UtilityService } from '../utility/utility.services';
import { SharedService } from '../../services/shared.service';
import { Exception } from '../class/operationalClasses/exception';
import { NotificationsService } from '../features/dashboard/notifications/notifications.service';
import { RobotService } from '../features/dashboard/workforce/robot.service';
import { Constants } from '../utility/app.constants';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})

export class HeaderComponent implements OnInit {

  notificationList: NotificationsClass[] = [];
  fadein: boolean;
  fadeout: boolean;
  show: any;
  display: any;
  isNotified = false;
  DateList = [];

  constructor(private _notificationsService: NotificationsService, private chat: ChatService, private _widgetService: WidgetService, private _utilityService: UtilityService, private _robotService: RobotService, private _router: Router, private _sharedService: SharedService) {
  }

  getName() {
    if (localStorage.username !== undefined) {
      const user: any[] = this._sharedService.users.filter(element => element.userName.toLowerCase() === localStorage.username.toLowerCase());
      if (user !== undefined && user.length) {
        return user[0]['name'];
      } else {
        return 'Avinash';
      }
    }
  }

  getFullName() {
    if (localStorage.username !== undefined) {
      const user: any[] = this._sharedService.users.filter(element => element.userName.toLowerCase() === localStorage.username.toLowerCase());
      if (user !== undefined && user.length) {
        return user[0]['fullName'];
      } else {
        return 'Avinash Birnale';
      }
    }
  }

  getEmail() {
    if (localStorage.username !== undefined) {
      const user: any[] = this._sharedService.users.filter(element => element.userName.toLowerCase() === localStorage.username.toLowerCase());
      if (user !== undefined && user.length) {
        return user[0]['email'];
      } else {
        return 'avinash.birnale@genpact.digital';
      }
    }
  }

  switchTo(event) {
    let navigateToTab;
    switch (event.index) {
      case 0:
        if (this._widgetService.activeGlances !== undefined && this._widgetService.activeGlances.length) {
          navigateToTab = this._router.navigateByUrl(this._widgetService.activeGlances[0].routeUrl);
        } else {
          navigateToTab = this._router.navigateByUrl(this._widgetService.getActiveGlances()[0].routeUrl);
        }
        break;
      case 1:
        break;
      case 2:
        navigateToTab = this._router.navigateByUrl('/root/settings');
        break;
    }
    return navigateToTab;
  }

  onMouseOver() {
    this.fadeout = true;
    this.fadein = false;
  }

  showsettings() {
    this.display = true;
  }

  mouseLeave() {
    this.isNotified = true;
    this.fadein = true;
    this.fadeout = false;
  }

  closesettings() {
    this.display = false;
  }


  goToDetailPage(item: NotificationsClass) {
    // this.mouseLeave();
    switch (item.exception.category) {
      case 'Robot':
        this._robotService.selectedRobot = {
          name: item.exception.robotName,
          status: undefined,
          from: null,
          id: item.exception.robotId,
          accountName: item.exception.accountName,
          hostName: item.exception.hostName,
        };
        this._robotService.emitSelectedRobot(this._robotService.selectedRobot);
        this._robotService.emitRobotSelected(true);
        this._router.navigateByUrl('/root/dashboard/view/workforce/robot');
        this._robotService.emitIsRobotView(2);
        break;
      case 'Process':
        break;
      case 'Job':
        break;
    }

  }

  logout() {
    this._sharedService.currentView = 1;
    this._widgetService.activeGlances = [];
    this._sharedService.emitSpinnerChange(true);
    this._utilityService.logout().subscribe(response => {
      this._sharedService.emitSpinnerChange(false);
      localStorage.clear();
      this._router.navigateByUrl('');
    }, (err) => {
      this._sharedService.emitSpinnerChange(false);
      localStorage.clear();
      this._router.navigateByUrl('');
    });
  }

  getDataList(dateitem) {
    const _notificationList: NotificationsClass[] = [];
    this.notificationList.forEach(element => {
      if (dateitem === moment(element.exception.loggedOn).format('DD/MM/YYYY')) {
        _notificationList.push(element);
      }
    });
    return _notificationList;
  }

  displayName(param) {
    const todayDate: any = new Date();
    const currentDate = moment(new Date()).format('DD/MM/YYYY');
    const yesterdayDate: any = new Date(todayDate - (1000 * 60 * 60 * 24));
    const yest = moment(yesterdayDate).format('DD/MM/YYYY');
    if (currentDate === param) {
      return Constants.today;
    } else if (yest === param) {
      return Constants.yesterday;
    } else {
      return param;
    }
  }

  getNotificationMessage(item: Exception) {
    return this._notificationsService.getNotificationMessage(item);
  }

  displayLocalTime(item) {
    let dateString = new Date(item);
    dateString = new Date(dateString.getTime() + (dateString.getTimezoneOffset() * 60000));
    return moment(dateString).format('h:mm a');
  }

  ngOnInit() {
    this.display = false;
    this.fadeout = false;
    this.fadein = false;
    this._notificationsService.getAlertDetail().subscribe(response => {
      this.notificationList = this._notificationsService.prepareNotificationList(response.logDetails);
      this.DateList = this.notificationList.map(item => (moment(item.exception.loggedOn).format('DD/MM/YYYY'))).filter((value, index, self) => self.indexOf(value) === index);
    }, (error) => {
      this._utilityService.handleException(error);
    });

    // this.initializeWebSocketConnection();
    // this.chat.messages.subscribe(msg => {
    //   console.log(msg);
    // })
  }
}

export const environment = {
  production: true,
  josnPath: '../assets/'
};

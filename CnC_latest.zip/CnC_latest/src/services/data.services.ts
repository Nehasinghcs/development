import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { SharedService } from './shared.service';
import { UtilityService } from '../app/utility/utility.services';
import { Constants } from '../app/utility/app.constants';

@Injectable()

export class DataService {
    constructor(private _http: Http) { }

    login(url, reqData) {
        const header = new Headers();
        header.append('Content-Type', 'application/x-www-form-urlencoded');
        const options = new RequestOptions({ headers: header });
        return this._http.post(url, reqData, options)
            .map((response: Response) => response.json())
            .catch(this._errorHandler);
    }
    postData(url, reqData) {
        const header = new Headers();
        header.append('Authorization', 'bearer ' + localStorage.access_token);
        header.append('Content-Type', 'application/json');
        const options = new RequestOptions({ headers: header });
        return this._http.post(url, reqData, options)
            .map((response: Response) => response.json())
            .catch(this._errorHandler);
    }
    _errorHandler(error: Response) {
        return Observable.throw(error);
    }

    getDataFromJSON(jsonName) {
        return this._http.get(Constants.jsonPath + jsonName)
            .map((response: Response) => response.json());
    }

    // Following functions will be remooved once CORS issue is fixed
    getTools() {
        return this._http.get('../assets/tools.json')
            .map((response: Response) => response.json());
    }
    getVerticals() {
        return this._http.get('../assets/verticals.json')
            .map((response: Response) => response.json());
    }
/*     getAccounts() {
        return this._http.get('../assets/accounts.json')
            .map((response: Response) => response.json());
    } */


}

import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Tickets } from '../app/class/operationalClasses/tickets';
import { Case } from '../app/class/operationalClasses/case';
import { Exception } from '../app/class/operationalClasses/exception';
import { Verticals } from '../app/class/verticals';

@Injectable()

export class SharedService {

    users: any[] = [{
        userName: 'kaushik',
        email: 'Kaushik.Bhaskar@genpact.digital',
        name: 'Kaushik',
        fullName: 'Kaushik Bhaskar'
    }, {
        userName: 'avinash',
        email: 'avinash.birnale@genpact.digital',
        name: 'Avinash',
        fullName: 'Avinash Birnale'
    }];

    exceptionList: Exception[];
    caseList: Case[];

    private _emitIsProcessViewOn = new Subject<boolean>();
    changeProcessViewEmitted = this._emitIsProcessViewOn.asObservable();
    tickets;
    private _emitCriticalTicket = new Subject<Tickets[]>();
    criticalTicketEmitted = this._emitCriticalTicket.asObservable();
    showFullScreen = false;
    private _emitViewSizeChange = new Subject<boolean>();
    changeViewSizeEmitted = this._emitViewSizeChange.asObservable();
    currentView = 1;
    private _emitWidgetChange = new Subject<string>();
    widgetChange = this._emitWidgetChange.asObservable();
    private _emitActiveViewChange = new Subject<number>();
    changeViewEmitted = this._emitActiveViewChange.asObservable();
    private _emitSpinnerChange = new Subject<boolean>();
    changeEmitted = this._emitSpinnerChange.asObservable();
    private _emitOperationalSpinnerChange = new Subject<boolean>();
    changeOperationalSpinnerEmitted = this._emitOperationalSpinnerChange.asObservable();
    private _emitAutomationNameChange = new Subject<string>();
    changeAutomationName = this._emitAutomationNameChange.asObservable();
    emitIsProcessViewChange(change: boolean) {
        this._emitIsProcessViewOn.next(change);
    }

    emitCriticalTicket(tickets: Tickets[]) {
        this.tickets = tickets;
        this._emitCriticalTicket.next(tickets);
    }

    emitViewSizeChange(change: boolean) {
        this.showFullScreen = change;
        this._emitViewSizeChange.next(change);
    }

    emitWidgetChange(oldValue: number, newValue: number) {
        this.currentView = newValue;
        this._emitWidgetChange.next(oldValue + '-' + newValue);
    }

    emitViewChange(change: number) {
        this._emitActiveViewChange.next(change);
    }

    emitSpinnerChange(change: boolean) {
        this._emitSpinnerChange.next(change);
    }

    emitOperationalSpinnerChange(change: boolean) {
        this._emitOperationalSpinnerChange.next(change);
    }

    emitAutomationName(val: string) {
        this._emitAutomationNameChange.next(val);
    }
}

import { Injectable } from '@angular/core';

@Injectable()

export class WidgetService {

    activeGlances: any[] = [];

    originalGlances = [
        {
            name: 'workforce',
            position: 1,
            routeUrl: 'root/dashboard/view/workforce/health',
            class: 'workforce-widget'
        }, {
            name: 'process',
            position: 2,
            routeUrl: 'root/dashboard/view/processview/on',
            class: 'process-widget'
        }, {
            name: 'notification',
            position: 3,
            routeUrl: 'root/dashboard/view/notifications',
            class: 'notification-widget'
        }, {
            name: 'analysis',
            position: 4,
            routeUrl: 'root/dashboard/view/analysis',
            class: 'analysis-widget'
        }, {
            name: 'automation',
            position: 5,
            routeUrl: 'root/dashboard/view/automationview/allaccounts',
            class: 'automation-widget'
        }, {
            name: 'hotspots',
            position: 6,
            routeUrl: 'root/dashboard/view/hotspots/fullview',
            class: 'hotspots-widget'
        }, {
            name: 'criticalTickets',
            position: 7,
            routeUrl: 'root/dashboard/view/criticaltickets',
            class: 'criticaltickets-widget'
        }, {
            name: 'ticketMetrics',
            position: 8,
            routeUrl: 'root/dashboard/view/ticketmetrics',
            class: 'ticketmetrics-widget'
        }
    ];

    getActiveGlances() {
        const activeGlances: any[] = new Array<any>();
        let isGoing = true;
        this.originalGlances.forEach(element => {
            if (isGoing) {
                activeGlances.push(element);
                if (activeGlances.length === 6) {
                    isGoing = false;
                }
            }
        });
        return activeGlances;
    }
}
